# Threads Multi-Tab UID Distributor & Auto Liker (Compact Edition)

Ekstensi Chrome (Manifest V3) ultra-kompak untuk mendistribusikan UID dan mengontrol form **Like Post** ke banyak tab Threads secara serentak.

## 📌 Update Terbaru:
1. **Sistem Log Ringkas (Hanya Sekali & Notifikasi Error)**:
   - Tidak lagi mencetak log baris per baris per tab (tidak ada lagi `Tab 1 selesai`, `Tab 2 selesai`, dst).
   - **Jika semua sukses**: Langsung muncul 1 baris saja, contoh:
     - `Berhasil semua tab (4 Tab) - Menu & Like Post dibuka`
     - `Berhasil semua tab (4 Tab) - UID & Delay terisi`
     - `Berhasil semua tab (4 Tab) - Start Like aktif`
   - **Jika ada tab yang gagal**: Ekstensi akan menyebutkan secara spesifik tab mana yang error beserta alasannya, contoh:
     - `Gagal di: Tab 3 (Tombol Like Post tidak ditemukan)`
2. **Auto-Pangkas UID Terpakai**:
   - Begitu Anda klik tombol **"📝 Isi UID & Delay"**, ekstensi akan mengisi UID ke tab yang ditargetkan (misal 4 tab x 250 = 1.000 UID).
   - Setelah sukses diisi, **1.000 UID tersebut otomatis langsung dipotong/dihapus dari kotak input master**, menyisakan **9.000 UID** berikutnya di baris teratas!
3. **Kotak Input "Jml Tab" (3 Kolom Sejajar)**:
   - **UID / Tab**: Jumlah UID yang dialokasikan per tab (contoh: 250).
   - **Delay (detik)**: Jeda waktu eksekusi (contoh: 0.1).
   - **Jml Tab**: Jumlah tab yang ingin dijalankan (contoh: isi `4` jika hanya ingin menjalankan 4 tab; kosongkan untuk semua).
2. **Tombol "Jalankan Semua Otomatis" Dihapus**:
   - Fokus menggunakan 4 tombol kontrol langsung agar eksekusi di multi-tab stabil dan terpantau:
     - 🔘 **Buka Menu & Like Post**: Klik icon SVG lalu langsung auto klik tombol `#likePost` di tab yang dipilih.
     - 📝 **Isi UID & Delay**: Membagi dan mengisi UID serta delay ke tab yang dipilih.
     - ▶️ **Start Like**: Mengklik `#startLikePost` di tab yang dipilih.
     - ⏹️ **Stop Like**: Mengklik `#stopLikePost` di tab yang dipilih.
3. **Perbaikan Log & Scrollbar Rapi**:
   - Tampilan log rapi dengan scrollbar vertikal tanpa tumpang tindih.

---

## 🚀 Cara Update di Chrome:
1. Buka `chrome://extensions`.
2. Klik tombol **Reload (ikon panah melingkar 🔄)** pada kartu ekstensi ini.
