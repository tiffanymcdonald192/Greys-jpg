// Threads UID Multi-Tab Auto Manager - Compact Edition
// Manifest V3

document.addEventListener('DOMContentLoaded', async () => {
  const filterScopeEl = document.getElementById('filterScope');
  const tabCountBadge = document.getElementById('tabCountBadge');
  const btnRefreshTabs = document.getElementById('btnRefreshTabs');

  const masterUidInput = document.getElementById('masterUidInput');
  const totalUidCount = document.getElementById('totalUidCount');
  const neededTabsCount = document.getElementById('neededTabsCount');
  const allocationStatus = document.getElementById('allocationStatus');

  const btnRemoveDuplicates = document.getElementById('btnRemoveDuplicates');
  const btnClearUid = document.getElementById('btnClearUid');

  const uidPerTabInput = document.getElementById('uidPerTab');
  const delayInput = document.getElementById('delayInput');
  const maxTabsInput = document.getElementById('maxTabsInput');
  const autoDivideEqually = document.getElementById('autoDivideEqually');

  const btnOpenMenuAndLike = document.getElementById('btnOpenMenuAndLike');
  const btnInjectUidDelay = document.getElementById('btnInjectUidDelay');
  const btnStartLike = document.getElementById('btnStartLike');
  const btnStopLike = document.getElementById('btnStopLike');

  const logConsole = document.getElementById('logConsole');
  const btnClearLog = document.getElementById('btnClearLog');

  let currentTabs = [];

  // ==========================================
  // Storage
  // ==========================================
  async function loadSettings() {
    try {
      const data = await chrome.storage.local.get([
        'masterUids',
        'uidPerTab',
        'delayVal',
        'maxTabsVal',
        'autoDivide',
        'filterScopeVal'
      ]);

      if (data.masterUids !== undefined) masterUidInput.value = data.masterUids;
      if (data.uidPerTab !== undefined) uidPerTabInput.value = data.uidPerTab;
      if (data.delayVal !== undefined) delayInput.value = data.delayVal;
      if (data.maxTabsVal !== undefined) maxTabsInput.value = data.maxTabsVal;
      if (data.autoDivide !== undefined) autoDivideEqually.checked = data.autoDivide;
      if (data.filterScopeVal !== undefined) filterScopeEl.value = data.filterScopeVal;
    } catch (e) {
      console.warn(e);
    }
  }

  function saveSettings() {
    chrome.storage.local.set({
      masterUids: masterUidInput.value,
      uidPerTab: uidPerTabInput.value,
      delayVal: delayInput.value,
      maxTabsVal: maxTabsInput.value,
      autoDivide: autoDivideEqually.checked,
      filterScopeVal: filterScopeEl.value
    });
  }

  // ==========================================
  // Ringkas Log
  // ==========================================
  function log(text, cls = '') {
    const div = document.createElement('div');
    if (cls) div.className = cls;
    div.textContent = text;
    logConsole.appendChild(div);
    logConsole.scrollTop = logConsole.scrollHeight;
  }

  btnClearLog.addEventListener('click', () => {
    logConsole.innerHTML = '';
    log('Ready.');
  });

  // ==========================================
  // UID Processing
  // ==========================================
  function getCleanUids() {
    return masterUidInput.value
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0);
  }

  function updateUidCalculations() {
    const uids = getCleanUids();
    const total = uids.length;
    totalUidCount.textContent = total;

    let perTab = parseInt(uidPerTabInput.value, 10);
    if (isNaN(perTab) || perTab <= 0) perTab = 1;

    let maxTabs = parseInt(maxTabsInput.value, 10);
    const availableTabs = currentTabs.length;
    const activeTabsCount = (maxTabs && maxTabs > 0) ? Math.min(maxTabs, availableTabs) : availableTabs;

    if (autoDivideEqually.checked && activeTabsCount > 0) {
      perTab = Math.max(1, Math.ceil(total / activeTabsCount));
      uidPerTabInput.value = perTab;
    }

    const neededTabs = perTab > 0 ? Math.ceil(total / perTab) : 0;
    neededTabsCount.textContent = neededTabs;

    if (total === 0) {
      allocationStatus.textContent = 'Belum diisi';
      allocationStatus.className = 'txt-warn';
    } else if (availableTabs === 0) {
      allocationStatus.textContent = 'Tab belum ada';
      allocationStatus.className = 'txt-warn';
    } else {
      const distributed = Math.min(total, activeTabsCount * perTab);
      const remaining = total - distributed;
      const tabInfo = (maxTabs && maxTabs > 0 && maxTabs < availableTabs) ? `${activeTabsCount}/${availableTabs} tab` : `${availableTabs} tab`;
      if (remaining > 0) {
        allocationStatus.textContent = `Pakai: ${distributed} | Sisa: ${remaining} UID (Tersimpan)`;
        allocationStatus.className = 'txt-ok';
      } else {
        allocationStatus.textContent = `Semua ${total} UID terbagi (${tabInfo})`;
        allocationStatus.className = 'txt-ok';
      }
    }

    saveSettings();
  }

  btnRemoveDuplicates.addEventListener('click', () => {
    const uids = getCleanUids();
    const unique = [...new Set(uids)];
    const removed = uids.length - unique.length;
    masterUidInput.value = unique.join('\n');
    updateUidCalculations();
    log(`Duplikat dihapus: -${removed}`, 'log-ok');
  });

  btnClearUid.addEventListener('click', () => {
    masterUidInput.value = '';
    updateUidCalculations();
    log('UID dikosongkan.');
  });

  masterUidInput.addEventListener('input', updateUidCalculations);
  uidPerTabInput.addEventListener('input', updateUidCalculations);
  delayInput.addEventListener('input', saveSettings);
  maxTabsInput.addEventListener('input', updateUidCalculations);

  autoDivideEqually.addEventListener('change', () => {
    uidPerTabInput.disabled = autoDivideEqually.checked;
    updateUidCalculations();
  });

  // ==========================================
  // Tab Query
  // ==========================================
  async function refreshTabs() {
    try {
      const scope = filterScopeEl.value;
      let tabs = [];

      // Query semua tab di jendela browser saat ini
      const windowTabs = await chrome.tabs.query({ currentWindow: true });
      const validTabs = windowTabs.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('devtools://') && !t.url.startsWith('chrome-extension://') && !t.url.startsWith('about:'));

      if (scope === 'threads') {
        // Deteksi domain threads.net (baik www.threads.net, threads.net, dll)
        tabs = validTabs.filter(t => t.url && t.url.toLowerCase().includes('threads.net'));
      } else {
        tabs = validTabs;
      }

      currentTabs = tabs;
      tabCountBadge.textContent = `${tabs.length} Tab`;
      updateUidCalculations();
      return tabs;
    } catch (err) {
      log(`Error tab: ${err.message}`, 'log-err');
      return [];
    }
  }

  btnRefreshTabs.addEventListener('click', async () => {
    await refreshTabs();
    log(`Tab diperbarui (${currentTabs.length} tab).`);
  });

  filterScopeEl.addEventListener('change', () => {
    saveSettings();
    refreshTabs();
  });

  // ==========================================
  // Injected Tab Functions
  // ==========================================

  // 1. Klik Icon Menu lalu AUTO Klik Tombol Like Post (#likePost)
  async function inTabClickIconThenLikePost() {
    const sleep = ms => new Promise(r => setTimeout(r, ms));

    // Cari icon menu (SVG polygon 10.5,6.5 atau id Free_Icons / SVGRepo_iconCarrier)
    let iconTarget = document.querySelector('#Free_Icons') ||
                     document.querySelector('#SVGRepo_iconCarrier') ||
                     document.querySelector('polygon[points*="10.5,6.5"]');

    if (!iconTarget) {
      const polygons = document.querySelectorAll('polygon');
      for (const poly of polygons) {
        const pts = poly.getAttribute('points') || '';
        if (pts.includes('10.5,6.5') || pts.includes('16,23.5')) {
          iconTarget = poly;
          break;
        }
      }
    }

    if (iconTarget) {
      const clickable = iconTarget.closest('button, [role="button"], a, div') || iconTarget;
      clickable.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      clickable.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
      clickable.click();
    }

    // Jeda sejenak agar menu / popover muncul
    await sleep(250);

    // Cari dan klik tombol Like Post
    const likeBtn = document.getElementById('likePost') ||
                    Array.from(document.querySelectorAll('button')).find(b => b.textContent && b.textContent.includes('Like Post'));

    if (!likeBtn) {
      return { success: false, message: 'Tombol Like Post tidak ditemukan' };
    }

    likeBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    likeBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    likeBtn.click();

    return { success: true };
  }

  // 2. Isi UID & Delay ke Form
  function inTabInjectForm(uidString, delayVal) {
    const inputUidEl = document.getElementById('inputLikePost') || document.querySelector('textarea#inputLikePost');
    const delayEl = document.getElementById('delayLikePost') || document.querySelector('input#delayLikePost');

    if (!inputUidEl) {
      return { success: false, message: 'Form belum terbuka' };
    }

    const setVal = (el, val) => {
      const isTa = el instanceof HTMLTextAreaElement;
      const proto = isTa ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) {
        desc.set.call(el, val);
      } else {
        el.value = val;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    };

    setVal(inputUidEl, uidString);
    if (delayEl && delayVal) setVal(delayEl, delayVal);

    return { success: true };
  }

  // 3. Klik Start Like
  function inTabClickStart() {
    const startBtn = document.getElementById('startLikePost') ||
                     Array.from(document.querySelectorAll('button')).find(b => b.textContent && b.textContent.includes('Start Like'));

    if (!startBtn) return { success: false, message: 'Tombol Start Like tidak ada' };

    startBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    startBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    startBtn.click();
    return { success: true };
  }

  // 4. Klik Stop Like
  function inTabClickStop() {
    const stopBtn = document.getElementById('stopLikePost') ||
                    document.querySelector('button.btn-stop') ||
                    Array.from(document.querySelectorAll('button')).find(b => b.textContent && b.textContent.includes('Stop'));

    if (!stopBtn) return { success: false, message: 'Tombol Stop tidak ada' };

    stopBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    stopBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    stopBtn.click();
    return { success: true };
  }

  // ==========================================
  // Execution Dispatcher (Eksekusi Serentak Semua Tab)
  // ==========================================
  async function runOnTabs(func, actionLabel, argsProvider = null) {
    // Pastikan selalu query daftar tab terbaru sebelum eksekusi
    await refreshTabs();

    if (currentTabs.length === 0) {
      log('Tidak ada tab target.', 'log-warn');
      return { totalToRun: 0, successCount: 0, failed: [] };
    }

    let maxTabs = parseInt(maxTabsInput.value, 10);
    const totalToRun = (maxTabs && maxTabs > 0) ? Math.min(maxTabs, currentTabs.length) : currentTabs.length;

    // Simpan hasil tiap tab
    const resultsList = new Array(totalToRun);
    const tasks = [];

    for (let i = 0; i < totalToRun; i++) {
      const tab = currentTabs[i];
      const tabNum = i + 1;
      const args = argsProvider ? argsProvider(tab, i) : [];

      tasks.push((async () => {
        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: func,
            args: args
          });

          const res = results && results[0] ? results[0].result : null;
          if (res && res.success) {
            resultsList[i] = { tabNum, success: true };
          } else {
            resultsList[i] = {
              tabNum,
              success: false,
              message: res && res.message ? res.message : 'gagal'
            };
          }
        } catch (err) {
          resultsList[i] = { tabNum, success: false, message: err.message };
        }
      })());
    }

    await Promise.all(tasks);

    // Evaluasi hasil log: hanya 1 kali
    const failed = resultsList.filter(r => !r.success);
    const successCount = totalToRun - failed.length;

    if (failed.length === 0) {
      // Jika semua sukses: tampilkan 1 baris sukses untuk semua tab
      log(`Berhasil semua tab (${totalToRun} Tab) - ${actionLabel}`, 'log-ok');
    } else {
      // Jika ada yang error: sebutkan tab mana yang error
      const errList = failed.map(f => `Tab ${f.tabNum} (${f.message})`).join(', ');
      log(`Gagal di: ${errList}`, 'log-err');
    }

    return { totalToRun, successCount, failed };
  }

  // ==========================================
  // Event Listeners Tombol Manual
  // ==========================================

  // 1. Klik Icon Menu lalu AUTO Klik Tombol Like Post (#likePost)
  btnOpenMenuAndLike.addEventListener('click', () => {
    runOnTabs(inTabClickIconThenLikePost, 'Menu & Like Post dibuka');
  });

  // 2. Isi UID & Delay (Auto-Pangkas UID yang terpakai)
  btnInjectUidDelay.addEventListener('click', async () => {
    const uids = getCleanUids();
    if (uids.length === 0) {
      log('UID masih kosong!', 'log-warn');
      return;
    }

    let perTab = parseInt(uidPerTabInput.value, 10);
    if (isNaN(perTab) || perTab <= 0) perTab = 1;
    const delayVal = delayInput.value.trim() || '0.1';

    let maxTabs = parseInt(maxTabsInput.value, 10);
    const availableTabs = currentTabs.length;
    const activeTabsCount = (maxTabs && maxTabs > 0) ? Math.min(maxTabs, availableTabs) : availableTabs;

    const usedCount = Math.min(uids.length, activeTabsCount * perTab);

    // Suntikkan ke tab-tab yang aktif
    const outcome = await runOnTabs(inTabInjectForm, 'UID & Delay terisi', (tab, i) => {
      const start = i * perTab;
      const end = Math.min(start + perTab, uids.length);
      const tabUids = uids.slice(start, end).join('\n');
      return [tabUids, delayVal];
    });

    // Otomatis pangkas UID yang sudah disuntikkan jika berhasil
    if (usedCount > 0 && outcome && outcome.successCount > 0) {
      const remainingUids = uids.slice(usedCount);
      masterUidInput.value = remainingUids.join('\n');
      updateUidCalculations();
      log(`Auto-pangkas: ${usedCount} UID dibuang (sisa ${remainingUids.length} UID di kotak).`, 'log-ok');
    }
  });

  // 3. Start Like
  btnStartLike.addEventListener('click', () => {
    runOnTabs(inTabClickStart, 'Start Like aktif');
  });

  // 4. Stop Like
  btnStopLike.addEventListener('click', () => {
    runOnTabs(inTabClickStop, 'Stop Like berhasil');
  });

  // Init
  await loadSettings();
  await refreshTabs();
});
