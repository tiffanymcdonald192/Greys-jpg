(() => {

  if (window.__THREADS_MULTI_TAB_POSTER__) {
    return;
  }

  window.__THREADS_MULTI_TAB_POSTER__ = true;


  // =========================================================
  // STATE
  // =========================================================

  // Lock ketika proses pengisian draft sedang berjalan.
  let postingInProgress = false;

  // Status draft untuk proses AUTO_SEND.
  let lastPostHasImage = false;
  let lastPostSent = false;


  // =========================================================
  // CONFIG
  // =========================================================

  const WAIT_SHORT = 80;
  const WAIT_MEDIUM = 150;
  const WAIT_UPLOAD = 500;

  const COMPOSER_TIMEOUT = 12000;
  const ELEMENT_TIMEOUT = 10000;


  // =========================================================
  // HELPERS
  // =========================================================

  const sleep = ms =>
    new Promise(resolve => setTimeout(resolve, ms));


  function visible(element) {

    if (!element) {
      return false;
    }

    const rect =
      element.getBoundingClientRect();

    const style =
      getComputedStyle(element);

    return (
      rect.width > 0 &&
      rect.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden"
    );

  }


  function getElementText(element) {

    if (!element) {
      return "";
    }

    return (
      element.innerText ||
      element.textContent ||
      element.getAttribute("aria-label") ||
      ""
    )
      .replace(/\s+/g, " ")
      .trim();

  }


  function clickElement(element) {

    if (!element) {
      return false;
    }

    try {

      element.scrollIntoView({
        block: "center",
        inline: "center"
      });

    } catch (_) {}


    try {

      try {
        element.dispatchEvent(
          new PointerEvent(
            "pointerdown",
            {
              bubbles: true,
              cancelable: true,
              view: window
            }
          )
        );
      } catch (_) {}


      element.dispatchEvent(
        new MouseEvent(
          "mousedown",
          {
            bubbles: true,
            cancelable: true,
            view: window
          }
        )
      );


      try {
        element.dispatchEvent(
          new PointerEvent(
            "pointerup",
            {
              bubbles: true,
              cancelable: true,
              view: window
            }
          )
        );
      } catch (_) {}


      element.dispatchEvent(
        new MouseEvent(
          "mouseup",
          {
            bubbles: true,
            cancelable: true,
            view: window
          }
        )
      );


      element.click();

      return true;

    } catch (error) {

      console.warn(
        "[Threads Poster] Click gagal:",
        error
      );

      return false;

    }

  }


  // =========================================================
  // WAIT UNTIL
  // =========================================================

  async function waitUntil(
    finder,
    timeout = ELEMENT_TIMEOUT,
    interval = WAIT_SHORT
  ) {

    const start =
      Date.now();

    while (
      Date.now() - start <
      timeout
    ) {

      const result =
        finder();

      if (result) {
        return result;
      }

      await sleep(interval);

    }

    return null;

  }


  // =========================================================
  // CARI TOMBOL "UTAS BARU"
  // =========================================================

  function findNewThreadButton() {

    const elements = [
      ...document.querySelectorAll(
        '[role="button"], button'
      )
    ];


    return elements.find(element => {

      if (!visible(element)) {
        return false;
      }


      const text =
        getElementText(element)
          .toLowerCase();


      const aria =
        (
          element.getAttribute(
            "aria-label"
          ) || ""
        )
          .trim()
          .toLowerCase();


      return (
        text === "utas baru" ||
        aria === "utas baru"
      );

    }) || null;

  }


  // =========================================================
  // CARI EDITOR
  // =========================================================

  function findEditor(root = document) {

    // Exact selector.
    const exact =
      root.querySelector?.(
        '[aria-label="Kolom teks kosong. Ketik untuk menulis postingan baru."][contenteditable="true"]'
      );


    if (
      exact &&
      visible(exact)
    ) {

      return exact;

    }


    // Lexical.
    const lexical =
      root.querySelector?.(
        '[contenteditable="true"][role="textbox"][data-lexical-editor="true"]'
      );


    if (
      lexical &&
      visible(lexical)
    ) {

      return lexical;

    }


    // Fallback.
    const elements = [
      ...(root.querySelectorAll?.(
        '[contenteditable="true"]'
      ) || [])
    ];


    return elements.find(element => {

      if (!visible(element)) {
        return false;
      }


      return (
        element.getAttribute("role") === "textbox" ||
        element.getAttribute("data-lexical-editor") === "true"
      );

    }) || null;

  }


  // =========================================================
  // CARI CONTAINER UTAS BARU
  // =========================================================

  function findNewThreadContainer() {

    const headings = [
      ...document.querySelectorAll("h1")
    ];


    const heading =
      headings.find(element => {

        if (!visible(element)) {
          return false;
        }


        return (
          getElementText(element)
            .toLowerCase() === "utas baru"
        );

      });


    if (!heading) {
      return null;
    }


    // Naik parent mencari container
    // yang memiliki editor.
    let container =
      heading;


    for (
      let i = 0;
      i < 12;
      i++
    ) {

      container =
        container.parentElement;


      if (!container) {
        break;
      }


      const editor =
        findEditor(container);


      if (editor) {
        return container;
      }

    }


    return null;

  }


  // =========================================================
  // CARI TOMBOL KIRIM
  // =========================================================

  function findSendButton(
    container = null
  ) {

    const root =
      container ||
      findNewThreadContainer();


    if (!root) {
      return null;
    }


    const buttons = [
      ...root.querySelectorAll(
        '[role="button"], button'
      )
    ];


    return buttons.find(button => {

      if (!visible(button)) {
        return false;
      }


      return (
        getElementText(button) === "Kirim"
      );

    }) || null;

  }


  // =========================================================
  // TUNGGU COMPOSER
  // =========================================================

  async function waitForComposer(
    timeout = COMPOSER_TIMEOUT
  ) {

    return await waitUntil(
      () => {

        const container =
          findNewThreadContainer();

        if (!container) {
          return null;
        }

        const editor =
          findEditor(container);

        if (!editor) {
          return null;
        }

        return {
          container,
          editor
        };

      },
      timeout,
      WAIT_SHORT
    );

  }

// =========================================================
// ISI CAPTION — PERTAHANKAN SETIAP BARIS
// =========================================================

async function setContentEditable(element, text) {
  if (!element) {
    throw new Error("Editor tidak ditemukan.");
  }

  const caption = String(text ?? "").replace(/\r\n?/g, "\n");

  element.focus();

  // Pilih dan hapus seluruh isi sebelumnya.
  const selection = window.getSelection();
  const range = document.createRange();

  range.selectNodeContents(element);
  selection.removeAllRanges();
  selection.addRange(range);

  document.execCommand("delete", false);

  const lines = caption.split("\n");

  for (let i = 0; i < lines.length; i++) {
    if (lines[i]) {
      document.execCommand("insertText", false, lines[i]);
    }

    if (i < lines.length - 1) {
      // Shift+Enter untuk membuat baris baru di editor.
      const eventOptions = {
        key: "Enter",
        code: "Enter",
        shiftKey: true,
        bubbles: true,
        cancelable: true
      };

      element.dispatchEvent(
        new KeyboardEvent("keydown", eventOptions)
      );

      document.execCommand("insertLineBreak", false);

      element.dispatchEvent(
        new KeyboardEvent("keyup", eventOptions)
      );
    }
  }

  element.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      inputType: "insertText",
      data: null
    })
  );

  element.focus();
}


  // =========================================================
  // CARI INPUT FILE
  // =========================================================

  function findFileInput(
    root = document
  ) {

    const inputs = [
      ...root.querySelectorAll(
        'input[type="file"]'
      )
    ];


    return (
      inputs.find(input =>
        visible(input)
      ) ||

      inputs[0] ||

      null
    );

  }


  // =========================================================
  // CARI TOMBOL MEDIA
  // =========================================================

  function findMediaButton(
    root = document
  ) {

    const elements = [
      ...root.querySelectorAll(
        '[role="button"], button'
      )
    ];


    return elements.find(element => {

      if (!visible(element)) {
        return false;
      }


      const aria =
        (
          element.getAttribute(
            "aria-label"
          ) || ""
        )
          .toLowerCase();


      const title =
        (
          element.getAttribute(
            "title"
          ) || ""
        )
          .toLowerCase();


      const text =
        getElementText(element)
          .toLowerCase();


      const combined =
        `${aria} ${title} ${text}`;


      return (
        combined.includes("foto") ||
        combined.includes("photo") ||
        combined.includes("image") ||
        combined.includes("gambar") ||
        combined.includes("media") ||
        combined.includes("lampiran") ||
        combined.includes("attach") ||
        combined.includes("upload")
      );

    }) || null;

  }


  // =========================================================
  // DOWNLOAD IMAGE
  // =========================================================

  async function downloadImage(url) {
    if (typeof url === "string" && url.startsWith("data:")) {
      const comma = url.indexOf(",");
      if (comma === -1) {
        throw new Error("Data URL gambar tidak valid.");
      }
      const meta = url.slice(0, comma);
      const b64 = url.slice(comma + 1);
      const mimeMatch = meta.match(/data:([^;]+)/i);
      const mime = mimeMatch ? mimeMatch[1] : "image/jpeg";
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) {
        bytes[i] = bin.charCodeAt(i);
      }
      return new Blob([bytes], { type: mime });
    }

    if (!url) {

      throw new Error(
        "URL gambar kosong."
      );

    }


    let response;


    try {

      response =
        await fetch(
          url,
          {
            method: "GET",
            mode: "cors",
            credentials: "omit",
            cache: "no-store"
          }
        );

    } catch (_) {

      throw new Error(
        "Gambar tidak bisa diambil. Kemungkinan server gambar memblokir CORS."
      );

    }


    if (!response.ok) {

      throw new Error(
        `HTTP ${response.status}`
      );

    }


    const blob =
      await response.blob();


    if (
      !blob ||
      !blob.size
    ) {

      throw new Error(
        "File gambar kosong."
      );

    }


    if (
      !blob.type ||
      !blob.type.startsWith("image/")
    ) {

      throw new Error(
        `URL tidak mengembalikan gambar (${blob.type || "unknown"}).`
      );

    }


    return blob;

  }


  // =========================================================
  // UPLOAD IMAGE
  // =========================================================

  async function uploadImageFromUrl(
    url,
    container
  ) {

    const blob =
      await downloadImage(url);


    // Cari input langsung.
    let input =
      findFileInput(container);


    // Kalau belum ada, cari global.
    if (!input) {

      input =
        findFileInput();

    }


    // Kalau tetap belum ada,
    // klik media.
    if (!input) {

      const mediaButton =
        findMediaButton(container) ||
        findMediaButton();


      if (mediaButton) {

        clickElement(
          mediaButton
        );


        // Tunggu input muncul,
        // bukan delay tetap.
        input =
          await waitUntil(
            () =>
              findFileInput(container) ||
              findFileInput(),
            5000,
            WAIT_SHORT
          );

      }

    }


    if (!input) {

      throw new Error(
        "Input upload gambar Threads tidak ditemukan."
      );

    }


    // =======================================================
    // FILE EXTENSION
    // =======================================================

    let extension = "jpg";


    if (blob.type) {

      const parts =
        blob.type.split("/");


      if (parts[1]) {

        extension =
          parts[1]
            .replace("jpeg", "jpg")
            .replace("svg+xml", "svg");

      }

    }


    // =======================================================
    // BUAT FILE
    // =======================================================

    const file =
      new File(
        [blob],
        `threads-image-${Date.now()}.${extension}`,
        {
          type:
            blob.type ||
            "image/jpeg",

          lastModified:
            Date.now()
        }
      );


    // =======================================================
    // DATA TRANSFER
    // =======================================================

    const dataTransfer =
      new DataTransfer();


    dataTransfer.items.add(
      file
    );


    try {

      input.files =
        dataTransfer.files;

    } catch (_) {

      throw new Error(
        "Browser menolak pemasangan file ke input Threads."
      );

    }


    // =======================================================
    // EVENTS
    // =======================================================

    input.dispatchEvent(
      new Event(
        "input",
        {
          bubbles: true
        }
      )
    );


    input.dispatchEvent(
      new Event(
        "change",
        {
          bubbles: true
        }
      )
    );


    // =======================================================
    // TUNGGU PREVIEW
    //
    // Preview gambar akan diperiksa lagi saat AUTO_SEND,
    // setelah background selesai melakukan switch tab.
    // =======================================================

    console.log(
      "[Threads Poster] File gambar dipasang; menunggu switch tab."
    );


    return true;

  }


  // =========================================================
  // CARI TOMBOL TOPIK / KOMUNITAS
  // =========================================================

  function findTopicButton(
    container = null
  ) {

    const roots = [
      container,
      document
    ].filter(Boolean);


    for (const root of roots) {

      // 1. Cari berdasarkan teks langsung pada elemen leaf / tombol
      const elements = [
        ...root.querySelectorAll(
          'span, div, [role="button"], button'
        )
      ];


      const textMatch = elements.find(el => {

        if (!visible(el)) {
          return false;
        }

        const text =
          (el.innerText || el.textContent || "")
            .trim()
            .toLowerCase();

        return (
          text === "komunitas atau topik" ||
          text === "komunitas" ||
          text === "topik" ||
          text === "community or topic" ||
          text === "topic" ||
          text === "add topic"
        );

      });


      if (textMatch) {

        return (
          textMatch.closest('[role="button"]') ||
          textMatch.closest('button') ||
          textMatch.closest('.x6s0dn4') ||
          textMatch
        );

      }


      // 2. Cari berdasarkan SVG plus (+) Barcelona / Threads
      const svgs = [
        ...root.querySelectorAll("svg")
      ];


      for (const svg of svgs) {

        if (!visible(svg)) {
          continue;
        }

        const path =
          svg.querySelector("path");

        const d =
          path?.getAttribute("d") || "";


        if (
          d.includes("M13.75 3.5") ||
          d.includes("13.75 3.5a1.75")
        ) {

          const pill =
            svg.closest('[role="button"]') ||
            svg.closest('button') ||
            svg.closest('.x6s0dn4') ||
            svg.parentElement;


          if (pill && visible(pill)) {
            return pill;
          }

        }

      }

    }


    return null;

  }


  // =========================================================
  // CARI INPUT TOPIK
  // =========================================================

  function findTopicInput(
    container = null
  ) {

    // 1. Cek activeElement jika browser langsung fokus ke input
    const active =
      document.activeElement;


    if (
      active &&
      active instanceof HTMLInputElement &&
      visible(active)
    ) {

      const type =
        (active.getAttribute("type") || "").toLowerCase();


      if (
        type !== "file" &&
        type !== "hidden" &&
        type !== "checkbox" &&
        type !== "radio"
      ) {
        return active;
      }

    }


    const scopes = [];

    if (container) {
      scopes.push(container);
    }

    // Portal / modal flyout Threads
    const dialogs = [
      ...document.querySelectorAll(
        '[role="dialog"], [role="menu"], [role="listbox"], [data-floating-ui-portal]'
      )
    ];

    dialogs.forEach(d => scopes.push(d));

    scopes.push(document);


    for (const scope of scopes) {

      // A. Exact placeholder
      const exact = [
        ...scope.querySelectorAll(
          'input[placeholder="Komunitas atau topik"], input[placeholder="Community or topic"]'
        )
      ].find(visible);


      if (exact) {
        return exact;
      }


      // B. Placeholder umum komunitas / topik
      const inputs = [
        ...scope.querySelectorAll(
          'input[type="text"], input[type="search"], input:not([type])'
        )
      ].filter(visible);


      const matched = inputs.find(input => {

        const placeholder =
          (input.getAttribute("placeholder") || "").toLowerCase();


        return (
          placeholder.includes("komunitas") ||
          placeholder.includes("topik") ||
          placeholder.includes("topic") ||
          placeholder.includes("community") ||
          placeholder.includes("cari") ||
          placeholder.includes("search")
        );

      });


      if (matched) {
        return matched;
      }


      // C. Jika di dalam container composer atau role dialog, ambil text input pertama yang terlihat
      if (
        scope === container ||
        scope.getAttribute?.("role") === "dialog"
      ) {

        const candidate = inputs.find(input => {

          const type =
            (input.getAttribute("type") || "").toLowerCase();


          return (
            type !== "file" &&
            type !== "hidden" &&
            type !== "checkbox" &&
            type !== "radio"
          );

        });


        if (candidate) {
          return candidate;
        }

      }

    }


    return null;

  }


  // =========================================================
  // CARI HASIL TOPIK
  // =========================================================

  function findTopicSuggestion(
    topic,
    root = document
  ) {

    const target =
      topic
        .trim()
        .toLowerCase()
        .replace(/^#/, "");


    if (!target) {
      return null;
    }


    const scopes = [root];

    if (root !== document) {
      scopes.push(document);
    }


    for (const scope of scopes) {

      const candidates = [
        ...scope.querySelectorAll(
          '[role="option"], [role="listbox"] [role="button"], [role="listbox"] div, [role="menuitem"], [role="button"]'
        )
      ].filter(visible);


      // Exact match (abaikan '#' di awal)
      const exact = candidates.find(element => {

        const text =
          getElementText(element)
            .toLowerCase()
            .replace(/^#/, "")
            .trim();


        return text === target;

      });


      if (exact) {
        return exact;
      }


      // Partial match
      const partial = candidates.find(element => {

        const text =
          getElementText(element)
            .toLowerCase()
            .replace(/^#/, "")
            .trim();


        return (
          text.startsWith(target) ||
          text.includes(target)
        );

      });


      if (partial) {
        return partial;
      }

    }


    return null;

  }


  // =========================================================
  // PILIH TOPIK CEPAT
  // =========================================================

  async function chooseTopic(
    topic,
    container
  ) {

    if (!topic) {
      return true;
    }


    const value =
      topic.trim();


    if (
      !value ||
      value.toLowerCase() === "tanpa topik" ||
      value === "-- tanpa topik --"
    ) {
      console.log(
        "[Threads Poster] Mode tanpa topik. Melewati pemilihan topik."
      );
      return true;
    }


    console.log(
      "[Threads Poster] Menyiapkan topik:",
      value
    );


    // 1. Cek apakah input topik sudah langsung tersedia
    let input =
      findTopicInput(container);


    // 2. Jika belum ada input, cari dan klik tombol/pill "Komunitas atau topik"
    if (!input) {

      console.log(
        "[Threads Poster] Mencari tombol 'Komunitas atau topik'..."
      );


      const button =
        findTopicButton(container) ||
        findTopicButton();


      if (button) {

        console.log(
          "[Threads Poster] Tombol 'Komunitas atau topik' ditemukan. Melakukan klik..."
        );


        clickElement(button);


        // Beri waktu animasi / render
        await sleep(WAIT_MEDIUM);


        // Tunggu hingga input topik muncul
        input =
          await waitUntil(
            () =>
              findTopicInput(container) ||
              findTopicInput(),
            4000,
            WAIT_SHORT
          );

      } else {

        console.warn(
          "[Threads Poster] Tombol 'Komunitas atau topik' tidak ditemukan."
        );

      }

    }


    // 3. Jika input masih tidak ditemukan
    if (!input) {

      console.warn(
        "[Threads Poster] Input topik tidak ditemukan setelah mencoba klik tombol."
      );


      return false;

    }


    console.log(
      "[Threads Poster] Input topik siap. Mengisi teks:",
      value
    );


    // 4. Fokus dan isi input topik
    input.focus();

    await sleep(WAIT_SHORT);


    // Masukkan nilai via execCommand jika memungkinkan
    try {

      document.execCommand("selectAll", false, null);

      document.execCommand("insertText", false, value);

    } catch (_) {}


    // Pastikan setter native juga dipanggil jika value belum berubah
    if (input.value !== value) {

      const setter =
        Object.getOwnPropertyDescriptor(
          HTMLInputElement.prototype,
          "value"
        )?.set;


      if (setter) {

        setter.call(
          input,
          value
        );

      } else {

        input.value =
          value;

      }

    }


    try {

      input.dispatchEvent(
        new InputEvent(
          "input",
          {
            bubbles: true,
            cancelable: true,
            inputType: "insertText",
            data: value
          }
        )
      );

    } catch (_) {

      input.dispatchEvent(
        new Event(
          "input",
          {
            bubbles: true
          }
        )
      );

    }


    input.dispatchEvent(
      new Event(
        "change",
        {
          bubbles: true
        }
      )
    );


    // 5. Polling suggestion list
    const suggestion =
      await waitUntil(
        () =>
          findTopicSuggestion(
            value,
            container
          ),
        3000,
        WAIT_SHORT
      );


    if (suggestion) {

      console.log(
        "[Threads Poster] Suggestion topik ditemukan, mengklik:",
        getElementText(suggestion)
      );


      clickElement(
        suggestion
      );


      await sleep(WAIT_MEDIUM);


      return true;

    }


    console.log(
      "[Threads Poster] Suggestion tidak ditemukan, mencoba tombol Enter..."
    );


    // 6. Fallback Enter
    try {

      input.dispatchEvent(
        new KeyboardEvent(
          "keydown",
          {
            key: "ArrowDown",
            code: "ArrowDown",
            keyCode: 40,
            which: 40,
            bubbles: true
          }
        )
      );


      await sleep(50);


      input.dispatchEvent(
        new KeyboardEvent(
          "keydown",
          {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            which: 13,
            bubbles: true
          }
        )
      );


      input.dispatchEvent(
        new KeyboardEvent(
          "keypress",
          {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            which: 13,
            bubbles: true
          }
        )
      );


      input.dispatchEvent(
        new KeyboardEvent(
          "keyup",
          {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            which: 13,
            bubbles: true
          }
        )
      );


      await sleep(WAIT_MEDIUM);


      return true;

    } catch (_) {

      return false;

    }

  }


  // =========================================================
  // POST / CREATE THREAD
  //
  // SETIAP POST SELALU MEMBUKA "UTAS BARU" BARU
  //
  // POST 1 -> klik Utas baru
  // POST 2 -> klik Utas baru
  // POST 3 -> klik Utas baru
  //
  // Tidak bergantung pada composer lama.
  // Tidak perlu reload tab.
  // =========================================================

  // =========================================================
  // INTERNAL API POSTING (DELEGASI KE MAIN WORLD AGAR BEBAS ERROR CSRF)
  // =========================================================

  async function prepareJpegFromUrl(imageUrl) {
    const blob = await downloadImage(imageUrl);
    const bitmap = await createImageBitmap(blob);
    let width = bitmap.width;
    let height = bitmap.height;

    const MAX_DIM = 1440;
    if (width > MAX_DIM || height > MAX_DIM) {
      const ratio = Math.min(MAX_DIM / width, MAX_DIM / height);
      width = Math.max(2, Math.round(width * ratio));
      height = Math.max(2, Math.round(height * ratio));
    }

    let jpegBlob;
    try {
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(bitmap, 0, 0, width, height);
      jpegBlob = await new Promise((resolve, reject) => {
        canvas.toBlob(
          b => (b ? resolve(b) : reject(new Error("Konversi JPEG gagal"))),
          "image/jpeg",
          0.92
        );
      });
    } finally {
      bitmap.close();
    }

    const jpegBuffer = await jpegBlob.arrayBuffer();
    return { jpegBuffer, width, height };
  }

  async function publishViaInternalApi(payload) {
    const hasImage = Boolean(payload.imageUrl && String(payload.imageUrl).trim());
    let imageData = { jpegBuffer: null, width: 0, height: 0 };

    if (hasImage) {
      imageData = await prepareJpegFromUrl(String(payload.imageUrl).trim());
    }

    const reqId =
      "ppt_post_" + Date.now() + "_" + Math.random().toString(36).slice(2, 9);

    return await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        window.removeEventListener("message", onMessage);
        reject(new Error("Timeout menunggu respons MAIN world (muat ulang tab Threads)."));
      }, 45000);

      function onMessage(event) {
        if (
          event.source !== window ||
          event.data?.type !== "PPT_MAIN_PUBLISH_POST_RES" ||
          event.data?.reqId !== reqId
        ) {
          return;
        }
        clearTimeout(timeout);
        window.removeEventListener("message", onMessage);

        const res = event.data.result;
        if (res && res.ok) {
          resolve(res);
        } else {
          reject(new Error(res?.error || "Gagal memposting via API Internal."));
        }
      }

      window.addEventListener("message", onMessage);

      window.postMessage(
        {
          type: "PPT_MAIN_PUBLISH_POST",
          reqId,
          caption: payload.caption ?? "",
          topic: payload.topic ?? "",
          quoteUrl: payload.quoteUrl || null,
          linkAttachmentUrl: payload.linkAttachmentUrl || null,
          jpegBuffer: imageData.jpegBuffer,
          width: imageData.width,
          height: imageData.height
        },
        "*"
      );
    });
  }
  async function postLinkViaInternalApi(rawLine) {
    const text = String(rawLine || "").trim();
    if (!text) {
      throw new Error("Teks / link kosong.");
    }

    const matches = text.match(/https?:\/\/[^\s<>"']+/gi) || [];
    const urls = [...new Set(matches)].map(u => u.replace(/[),.!?;:]+$/, ""));
    const linkAttachmentUrl = urls[0] || null;

    let cleanCaption = text;
    for (const url of urls) {
      const escaped = url.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      cleanCaption = cleanCaption.replace(new RegExp(escaped, "gi"), "");
    }

    cleanCaption = cleanCaption
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .replace(/\s{2,}/g, " ")
      .trim();

    return await publishViaInternalApi({
      caption: cleanCaption,
      imageUrl: "",
      topic: "",
      linkAttachmentUrl
    });
  }

  async function post(payload) {
    if (postingInProgress) {
      return { ok: false, ignored: true, error: "Posting sedang berjalan." };
    }
    postingInProgress = true;
    try {
      return await publishViaInternalApi(payload);
    } catch (error) {
      console.error("[Threads Poster API] Error:", error);
      return { ok: false, error: error?.message || String(error) };
    } finally {
      postingInProgress = false;
    }
  }

  async function postLegacyDom(payload) {

    // =======================================================
    // LOCK
    // =======================================================

    if (postingInProgress) {

      console.warn(
        "[Threads Poster] Proses masih berjalan."
      );

      return {
        ok: false,
        ignored: true,
        error: "Posting sedang berjalan."
      };

    }


    postingInProgress = true;

    lastPostHasImage =
      Boolean(payload.imageUrl);

    lastPostSent = false;


    try {

      // =====================================================
      // 1. SELALU CARI TOMBOL "UTAS BARU"
      // =====================================================

      console.log(
        "[Threads Poster] Mencari tombol Utas baru..."
      );


      const newThreadButton =
        await waitUntil(
          () => {

            const button =
              findNewThreadButton();

            if (!button) {
              return null;
            }

            return button;

          },
          10000,
          WAIT_SHORT
        );


      // =====================================================
      // 2. TOMBOL HARUS DITEMUKAN
      // =====================================================

      if (!newThreadButton) {

        throw new Error(
          "Tombol Utas baru tidak ditemukan."
        );

      }


      console.log(
        "[Threads Poster] Tombol Utas baru ditemukan."
      );


      // =====================================================
      // 3. KLIK UTAS BARU
      // =====================================================

      const clicked =
        clickElement(
          newThreadButton
        );


      if (!clicked) {

        throw new Error(
          "Gagal mengklik tombol Utas baru."
        );

      }


      console.log(
        "[Threads Poster] Utas baru diklik."
      );


      // =====================================================
      // 4. TUNGGU COMPOSER
      // =====================================================

      const composer =
        await waitForComposer(
          COMPOSER_TIMEOUT
        );


      // =====================================================
      // 5. COMPOSER HARUS BENAR-BENAR ADA
      // =====================================================

      if (!composer) {

        throw new Error(
          "Composer Utas baru tidak muncul setelah tombol diklik."
        );

      }


      console.log(
        "[Threads Poster] Composer baru siap."
      );


      const {
        container,
        editor
      } = composer;


      // =====================================================
      // 6. CAPTION
      // =====================================================

      if (
        payload.caption !== undefined &&
        payload.caption !== null
      ) {

        await setContentEditable(
          editor,
          payload.caption
        );

      }


      // Beri kesempatan React/Threads memproses perubahan.
      await sleep(WAIT_SHORT);


      // =====================================================
      // 7. TOPIK
      // =====================================================

      const topicTrimmed =
        String(payload.topic || "").trim();

      const hasValidTopic =
        Boolean(topicTrimmed) &&
        topicTrimmed.toLowerCase() !== "tanpa topik" &&
        topicTrimmed !== "-- tanpa topik --";

      if (hasValidTopic) {

        await chooseTopic(
          topicTrimmed,
          container
        );

      } else {

        console.log(
          "[Threads Poster] Tanpa topik: langkah pengisian topik dilewati."
        );

      }


      // =====================================================
      // 8. IMAGE
      // =====================================================

      if (payload.imageUrl) {

        await uploadImageFromUrl(
          payload.imageUrl,
          container
        );

      }


      // =====================================================
      // 9. SELESAI MENGISI DRAFT
      //
      // Belum mengeklik Kirim.
      // =====================================================

      console.log(
        "[Threads Poster] Caption, topik, dan gambar sudah siap."
      );


      console.log(
        "[Threads Poster] STOP SEBELUM KLIK KIRIM."
      );


      return {
        ok: true,
        filled: true,
        sent: false
      };


    } catch (error) {

      console.error(
        "[Threads Poster] Error:",
        error
      );


      return {
        ok: false,
        error:
          error?.message ||
          String(error)
      };


    } finally {

      // Lock dilepas setelah pengisian selesai.
      postingInProgress = false;

    }

  }


  // =========================================================
  // AUTO SEND
  //
  // Dipanggil background.js setelah selesai switch tab.
  // =========================================================

  async function autoSend() {

    if (lastPostSent) {

      return {
        ok: false,
        sent: false,
        error: "Draft ini sudah pernah diproses."
      };

    }


    // Cari composer yang sedang terbuka.
    const container =
      await waitUntil(
        () => findNewThreadContainer(),
        5000,
        WAIT_SHORT
      );


    if (
      !container ||
      !findEditor(container)
    ) {

      return {
        ok: false,
        sent: false,
        error: "Composer tidak ditemukan."
      };

    }


    // =======================================================
    // PASTIKAN PREVIEW GAMBAR SUDAH SIAP
    // =======================================================

    if (lastPostHasImage) {

      const preview =
        await waitUntil(
          () => {

            const currentContainer =
              findNewThreadContainer();


            if (!currentContainer) {
              return null;
            }


            const images = [
              ...currentContainer.querySelectorAll("img")
            ];


            return images.find(img => {

              if (!visible(img)) {
                return false;
              }


              const src =
                img.getAttribute("src") || "";


              return (
                src.startsWith("blob:") &&
                img.complete &&
                img.naturalWidth > 0 &&
                img.naturalHeight > 0
              );

            }) || null;

          },
          15000,
          WAIT_SHORT
        );


      if (!preview) {

        return {
          ok: false,
          sent: false,
          error: "Preview gambar belum siap; tombol Kirim tidak ditekan."
        };

      }

    }


    // =======================================================
    // TUNGGU TOMBOL KIRIM AKTIF
    // =======================================================

    const button =
      await waitUntil(
        () => {

          const currentContainer =
            findNewThreadContainer();


          if (!currentContainer) {
            return null;
          }


          const candidate =
            findSendButton(currentContainer);


          if (!candidate) {
            return null;
          }


          if (candidate.disabled) {
            return null;
          }


          if (
            candidate.getAttribute("aria-disabled") === "true"
          ) {
            return null;
          }


          return candidate;

        },
        10000,
        WAIT_SHORT
      );


    if (!button) {

      return {
        ok: false,
        sent: false,
        error: "Tombol Kirim belum aktif."
      };

    }


    // =======================================================
    // CEGAH KLIK GANDA
    // =======================================================

    lastPostSent = true;


    if (!clickElement(button)) {

      lastPostSent = false;

      return {
        ok: false,
        sent: false,
        error: "Gagal mengeklik tombol Kirim."
      };

    }


    console.log(
      "[Threads Poster] Tombol Kirim diklik."
    );


    return {
      ok: true,
      sent: true
    };

  }


  // =========================================================
  // MESSAGE HANDLER
  // =========================================================

  chrome.runtime.onMessage.addListener(
    (
      message,
      sender,
      sendResponse
    ) => {

      if (
        !message ||
        !message.action
      ) {

        return;
      }


      // =====================================================
      // POST: isi draft tanpa mengirim.
      // =====================================================

      if (message.action === "POST") {

        post(message)
          .then(result => {

            sendResponse(
              result
            );

          })
          .catch(error => {

            sendResponse({
              ok: false,
              error:
                error?.message ||
                String(error)
            });

          });


        return true;

      }


      // =====================================================
      // AUTO_SEND: kirim setelah switch tab selesai.
      // =====================================================

      if (message.action === "POST_LINK") {
        postLinkViaInternalApi(message.text)
          .then(result => sendResponse(result))
          .catch(error =>
            sendResponse({
              ok: false,
              sent: false,
              error: error?.message || String(error)
            })
          );
        return true;
      }

      if (message.action === "AUTO_SEND") {

        autoSend()
          .then(result => {

            sendResponse(
              result
            );

          })
          .catch(error => {

            sendResponse({
              ok: false,
              sent: false,
              error:
                error?.message ||
                String(error)
            });

          });


        return true;

      }

    }
  );


})();