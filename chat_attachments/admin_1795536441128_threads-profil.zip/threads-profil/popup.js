const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r => setTimeout(r, ms));

const inputUsernames = $('inputUsernames');
const inputPassword = $('inputPassword');
const inputSecrets = $('inputSecrets');
const countUsernames = $('countUsernames');
const countSecrets = $('countSecrets');
const autoEditProfileInput = $('autoEditProfile');
const autoEditProfileDesc = $('autoEditProfileDesc');
const loginBatchCountInput = $('loginBatchCount');
const loginProfilePhotoBox = $('loginProfilePhotoBox');
const loginProfileUrlsInput = $('loginProfileUrls');
const loginProfileFilesInput = $('loginProfileFiles');
const loginProfileFileBtn = $('loginProfileFileBtn');
const btnClearProfileFiles = $('btnClearProfileFiles');
const btnLogin = $('btnLogin');
const btnPin = $('btnPin');
const btnClear = $('btnClear');
const toastContainer = $('toastContainer');

const captionsInput = $('captions');
const urlsInput = $('urls');
const postFilesInput = $('postFiles');
const postFilesBtn = $('postFilesBtn');
const postFilesBtnText = $('postFilesBtnText');
const btnClearPostFiles = $('btnClearPostFiles');
const postFilesPreview = $('postFilesPreview');
let uploadedPostFiles = [];
const enableQuotePostInput = $('enableQuotePost');
const quoteUrlField = $('quoteUrlField');
const quoteUrlsInput = $('quoteUrls');
const quoteUrlCount = $('quoteUrlCount');
const combineCaptionsInput = $('combineCaptions');
const captionModeDescription = $('captionModeDescription');
const contentCount = $('contentCount');
const topicSelect = $('topic');
const tabCountInput = $('tabCount');
const delayInput = $('delay');
const startBtn = $('start');
const stopBtn = $('stop');
const statusEl = $('status');
const statusIndicator = $('statusIndicator');

const postLinkText = $('postLinkText');
const postLinkAllWindows = $('postLinkAllWindows');
const countPostLinks = $('countPostLinks');
const btnApplyPostLink = $('btnApplyPostLink');
const postLinkStatus = $('postLinkStatus');

const copyUrlsOutput = $('copyUrlsOutput');
const copyAllWindows = $('copyAllWindows');
const countCopyUrls = $('countCopyUrls');
const btnCopyAllUrls = $('btnCopyAllUrls');
const btnRefreshUrls = $('btnRefreshUrls');

const profilePhotoUrlsInput = $('profilePhotoUrls');
const profilePhotoFilesInput = $('profilePhotoFiles');
const profilePhotoFileBtn = $('profilePhotoFileBtn');
const btnClearProfilePhotoFiles = $('btnClearProfilePhotoFiles');
const profilePhotoPreview = $('profilePhotoPreview');
const countProfilePhoto = $('countProfilePhoto');
const profilePrivacySelect = $('profilePrivacySelect');
const profileBioTextInput = $('profileBioText');
const profileSingleBioInput = $('profileSingleBio');
const countProfileBio = $('countProfileBio');
const profileLinkTextInput = $('profileLinkText');
const profileSingleLinkInput = $('profileSingleLink');
const countProfileLink = $('countProfileLink');
const profileAllWindowsInput = $('profileAllWindows');
const profileTabCountInput = $('profileTabCount');
const profileStatusBar = $('profileStatusBar');
const profileStatusText = $('profileStatusText');
const profileStatusIndicator = $('profileStatusIndicator');
const btnApplyBioLink = $('btnApplyBioLink');
const btnApplyPrivacy = $('btnApplyPrivacy');

const LS_KEYS = {
  activeTab: 'ppt_active_tab',
  usernames: 'ppt_form_usernames',
  secrets: 'ppt_form_secrets',
  password: 'ppt_form_password',
  autoEditProfile: 'ppt_auto_edit_profile',
  loginBatchCount: 'ppt_login_batch_count',
  loginProfileUrls: 'ppt_login_profile_urls',
  profileBio: 'ppt_profile_bio',
  profileLink: 'ppt_profile_link',
  profileSingleBio: 'ppt_profile_single_bio',
  profileSingleLink: 'ppt_profile_single_link',
  profileAllWin: 'ppt_profile_all_win',
  profileTabCount: 'ppt_profile_tab_count',
  profilePrivacy: 'ppt_profile_privacy',
  profilePhotoUrls: 'ppt_profile_photo_urls',
  postData: 'ppt_post_form_v1',
  postLinkText: 'ppt_post_link_text',
  postLinkAllWin: 'ppt_post_link_allwin'
};

let uploadedProfileFiles = [];
let uploadedTabProfileFiles = [];

const POST_STORAGE_KEY = 'threads_popup_restore_v1';

// Cek apakah dibuka sebagai jendela Pin
const isPinnedWindow = new URLSearchParams(location.search).get('pinned') === '1';
if (isPinnedWindow) {
  document.body.classList.add('pinned-mode');
  if (btnPin) btnPin.style.display = 'none';
}

// =====================================================
// TOAST
// =====================================================

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const iconMap = {
    success: 'fa-circle-check',
    error: 'fa-circle-xmark',
    info: 'fa-circle-info'
  };

  toast.innerHTML = `
    <i class="fas ${iconMap[type] || iconMap.info}"></i>
    <span>${message}</span>
  `;

  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('out');
    setTimeout(() => toast.remove(), 220);
  }, 3800);
}

function parseLines(raw) {
  return (raw || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(s => s.length > 0);
}

// =====================================================
// 5-TAB SWITCHER (LOGIN | PROFIL | POST FOTO | POST LINK | COPY URL)
// =====================================================

const VALID_TABS = ['login', 'profile', 'post', 'link', 'copy'];
let activeTabName = localStorage.getItem(LS_KEYS.activeTab) || 'login';
if (!VALID_TABS.includes(activeTabName)) activeTabName = 'login';

function switchTab(tabName) {
  activeTabName = VALID_TABS.includes(tabName) ? tabName : 'login';
  try {
    localStorage.setItem(LS_KEYS.activeTab, activeTabName);
  } catch (_) {}

  document.querySelectorAll('.nav-tab').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === activeTabName);
  });

  document.querySelectorAll('.tab-view').forEach(view => {
    view.classList.toggle('active', view.id === `view-${activeTabName}`);
  });

  if (activeTabName === 'copy') {
    refreshOpenTabUrls();
  }
}

document.querySelectorAll('.nav-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    saveAllNow();
    switchTab(btn.dataset.tab);
  });
});

// =====================================================
// LOAD TOPICS (UNTUK PANEL AUTO POST)
// =====================================================

function initTopicOptions() {
  const datalist = $('topicList');
  if (!datalist) return;

  datalist.innerHTML = '';

  if (typeof TOPICS !== 'undefined' && Array.isArray(TOPICS)) {
    const seen = new Set();
    TOPICS.forEach(topic => {
      const trimmed = String(topic ?? '').trim();
      if (
        !trimmed ||
        trimmed.toLowerCase() === 'tanpa topik' ||
        trimmed === '-- tanpa topik --' ||
        seen.has(trimmed)
      ) {
        return;
      }
      seen.add(trimmed);
      const option = document.createElement('option');
      option.value = trimmed;
      datalist.appendChild(option);
    });
  }
}

initTopicOptions();

// =====================================================
// COUNTERS & CAPTION MODE UI
// =====================================================

function updateAllCounts() {
  const uCount = parseLines(inputUsernames.value).length;
  const sCount = parseLines(inputSecrets.value).length;
  if (countUsernames) countUsernames.textContent = `${uCount}`;
  if (countSecrets) countSecrets.textContent = `${sCount}`;

  const cCount = parseLines(captionsInput.value).length;
  const urlCount = (uploadedPostFiles && uploadedPostFiles.length > 0)
    ? uploadedPostFiles.length
    : parseLines(urlsInput.value).length;
  if (contentCount) {
    contentCount.textContent = `${cCount} • ${urlCount}`;
  }

  if (quoteUrlsInput && quoteUrlCount) {
    const qCount = parseLines(quoteUrlsInput.value).length;
    quoteUrlCount.textContent = `${qCount}`;
  }

  if (postLinkText && countPostLinks) {
    const lCount = parseLines(postLinkText.value).length;
    countPostLinks.textContent = `${lCount}`;
  }

  if (profilePhotoUrlsInput && countProfilePhoto) {
    if (uploadedTabProfileFiles.length > 0) {
      countProfilePhoto.textContent = uploadedTabProfileFiles.length === 1
        ? '1 File Foto'
        : `${uploadedTabProfileFiles.length} File Foto`;
    } else if (profilePhotoUrlsInput.value.trim()) {
      const uCount = parseLines(profilePhotoUrlsInput.value).length;
      countProfilePhoto.textContent = `${uCount} URL Foto`;
    } else {
      countProfilePhoto.textContent = 'Opsional';
    }
  }

  if (profileBioTextInput && countProfileBio) {
    const raw = profileBioTextInput.value;
    const lines = parseLines(raw);
    const lineCount = raw ? raw.split(/\r?\n/).length : 0;
    const chars = raw.length;
    if (profileSingleBioInput?.checked) {
      countProfileBio.textContent = chars > 0 ? `${lineCount} Baris (${chars} Karakter)` : '0 Karakter';
    } else {
      if (raw.includes('===')) {
        const entries = raw.split(/\n?\s*===\s*\n?/).filter(Boolean).length;
        countProfileBio.textContent = `${entries} Akun (${lineCount} Baris)`;
      } else {
        countProfileBio.textContent = `${lines.length} Akun (${lineCount} Baris)`;
      }
    }
  }

  if (profileLinkTextInput && countProfileLink) {
    const lines = parseLines(profileLinkTextInput.value);
    countProfileLink.textContent = profileSingleLinkInput?.checked
      ? `${profileLinkTextInput.value.trim() ? 1 : 0} Link`
      : `${lines.length} Link`;
  }
}

function updateCaptionModeUI() {
  if (!combineCaptionsInput || !captionModeDescription) return;
  if (combineCaptionsInput.checked) {
    captionModeDescription.textContent =
      'ON: semua baris digabung menjadi satu caption untuk setiap tab.';
  } else {
    captionModeDescription.textContent =
      'OFF: setiap baris dibagikan seperti biasa.';
  }
}

if (combineCaptionsInput) {
  combineCaptionsInput.addEventListener('change', () => {
    updateCaptionModeUI();
    saveAllNow();
  });
}

function updateQuotePostUI() {
  if (!enableQuotePostInput || !quoteUrlField) return;
  quoteUrlField.style.display = enableQuotePostInput.checked ? 'flex' : 'none';
}

if (enableQuotePostInput) {
  enableQuotePostInput.addEventListener('change', () => {
    updateQuotePostUI();
    saveAllNow();
  });
}

function updateAutoEditProfileUI() {
  if (!autoEditProfileInput) return;
  if (loginProfilePhotoBox) {
    loginProfilePhotoBox.style.display = autoEditProfileInput.checked ? 'flex' : 'none';
  }
  if (!autoEditProfileDesc) return;
  if (autoEditProfileInput.checked) {
    autoEditProfileDesc.textContent =
      'ON: Login + 2FA lalu otomatis ganti foto & username random.';
  } else {
    autoEditProfileDesc.textContent =
      'OFF: Hanya Login & 2FA biasa (tanpa ganti foto / username).';
  }
}

function updateProfileFilesUI() {
  if (!uploadedProfileFiles.length) {
    if (loginProfileUrlsInput) {
      loginProfileUrlsInput.placeholder = 'URL / Default';
    }
    if (loginProfileFileBtn) {
      loginProfileFileBtn.classList.remove('has-files');
      loginProfileFileBtn.title = 'Pilih file foto dari komputer';
    }
    if (btnClearProfileFiles) btnClearProfileFiles.style.display = 'none';
    return;
  }

  const label =
    uploadedProfileFiles.length === 1
      ? `File: ${uploadedProfileFiles[0].name}`
      : `${uploadedProfileFiles.length} file dipilih`;

  if (loginProfileUrlsInput) {
    loginProfileUrlsInput.placeholder = label;
  }
  if (loginProfileFileBtn) {
    loginProfileFileBtn.classList.add('has-files');
    loginProfileFileBtn.title = label;
  }
  if (btnClearProfileFiles) btnClearProfileFiles.style.display = 'inline-flex';
}

async function compressFileToDataUrl(file, maxDim = 640) {
  const bitmap = await createImageBitmap(file);
  let width = bitmap.width;
  let height = bitmap.height;
  const MAX_DIM = maxDim;
  if (width > MAX_DIM || height > MAX_DIM) {
    const ratio = Math.min(MAX_DIM / width, MAX_DIM / height);
    width = Math.max(2, Math.round(width * ratio));
    height = Math.max(2, Math.round(height * ratio));
  }
  try {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(bitmap, 0, 0, width, height);
    return canvas.toDataURL('image/jpeg', 0.9);
  } finally {
    bitmap.close();
  }
}

async function urlToCompressedDataUrl(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const blob = await res.blob();
    return await compressFileToDataUrl(blob, 640);
  } catch (e) {
    console.warn("Gagal download URL foto:", e);
    return null;
  }
}

if (loginProfileFilesInput) {
  loginProfileFilesInput.addEventListener('change', async () => {
    const files = Array.from(loginProfileFilesInput.files || []).filter(f =>
      f.type.startsWith('image/')
    );
    if (!files.length) return;

    try {
      const processed = [];
      for (const file of files) {
        const dataUrl = await compressFileToDataUrl(file);
        processed.push({ name: file.name, dataUrl });
      }
      uploadedProfileFiles = processed;
      updateProfileFilesUI();
      chrome.storage.local.set({ form_login_profile_files: uploadedProfileFiles }).catch(() => {});
      showToast(`${processed.length} foto profil siap digunakan`, 'success');
    } catch (err) {
      showToast('Gagal membaca file gambar', 'error');
    }
  });
}

if (btnClearProfileFiles) {
  btnClearProfileFiles.addEventListener('click', () => {
    uploadedProfileFiles = [];
    if (loginProfileFilesInput) loginProfileFilesInput.value = '';
    updateProfileFilesUI();
    chrome.storage.local.remove('form_login_profile_files').catch(() => {});
    showToast('File foto profil dihapus (kembali ke URL / default.jpg)', 'info');
  });
}

function updateTabProfileFilesUI() {
  if (!uploadedTabProfileFiles.length) {
    if (profilePhotoUrlsInput) {
      profilePhotoUrlsInput.placeholder = 'URL Foto (https://...) atau pilih file';
    }
    if (profilePhotoFileBtn) {
      profilePhotoFileBtn.classList.remove('has-files');
      profilePhotoFileBtn.title = 'Pilih file foto dari komputer';
    }
    if (btnClearProfilePhotoFiles) btnClearProfilePhotoFiles.style.display = 'none';
    if (profilePhotoPreview) {
      profilePhotoPreview.innerHTML = '';
      profilePhotoPreview.style.display = 'none';
    }
    updateAllCounts();
    return;
  }

  const count = uploadedTabProfileFiles.length;
  const label = count === 1 ? `1 File: ${uploadedTabProfileFiles[0].name}` : `${count} file foto dipilih`;

  if (profilePhotoUrlsInput) {
    profilePhotoUrlsInput.placeholder = label;
  }
  if (profilePhotoFileBtn) {
    profilePhotoFileBtn.classList.add('has-files');
    profilePhotoFileBtn.title = label;
  }
  if (btnClearProfilePhotoFiles) btnClearProfilePhotoFiles.style.display = 'inline-flex';

  if (profilePhotoPreview) {
    profilePhotoPreview.innerHTML = '';
    uploadedTabProfileFiles.forEach((file, index) => {
      const item = document.createElement('div');
      item.style.cssText =
        'position: relative; width: 44px; height: 44px; border-radius: 8px; overflow: hidden; border: 1px solid rgba(124, 92, 255, 0.4); flex-shrink: 0; background: var(--surface-2);';
      item.innerHTML = `<img src="${file.dataUrl}" style="width: 100%; height: 100%; object-fit: cover;" title="${file.name || 'Foto ' + (index + 1)}">`;
      profilePhotoPreview.appendChild(item);
    });
    profilePhotoPreview.style.display = 'flex';
  }

  updateAllCounts();
}

function clearTabProfileFiles() {
  uploadedTabProfileFiles = [];
  if (profilePhotoFilesInput) profilePhotoFilesInput.value = '';
  updateTabProfileFilesUI();
  chrome.storage.local.remove('form_tab_profile_files').catch(() => {});
}

if (profilePhotoFilesInput) {
  profilePhotoFilesInput.addEventListener('change', async () => {
    const files = Array.from(profilePhotoFilesInput.files || []).filter(f =>
      f.type.startsWith('image/')
    );
    if (!files.length) return;

    try {
      const processed = [];
      for (const file of files) {
        const dataUrl = await compressFileToDataUrl(file, 640);
        processed.push({ name: file.name, dataUrl });
      }
      uploadedTabProfileFiles = processed;
      updateTabProfileFilesUI();
      chrome.storage.local.set({ form_tab_profile_files: uploadedTabProfileFiles }).catch(() => {});
      showToast(`${processed.length} foto profil baru siap digunakan`, 'success');
    } catch (err) {
      showToast('Gagal membaca file gambar', 'error');
    }
  });
}

if (btnClearProfilePhotoFiles) {
  btnClearProfilePhotoFiles.addEventListener('click', () => {
    clearTabProfileFiles();
    showToast('File foto profil dihapus', 'info');
  });
}

function updatePostFilesUI() {
  if (!uploadedPostFiles.length) {
    if (urlsInput) {
      urlsInput.placeholder = 'URL Foto (https://...) atau pilih file dari komputer lewat tombol di atas';
    }
    if (postFilesBtn) {
      postFilesBtn.classList.remove('has-files');
      postFilesBtn.title = 'Pilih file foto dari komputer';
    }
    if (postFilesBtnText) {
      postFilesBtnText.textContent = 'Pilih File';
    }
    if (btnClearPostFiles) btnClearPostFiles.style.display = 'none';
    if (postFilesPreview) {
      postFilesPreview.innerHTML = '';
      postFilesPreview.style.display = 'none';
    }
    updateAllCounts();
    return;
  }

  const count = uploadedPostFiles.length;
  const label = count === 1 ? '1 Foto' : `${count} Foto`;

  if (urlsInput) {
    urlsInput.placeholder = `Menggunakan ${label} dari komputer. Klik tombol X untuk batal.`;
  }
  if (postFilesBtn) {
    postFilesBtn.classList.add('has-files');
    postFilesBtn.title = `${label} dipilih`;
  }
  if (postFilesBtnText) {
    postFilesBtnText.textContent = label;
  }
  if (btnClearPostFiles) btnClearPostFiles.style.display = 'inline-flex';

  if (postFilesPreview) {
    postFilesPreview.innerHTML = '';
    uploadedPostFiles.forEach((file, index) => {
      const item = document.createElement('div');
      item.style.cssText =
        'position: relative; width: 44px; height: 44px; border-radius: 8px; overflow: hidden; border: 1px solid rgba(124, 92, 255, 0.4); flex-shrink: 0; background: var(--surface-2);';
      item.innerHTML = `<img src="${file.dataUrl}" style="width: 100%; height: 100%; object-fit: cover;" title="${file.name || 'Foto ' + (index + 1)}">`;
      postFilesPreview.appendChild(item);
    });
    postFilesPreview.style.display = 'flex';
  }

  updateAllCounts();
}

function clearPostFiles() {
  uploadedPostFiles = [];
  if (postFilesInput) postFilesInput.value = '';
  updatePostFilesUI();
  chrome.storage.local.remove('form_post_files').catch(() => {});
}

if (postFilesInput) {
  postFilesInput.addEventListener('change', async () => {
    const files = Array.from(postFilesInput.files || []).filter(f =>
      f.type.startsWith('image/')
    );
    if (!files.length) return;

    try {
      const processed = [];
      for (const file of files) {
        const dataUrl = await compressFileToDataUrl(file, 1280);
        processed.push({ name: file.name, dataUrl });
      }
      uploadedPostFiles = processed;
      updatePostFilesUI();
      chrome.storage.local.set({ form_post_files: uploadedPostFiles }).catch(() => {});
      showToast(`${processed.length} foto post siap digunakan`, 'success');
    } catch (err) {
      showToast('Gagal membaca file gambar', 'error');
    }
  });
}

if (btnClearPostFiles) {
  btnClearPostFiles.addEventListener('click', () => {
    clearPostFiles();
    showToast('File foto post dihapus (kembali ke mode URL)', 'info');
  });
}

if (autoEditProfileInput) {
  autoEditProfileInput.addEventListener('change', () => {
    updateAutoEditProfileUI();
    saveAllNow();
  });
}

// =====================================================
// SIMPAN & PULIHKAN SEMUA INPUT (INSTAN ANTI HILANG)
// =====================================================

function getPostFormData() {
  const rawTopic = topicSelect ? topicSelect.value.trim() : '';
  const topic =
    !rawTopic ||
    rawTopic.toLowerCase() === 'tanpa topik' ||
    rawTopic === '-- tanpa topik --'
      ? ''
      : rawTopic;

  return {
    captions: captionsInput.value,
    urls: urlsInput.value,
    enableQuotePost: enableQuotePostInput?.checked ?? false,
    quoteUrls: quoteUrlsInput ? quoteUrlsInput.value : '',
    tabCount: tabCountInput.value,
    delay: delayInput ? delayInput.value : '0',
    topic,
    combineCaptions: combineCaptionsInput?.checked ?? false
  };
}

function applyPostFormData(saved) {
  if (!saved || typeof saved !== 'object') return;
  if (typeof saved.captions === 'string') captionsInput.value = saved.captions;
  if (typeof saved.urls === 'string') urlsInput.value = saved.urls;
  if (enableQuotePostInput) {
    enableQuotePostInput.checked = saved.enableQuotePost === true;
  }
  if (quoteUrlsInput && typeof saved.quoteUrls === 'string') {
    quoteUrlsInput.value = saved.quoteUrls;
  }
  if (saved.tabCount != null) tabCountInput.value = saved.tabCount;
  if (saved.delay != null && delayInput) delayInput.value = saved.delay;

  if (typeof saved.topic === 'string' && topicSelect) {
    topicSelect.value =
      saved.topic.toLowerCase() === 'tanpa topik' ||
      saved.topic === '-- tanpa topik --'
        ? ''
        : saved.topic;
  }

  if (combineCaptionsInput) {
    combineCaptionsInput.checked = saved.combineCaptions === true;
  }

  updateCaptionModeUI();
  updateQuotePostUI();
  updateAutoEditProfileUI();
  updateAllCounts();
}

function restoreAllInputs() {
  try {
    const u = localStorage.getItem(LS_KEYS.usernames);
    const s = localStorage.getItem(LS_KEYS.secrets);
    const p = localStorage.getItem(LS_KEYS.password);
    const aep = localStorage.getItem(LS_KEYS.autoEditProfile);
    const lbc = localStorage.getItem(LS_KEYS.loginBatchCount);
    const lpu = localStorage.getItem(LS_KEYS.loginProfileUrls);
    const pBio = localStorage.getItem(LS_KEYS.profileBio);
    const pLink = localStorage.getItem(LS_KEYS.profileLink);
    const pSBio = localStorage.getItem(LS_KEYS.profileSingleBio);
    const pSLink = localStorage.getItem(LS_KEYS.profileSingleLink);
    const pAllWin = localStorage.getItem(LS_KEYS.profileAllWin);
    const pTabCount = localStorage.getItem(LS_KEYS.profileTabCount);
    const pPriv = localStorage.getItem(LS_KEYS.profilePrivacy);
    const pUrls = localStorage.getItem(LS_KEYS.profilePhotoUrls);
    const postRaw = localStorage.getItem(LS_KEYS.postData);
    const linkTxt = localStorage.getItem(LS_KEYS.postLinkText);
    const linkAllWin = localStorage.getItem(LS_KEYS.postLinkAllWin);

    if (u !== null) inputUsernames.value = u;
    if (s !== null) inputSecrets.value = s;
    if (p !== null && p.length > 0) inputPassword.value = p;
    if (aep !== null && autoEditProfileInput) {
      autoEditProfileInput.checked = aep !== '0';
    }
    if (lbc !== null && loginBatchCountInput) {
      loginBatchCountInput.value = lbc;
    }
    if (lpu !== null && loginProfileUrlsInput) {
      loginProfileUrlsInput.value = lpu;
    }
    if (pBio !== null && profileBioTextInput) profileBioTextInput.value = pBio;
    if (pLink !== null && profileLinkTextInput) profileLinkTextInput.value = pLink;
    if (pSBio !== null && profileSingleBioInput) profileSingleBioInput.checked = pSBio !== '0';
    if (pSLink !== null && profileSingleLinkInput) profileSingleLinkInput.checked = pSLink !== '0';
    if (pAllWin !== null && profileAllWindowsInput) profileAllWindowsInput.checked = pAllWin === '1';
    if (pTabCount !== null && profileTabCountInput) profileTabCountInput.value = pTabCount;
    if (pPriv !== null && profilePrivacySelect) profilePrivacySelect.value = pPriv;
    if (pUrls !== null && profilePhotoUrlsInput) profilePhotoUrlsInput.value = pUrls;
    if (linkTxt !== null && postLinkText) postLinkText.value = linkTxt;
    if (linkAllWin !== null && postLinkAllWindows) {
      postLinkAllWindows.checked = linkAllWin === '1';
    }

    if (postRaw) {
      applyPostFormData(JSON.parse(postRaw));
    }
  } catch (_) {}

  updateCaptionModeUI();
  updateQuotePostUI();
  updateAutoEditProfileUI();
  updateAllCounts();

  try {
    chrome.storage.local.get(
      [
        'form_usernames',
        'form_secrets',
        'form_password',
        'form_login_profile_urls',
        'form_login_profile_files',
        'form_tab_profile_urls',
        'form_tab_profile_files',
        'form_profile_privacy',
        'form_post_files',
        'form_post_link_text',
        POST_STORAGE_KEY
      ],
      data => {
        if (!inputUsernames.value && typeof data?.form_usernames === 'string') {
          inputUsernames.value = data.form_usernames;
        }
        if (!inputSecrets.value && typeof data?.form_secrets === 'string') {
          inputSecrets.value = data.form_secrets;
        }
        if (typeof data?.form_password === 'string' && data.form_password) {
          inputPassword.value = data.form_password;
        }
        if (
          loginProfileUrlsInput &&
          !loginProfileUrlsInput.value &&
          typeof data?.form_login_profile_urls === 'string'
        ) {
          loginProfileUrlsInput.value = data.form_login_profile_urls;
        }
        if (Array.isArray(data?.form_login_profile_files) && data.form_login_profile_files.length) {
          uploadedProfileFiles = data.form_login_profile_files;
          updateProfileFilesUI();
        }
        if (
          profilePhotoUrlsInput &&
          !profilePhotoUrlsInput.value &&
          typeof data?.form_tab_profile_urls === 'string'
        ) {
          profilePhotoUrlsInput.value = data.form_tab_profile_urls;
        }
        if (Array.isArray(data?.form_tab_profile_files) && data.form_tab_profile_files.length) {
          uploadedTabProfileFiles = data.form_tab_profile_files;
          updateTabProfileFilesUI();
        }
        if (
          profilePrivacySelect &&
          typeof data?.form_profile_privacy === 'string' &&
          data.form_profile_privacy
        ) {
          profilePrivacySelect.value = data.form_profile_privacy;
        }
        if (Array.isArray(data?.form_post_files) && data.form_post_files.length) {
          uploadedPostFiles = data.form_post_files;
          updatePostFilesUI();
        }
        if (
          postLinkText &&
          !postLinkText.value &&
          typeof data?.form_post_link_text === 'string'
        ) {
          postLinkText.value = data.form_post_link_text;
        }
        if (
          profileBioTextInput &&
          !profileBioTextInput.value &&
          typeof data?.form_profile_bio === 'string'
        ) {
          profileBioTextInput.value = data.form_profile_bio;
        }
        if (
          profileLinkTextInput &&
          !profileLinkTextInput.value &&
          typeof data?.form_profile_link === 'string'
        ) {
          profileLinkTextInput.value = data.form_profile_link;
        }
        if (!captionsInput.value && !urlsInput.value && data?.[POST_STORAGE_KEY]) {
          applyPostFormData(data[POST_STORAGE_KEY]);
        }
        updateAllCounts();
      }
    );
  } catch (_) {}
}

function saveAllNow() {
  updateAllCounts();
  const postData = getPostFormData();

  try {
    localStorage.setItem(LS_KEYS.usernames, inputUsernames.value);
    localStorage.setItem(LS_KEYS.secrets, inputSecrets.value);
    localStorage.setItem(LS_KEYS.password, inputPassword.value);
    if (autoEditProfileInput) {
      localStorage.setItem(
        LS_KEYS.autoEditProfile,
        autoEditProfileInput.checked ? '1' : '0'
      );
    }
    if (loginBatchCountInput) {
      localStorage.setItem(LS_KEYS.loginBatchCount, loginBatchCountInput.value);
    }
    if (loginProfileUrlsInput) {
      localStorage.setItem(LS_KEYS.loginProfileUrls, loginProfileUrlsInput.value);
    }
    if (profileBioTextInput) {
      localStorage.setItem(LS_KEYS.profileBio, profileBioTextInput.value);
    }
    if (profileLinkTextInput) {
      localStorage.setItem(LS_KEYS.profileLink, profileLinkTextInput.value);
    }
    if (profileSingleBioInput) {
      localStorage.setItem(LS_KEYS.profileSingleBio, profileSingleBioInput.checked ? '1' : '0');
    }
    if (profileSingleLinkInput) {
      localStorage.setItem(LS_KEYS.profileSingleLink, profileSingleLinkInput.checked ? '1' : '0');
    }
    if (profileAllWindowsInput) {
      localStorage.setItem(LS_KEYS.profileAllWin, profileAllWindowsInput.checked ? '1' : '0');
    }
    if (profileTabCountInput) {
      localStorage.setItem(LS_KEYS.profileTabCount, profileTabCountInput.value);
    }
    if (profilePrivacySelect) {
      localStorage.setItem(LS_KEYS.profilePrivacy, profilePrivacySelect.value);
    }
    if (profilePhotoUrlsInput) {
      localStorage.setItem(LS_KEYS.profilePhotoUrls, profilePhotoUrlsInput.value);
    }
    localStorage.setItem(LS_KEYS.postData, JSON.stringify(postData));
    if (postLinkText) {
      localStorage.setItem(LS_KEYS.postLinkText, postLinkText.value);
    }
    if (postLinkAllWindows) {
      localStorage.setItem(
        LS_KEYS.postLinkAllWin,
        postLinkAllWindows.checked ? '1' : '0'
      );
    }
  } catch (_) {}

  try {
    chrome.storage.local.set({
      form_usernames: inputUsernames.value,
      form_secrets: inputSecrets.value,
      form_password: inputPassword.value,
      form_login_batch_count: loginBatchCountInput ? loginBatchCountInput.value : '',
      form_login_profile_urls: loginProfileUrlsInput ? loginProfileUrlsInput.value : '',
      form_tab_profile_urls: profilePhotoUrlsInput ? profilePhotoUrlsInput.value : '',
      form_profile_privacy: profilePrivacySelect ? profilePrivacySelect.value : 'keep',
      form_profile_bio: profileBioTextInput ? profileBioTextInput.value : '',
      form_profile_link: profileLinkTextInput ? profileLinkTextInput.value : '',
      form_profile_single_bio: profileSingleBioInput ? profileSingleBioInput.checked : true,
      form_profile_single_link: profileSingleLinkInput ? profileSingleLinkInput.checked : true,
      form_profile_tab_count: profileTabCountInput ? profileTabCountInput.value : '',
      form_post_link_text: postLinkText ? postLinkText.value : '',
      [POST_STORAGE_KEY]: {
        ...postData,
        savedAt: Date.now()
      }
    });
  } catch (_) {}
}

restoreAllInputs();
switchTab(activeTabName);

const allInputs = [
  inputUsernames,
  inputSecrets,
  inputPassword,
  loginBatchCountInput,
  loginProfileUrlsInput,
  profilePhotoUrlsInput,
  profilePrivacySelect,
  profileBioTextInput,
  profileSingleBioInput,
  profileLinkTextInput,
  profileSingleLinkInput,
  profileAllWindowsInput,
  profileTabCountInput,
  captionsInput,
  urlsInput,
  enableQuotePostInput,
  quoteUrlsInput,
  tabCountInput,
  delayInput,
  topicSelect,
  postLinkText,
  postLinkAllWindows
];

['input', 'change', 'keyup', 'paste', 'blur'].forEach(evt => {
  allInputs.forEach(el => {
    if (el) el.addEventListener(evt, () => setTimeout(saveAllNow, 0));
  });
});

window.addEventListener('visibilitychange', saveAllNow);
window.addEventListener('pagehide', saveAllNow);
window.addEventListener('beforeunload', saveAllNow);

// Sinkronisasi antar jendela Pin & Popup
window.addEventListener('storage', e => {
  if (e.key === LS_KEYS.usernames && e.newValue !== null) {
    inputUsernames.value = e.newValue;
  } else if (e.key === LS_KEYS.secrets && e.newValue !== null) {
    inputSecrets.value = e.newValue;
  } else if (e.key === LS_KEYS.password && e.newValue !== null) {
    inputPassword.value = e.newValue;
  } else if (e.key === LS_KEYS.postLinkText && e.newValue !== null && postLinkText) {
    postLinkText.value = e.newValue;
  } else if (e.key === LS_KEYS.postData && e.newValue) {
    try {
      applyPostFormData(JSON.parse(e.newValue));
    } catch (_) {}
  }
  updateAllCounts();
});

// Tombol Pin
if (btnPin) {
  btnPin.addEventListener('click', () => {
    saveAllNow();
    chrome.windows.create({
      url: chrome.runtime.getURL('popup.html?pinned=1'),
      type: 'popup',
      width: 440,
      height: 600
    });
    window.close();
  });
}

// Tombol Reset (mengosongkan panel yang sedang dibuka)
if (btnClear) {
  btnClear.addEventListener('click', () => {
    if (activeTabName === 'login') {
      inputUsernames.value = '';
      inputSecrets.value = '';
      saveAllNow();
      showToast('Daftar Username & Secret Key dikosongkan', 'info');
    } else if (activeTabName === 'profile') {
      if (profileBioTextInput) profileBioTextInput.value = '';
      if (profileLinkTextInput) profileLinkTextInput.value = '';
      if (profilePhotoUrlsInput) profilePhotoUrlsInput.value = '';
      clearTabProfileFiles();
      if (profilePrivacySelect) profilePrivacySelect.value = 'keep';
      saveAllNow();
      showToast('Form Profil dikosongkan', 'info');
    } else if (activeTabName === 'post') {
      captionsInput.value = '';
      urlsInput.value = '';
      if (quoteUrlsInput) quoteUrlsInput.value = '';
      clearPostFiles();
      saveAllNow();
      showToast('Caption & Foto Post dikosongkan', 'info');
    } else if (activeTabName === 'link') {
      if (postLinkText) postLinkText.value = '';
      saveAllNow();
      showToast('Teks Post Link dikosongkan', 'info');
    } else if (activeTabName === 'copy') {
      refreshOpenTabUrls();
      showToast('Daftar URL dimuat ulang', 'info');
    }
  });
}

// =====================================================
// HELPER AMBIL TAB BROWSER
// =====================================================

async function getTargetTabs(allWindows = false) {
  if (allWindows) {
    const tabs = await chrome.tabs.query({ windowType: 'normal' });
    return tabs.filter(t => t.url && !t.url.startsWith('chrome://'));
  }

  if (!isPinnedWindow) {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    return tabs.filter(t => !t.url || !t.url.startsWith('chrome://'));
  }

  const normalWindows = await chrome.windows.getAll({
    populate: true,
    windowTypes: ['normal']
  });
  if (!normalWindows.length) return [];
  const focused = normalWindows.find(w => w.focused) || normalWindows[0];
  return (focused.tabs || []).filter(
    t => !t.url || !t.url.startsWith('chrome://')
  );
}

// =====================================================
// PANEL 1: EKSEKUSI AUTO LOGIN + 2FA + AUTO EDIT PROFIL
// =====================================================

btnLogin.addEventListener('click', async () => {
  saveAllNow();

  const password = inputPassword.value.trim();
  const usernames = parseLines(inputUsernames.value);
  const secrets = parseLines(inputSecrets.value);

  const totalAccounts = Math.max(usernames.length, secrets.length);

  if (totalAccounts === 0) {
    showToast('Masukkan daftar Username dan Secret Key', 'error');
    return;
  }

  if (usernames.length > 0 && !password) {
    showToast('Password wajib diisi', 'error');
    return;
  }

  const allTabs = await getTargetTabs(false);

  // Filter tab Threads (prioritaskan tab threads.com / threads.net)
  const threadsTabs = allTabs.filter(tab => {
    const url = String(tab.url || '');
    return /threads\.(com|net)/i.test(url);
  });

  const tabList = threadsTabs.length ? threadsTabs : allTabs;

  // Ambil state tab yang sudah tercatat login di storage (tab_username_<id> dan tab_logged_in_<id>)
  const storageKeys = tabList.flatMap(t => [`tab_username_${t.id}`, `tab_logged_in_${t.id}`]);
  const storedData = await new Promise(resolve => {
    try {
      chrome.storage.local.get(storageKeys, data => resolve(data || {}));
    } catch (_) {
      resolve({});
    }
  });

  // Filter hanya tab yang BELUM login
  const tabChecks = await Promise.all(
    tabList.map(tab => {
      const url = String(tab.url || '');

      // 1. Jika URL sudah berada di /archive, /@username, /notifications, /activity -> PASTI SUDAH LOGIN
      if (/threads\.(com|net)\/(archive|@[^/?#]+|notifications|activity|search)(\/|\?|#|$)/i.test(url)) {
        return Promise.resolve({ tab, needsLogin: false });
      }

      // 2. Jika di storage sudah tercatat tab ini sudah login / ganti username -> PASTI SUDAH LOGIN
      if (storedData[`tab_username_${tab.id}`] || storedData[`tab_logged_in_${tab.id}`]) {
        return Promise.resolve({ tab, needsLogin: false });
      }

      // 3. Jika URL jelas halaman login (/login) -> BUTUH LOGIN
      if (/\/login(\/|\?|#|$)/i.test(url)) {
        return Promise.resolve({ tab, needsLogin: true });
      }

      // 4. Cek ke content script auto-login.js (DOM form login, cookie session, icon)
      return new Promise(resolve => {
        const timer = setTimeout(() => {
          // Timeout jika tab di background
          resolve({ tab, needsLogin: true });
        }, 1200);

        try {
          chrome.tabs.sendMessage(
            tab.id,
            { action: 'checkNeedsLogin' },
            res => {
              clearTimeout(timer);
              if (chrome.runtime.lastError || !res) {
                resolve({ tab, needsLogin: true });
                return;
              }
              resolve({ tab, needsLogin: res.needsLogin !== false });
            }
          );
        } catch (_) {
          clearTimeout(timer);
          resolve({ tab, needsLogin: true });
        }
      });
    })
  );

  const tabs = tabChecks.filter(item => item.needsLogin).map(item => item.tab);

  if (tabs.length === 0) {
    showToast('Semua tab sudah login! Buka tab Threads baru untuk login akun berikutnya.', 'info');
    return;
  }

  // Tentukan batas tab (batch) jika diatur user
  const batchLimitVal = parseInt(loginBatchCountInput ? loginBatchCountInput.value : '', 10);
  const hasBatchLimit = !isNaN(batchLimitVal) && batchLimitVal > 0;
  const accountsToRun = hasBatchLimit
    ? Math.min(totalAccounts, tabs.length, batchLimitVal)
    : Math.min(totalAccounts, tabs.length);

  const targetTabs = tabs.slice(0, accountsToRun);

  // Jika akun di antrean lebih banyak daripada tab yang dijalankan pada batch ini,
  // jalankan untuk targetTabs dan geser antrean textarea (hapus akun yang sudah diluncurkan)
  const isBatchedRun = totalAccounts > targetTabs.length;
  let remainingUsernames = usernames;
  let remainingSecrets = secrets;

  if (isBatchedRun) {
    remainingUsernames = usernames.slice(targetTabs.length);
    remainingSecrets = secrets.slice(targetTabs.length);
    inputUsernames.value = remainingUsernames.join('\n');
    inputSecrets.value = remainingSecrets.join('\n');
    saveAllNow();
  }

  btnLogin.disabled = true;
  btnLogin.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Menjalankan ${targetTabs.length} Tab...`;

  const jobs = {};
  const now = Date.now();
  const autoEditProfile = autoEditProfileInput
    ? autoEditProfileInput.checked
    : true;

  targetTabs.forEach((tab, index) => {
    jobs[tab.id] = {
      identifier: usernames[index] || '',
      password: password,
      secret: secrets[index] || '',
      autoEditProfile,
      accountIndex: index,
      stage: usernames[index] ? 'LOGIN' : 'WAIT_2FA',
      startedAt: now
    };
  });

  await new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'setTabJobsBulk', jobs }, () => resolve());
  });

  const results = await Promise.all(
    targetTabs.map((tab, index) => {
      return new Promise(resolve => {
        chrome.tabs.sendMessage(
          tab.id,
          {
            action: 'startAutoFlow',
            job: jobs[tab.id]
          },
          response => {
            if (chrome.runtime.lastError || !response || !response.ok) {
              console.warn(
                `Tab ${index + 1}:`,
                chrome.runtime.lastError?.message || 'Belum merespons'
              );
              resolve(false);
              return;
            }
            resolve(true);
          }
        );
      });
    })
  );

  const startedCount = results.filter(Boolean).length;

  btnLogin.disabled = false;
  btnLogin.innerHTML = '<i class="fas fa-bolt"></i> Jalankan Login';

  if (startedCount > 0) {
    const sisaText = isBatchedRun ? ` (sisa ${remainingUsernames.length} akun di antrean)` : '';
    showToast(
      `Alur otomatis berjalan di ${startedCount} tab!${sisaText}`,
      'success'
    );
  } else {
    showToast(
      'Job disimpan. Muat ulang (refresh) tab Threads jika belum berjalan.',
      'info'
    );
  }
});

// =====================================================
// PANEL 2: EKSEKUSI EDIT PROFIL (BIO & LINK MULTI-TAB)
// =====================================================

function setProfileStatus(text, kind = '') {
  if (profileStatusText) profileStatusText.textContent = text;
  if (profileStatusBar) {
    profileStatusBar.classList.remove('running', 'success', 'error');
    if (kind) profileStatusBar.classList.add(kind);
  }
  if (profileStatusIndicator) {
    profileStatusIndicator.classList.remove('running', 'success', 'error');
    if (kind) profileStatusIndicator.classList.add(kind);
  }
}

if (btnApplyBioLink) {
  btnApplyBioLink.addEventListener('click', async () => {
    saveAllNow();

    const isSingleBio = profileSingleBioInput ? profileSingleBioInput.checked : true;
    const isSingleLink = profileSingleLinkInput ? profileSingleLinkInput.checked : true;

    const rawBio = profileBioTextInput ? profileBioTextInput.value : '';
    const rawLink = profileLinkTextInput ? profileLinkTextInput.value : '';
    const privacyVal = profilePrivacySelect ? profilePrivacySelect.value : 'keep';

    const hasBio = Boolean(rawBio.trim());
    const hasLink = Boolean(rawLink.trim());
    const hasPhoto = uploadedTabProfileFiles.length > 0 || Boolean(profilePhotoUrlsInput?.value.trim());

    if (!hasBio && !hasLink && !hasPhoto) {
      showToast('Masukkan Foto, Bio, atau Link yang ingin diterapkan', 'error');
      return;
    }

    const allTabs = await getTargetTabs(profileAllWindowsInput?.checked ?? false);
    const threadsTabs = allTabs.filter(tab => {
      const url = String(tab.url || '');
      return /threads\.(com|net)/i.test(url);
    });

    if (threadsTabs.length === 0) {
      showToast('Tidak ada tab Threads yang terbuka!', 'error');
      setProfileStatus('Tidak ada tab Threads yang ditemukan.', 'error');
      return;
    }

    const limitVal = parseInt(profileTabCountInput ? profileTabCountInput.value : '', 10);
    const maxTabs = (!isNaN(limitVal) && limitVal > 0)
      ? Math.min(threadsTabs.length, limitVal)
      : threadsTabs.length;

    const targetTabs = threadsTabs.slice(0, maxTabs);

    btnApplyBioLink.disabled = true;
    btnApplyBioLink.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Memproses ${targetTabs.length} Tab...`;
    setProfileStatus(`Sedang memproses ${targetTabs.length} tab secara serentak...`, 'running');

    // Persiapkan bio per akun
    let bioEntries = [];
    if (hasBio) {
      if (isSingleBio) {
        const normalizedBio = rawBio.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
        bioEntries = [normalizedBio];
      } else {
        if (rawBio.includes('===')) {
          bioEntries = rawBio
            .split(/\n?\s*===\s*\n?/)
            .map(b => b.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim())
            .filter(Boolean);
        } else {
          bioEntries = parseLines(rawBio);
        }
      }
    }

    // Persiapkan link per akun
    let linkEntries = [];
    if (hasLink) {
      if (isSingleLink) {
        linkEntries = [rawLink.trim()];
      } else {
        linkEntries = parseLines(rawLink);
      }
    }

    // Persiapkan URL foto (jika ada)
    const photoUrls = (profilePhotoUrlsInput && profilePhotoUrlsInput.value.trim())
      ? parseLines(profilePhotoUrlsInput.value)
      : [];

    // Unduh foto URL secara paralel jika ada yang berupa URL eksternal
    const preparedPhotos = await Promise.all(
      targetTabs.map(async (_, i) => {
        if (uploadedTabProfileFiles.length > 0) {
          return uploadedTabProfileFiles[i % uploadedTabProfileFiles.length].dataUrl;
        } else if (photoUrls.length > 0) {
          const u = photoUrls[i % photoUrls.length];
          if (u.startsWith('data:')) return u;
          return await urlToCompressedDataUrl(u);
        }
        return undefined;
      })
    );

    // Jalankan update profil SECARA SERENTAK (PARALEL) di semua tab
    const tasks = targetTabs.map(async (tab, i) => {
      if (i > 0) {
        await sleep(i * 600);
      }
      const bio = hasBio
        ? (isSingleBio ? bioEntries[0] : (bioEntries[i % bioEntries.length] || ''))
        : undefined;

      const link = hasLink
        ? (isSingleLink ? linkEntries[0] : (linkEntries[i % linkEntries.length] || ''))
        : undefined;

      const photoDataUrl = preparedPhotos[i];

      return new Promise(resolve => {
        const timeout = setTimeout(() => resolve({ ok: false, error: 'Timeout' }), 35000);
        chrome.tabs.sendMessage(
          tab.id,
          {
            action: 'updateProfileBioLink',
            bio,
            link,
            photoDataUrl
          },
          response => {
            clearTimeout(timeout);
            if (chrome.runtime.lastError) {
              let msg = chrome.runtime.lastError.message || 'Error koneksi tab';
              if (/message port closed|receiving end does not exist/i.test(msg)) {
                msg = 'Tab Threads perlu di-refresh (F5) terlebih dahulu setelah ekstensi di-reload.';
              }
              resolve({ ok: false, error: msg });
              return;
            }
            resolve(response || { ok: false, error: 'Respons kosong dari tab' });
          }
        );
      });
    });

    const results = await Promise.all(tasks);

    let successCount = 0;
    let failCount = 0;
    let lastErrorMsg = '';

    results.forEach((res, i) => {
      if (res && res.ok) {
        successCount++;
      } else {
        failCount++;
        lastErrorMsg = res?.error || 'Gagal update profil';
        console.warn(`[Profile Update] Tab ${targetTabs[i].id} gagal:`, res?.error);
      }
    });

    btnApplyBioLink.disabled = false;
    btnApplyBioLink.innerHTML = '<i class="fas fa-bolt"></i> Simpan Profil (Serentak Semua Tab)';

    if (successCount > 0) {
      const failInfo = failCount > 0 ? `, Gagal: ${failCount} (${lastErrorMsg})` : '';
      setProfileStatus(`Selesai! Berhasil: ${successCount} tab${failInfo}.`, failCount > 0 ? 'running' : 'success');
      showToast(`Berhasil menerapkan profil di ${successCount} tab Threads!`, 'success');
    } else {
      setProfileStatus(`Gagal mengupdate profil: ${lastErrorMsg || 'Cek konsol tab'}`, 'error');
      showToast(lastErrorMsg || 'Gagal mengupdate profil di tab Threads', 'error');
    }
  });
}

// =====================================================
// AKSI TERPISAH: TERAPKAN PRIVASI AKUN (MODE PRIVAT / PUBLIK)
// =====================================================

if (btnApplyPrivacy) {
  btnApplyPrivacy.addEventListener('click', async () => {
    saveAllNow();
    const privacyVal = profilePrivacySelect ? profilePrivacySelect.value : 'private';

    const allTabs = await getTargetTabs(profileAllWindowsInput?.checked ?? false);
    const threadsTabs = allTabs.filter(tab => {
      const url = String(tab.url || '');
      return /threads\.(com|net)/i.test(url);
    });

    if (threadsTabs.length === 0) {
      showToast('Tidak ada tab Threads yang terbuka!', 'error');
      setProfileStatus('Tidak ada tab Threads yang ditemukan.', 'error');
      return;
    }

    const limitVal = parseInt(profileTabCountInput ? profileTabCountInput.value : '', 10);
    const maxTabs = (!isNaN(limitVal) && limitVal > 0)
      ? Math.min(threadsTabs.length, limitVal)
      : threadsTabs.length;

    const targetTabs = threadsTabs.slice(0, maxTabs);

    btnApplyPrivacy.disabled = true;
    btnApplyPrivacy.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Mengubah ${targetTabs.length} Tab...`;
    setProfileStatus(`Sedang mengubah privasi di ${targetTabs.length} tab secara serentak...`, 'running');

    try {
      // Eksekusi privasi secara serentak (paralel)
      const tasks = targetTabs.map(async (tab, i) => {
        if (i > 0) {
          await sleep(i * 600);
        }

        return new Promise(resolve => {
          const timeout = setTimeout(() => resolve({ ok: false, error: 'Timeout' }), 25000);
          chrome.tabs.sendMessage(
            tab.id,
            {
              action: 'updateProfilePrivacy',
              privacy: privacyVal
            },
            response => {
              clearTimeout(timeout);
              if (chrome.runtime.lastError) {
                let msg = chrome.runtime.lastError.message || 'Error koneksi tab';
                if (/message port closed|receiving end does not exist/i.test(msg)) {
                  msg = 'Tab Threads perlu di-refresh (F5) terlebih dahulu setelah ekstensi di-reload.';
                }
                resolve({ ok: false, error: msg });
                return;
              }
              resolve(response || { ok: false, error: 'Respons kosong dari tab' });
            }
          );
        });
      });

      const results = await Promise.all(tasks);

      let successCount = 0;
      let failCount = 0;
      let lastErrorMsg = '';

      results.forEach((res, i) => {
        if (res && res.ok) {
          successCount++;
        } else {
          failCount++;
          lastErrorMsg = res?.error || 'Gagal update privasi';
          console.warn(`[Privacy Update] Tab ${targetTabs[i].id} gagal:`, res?.error);
        }
      });

      if (successCount > 0) {
        const failInfo = failCount > 0 ? `, Gagal: ${failCount} (${lastErrorMsg})` : '';
        setProfileStatus(`Selesai! Privasi diterapkan di ${successCount} tab${failInfo}.`, failCount > 0 ? 'running' : 'success');
        showToast(`Privasi ${privacyVal === 'private' ? 'Privat 🔒' : 'Publik 🌐'} berhasil diterapkan di ${successCount} tab!`, 'success');
      } else {
        setProfileStatus(`Gagal menerapkan privasi: ${lastErrorMsg || 'Cek konsol tab'}`, 'error');
        showToast(lastErrorMsg || 'Gagal menerapkan privasi di tab Threads', 'error');
      }
    } catch (err) {
      console.error('[Privacy Update] Exception:', err);
      setProfileStatus('Error: ' + (err?.message || String(err)), 'error');
      showToast(err?.message || 'Error eksekusi privasi', 'error');
    } finally {
      btnApplyPrivacy.disabled = false;
      btnApplyPrivacy.innerHTML = '<i class="fas fa-lock"></i> Terapkan Privasi';
    }
  });
}

// =====================================================
// PANEL 3: EKSEKUSI AUTO POST FOTO (MULTI-TAB POSTER)
// =====================================================

function setPostStatus(text) {
  if (statusEl) statusEl.textContent = text;
  const bar = statusEl ? statusEl.closest('.status-bar') : null;

  if (statusIndicator) {
    statusIndicator.classList.remove('running', 'success', 'error');
  }
  if (bar) {
    bar.classList.remove('running', 'success', 'error');
  }

  let state = '';
  if (/error|gagal|dihentikan/i.test(text)) {
    state = 'error';
  } else if (/^selesai$/i.test(text.trim()) || /selesai|berhasil/i.test(text)) {
    state = 'success';
  } else if (/proses|menyiapkan|memposting|berjalan/i.test(text)) {
    state = 'running';
  }

  if (state) {
    if (statusIndicator) statusIndicator.classList.add(state);
    if (bar) bar.classList.add(state);
  }

  chrome.storage.local.set({
    threads_popup_status_v1: {
      text: String(text),
      savedAt: Date.now()
    }
  }).catch(() => {});
}

async function restorePostStatus() {
  try {
    const data = await chrome.storage.local.get('threads_popup_status_v1');
    const saved = data?.threads_popup_status_v1;
    if (saved?.text) {
      setPostStatus(saved.text);
    }
  } catch (_) {}
}

restorePostStatus();

startBtn.addEventListener('click', async () => {
  saveAllNow();

  const captions = parseLines(captionsInput.value);
  const fileUrls = (uploadedPostFiles || []).map(f => f.dataUrl).filter(Boolean);
  const urls = fileUrls.length > 0 ? fileUrls : parseLines(urlsInput.value);

  const tabCount = Math.max(
    1,
    Math.min(50, Number(tabCountInput.value) || 1)
  );

  const delay = delayInput
    ? Math.max(0, Math.min(60000, Number(delayInput.value) || 0))
    : 0;

  const rawTopic = topicSelect ? topicSelect.value.trim() : '';
  const topic =
    !rawTopic ||
    rawTopic.toLowerCase() === 'tanpa topik' ||
    rawTopic === '-- tanpa topik --'
      ? ''
      : rawTopic;

  const combineCaptions = combineCaptionsInput?.checked === true;
  const finalCaptions = combineCaptions ? [captions.join('\n')] : captions;

  const enableQuote = enableQuotePostInput?.checked === true;
  const quoteUrls = enableQuote && quoteUrlsInput ? parseLines(quoteUrlsInput.value) : [];

  if (enableQuote && !quoteUrls.length) {
    setPostStatus('Gagal');
    showToast('Isi URL postingan yang ingin dikutip', 'error');
    return;
  }

  if (!captions.length && !urls.length && !quoteUrls.length) {
    setPostStatus('Gagal');
    showToast('Isi minimal caption, foto, atau URL kutipan', 'error');
    return;
  }

  setPostStatus('Proses...');

  try {
    const result = await chrome.runtime.sendMessage({
      action: 'START',
      captions: finalCaptions,
      combineCaptions,
      urls,
      quoteUrls,
      tabCount,
      delay,
      topic,
      useProfilePhoto: false,
      profilePhotoUrl: ''
    });

    setPostStatus(result?.message || 'Proses...');
  } catch (error) {
    setPostStatus('Gagal');
  }
});

stopBtn.addEventListener('click', async () => {
  try {
    await chrome.runtime.sendMessage({
      action: 'STOP'
    });
    setPostStatus('Dihentikan');
  } catch (error) {
    setPostStatus('Gagal');
  }
});

chrome.runtime.onMessage.addListener(message => {
  if (message?.action === 'PROGRESS') {
    setPostStatus(message.text);
  }
});

// =====================================================
// PANEL 4: POST LINK PER TAB (VIA API INTERNAL)
// =====================================================

function setLinkStatus(msg, state = '') {
  if (!postLinkStatus) return;
  postLinkStatus.textContent = msg;
  const bar = postLinkStatus.closest('.status-bar');
  const dot = bar ? bar.querySelector('.status-dot') : null;

  if (bar) bar.classList.remove('running', 'success', 'error');
  if (dot) dot.classList.remove('running', 'success', 'error');

  if (state) {
    if (bar) bar.classList.add(state);
    if (dot) dot.classList.add(state);
  }
}

if (btnApplyPostLink) {
  btnApplyPostLink.addEventListener('click', async () => {
    saveAllNow();

    const lines = (postLinkText.value || '')
      .replace(/\r\n?/g, '\n')
      .split('\n')
      .map(l => l.replace(/\s+/g, ' ').trim())
      .filter(Boolean);

    if (lines.length === 0) {
      setLinkStatus('Gagal', 'error');
      showToast('Isi teks / link postingan dulu', 'error');
      return;
    }

    btnApplyPostLink.disabled = true;
    setLinkStatus('Proses...', 'running');

    try {
      const targetTabs = await getTargetTabs(postLinkAllWindows?.checked);
      const n = Math.min(lines.length, targetTabs.length);

      const results = await Promise.all(
        targetTabs.slice(0, n).map(tab =>
          chrome.tabs
            .sendMessage(tab.id, {
              action: 'POST_LINK',
              text: lines[targetTabs.indexOf(tab)]
            })
            .catch(err => ({ ok: false, error: err?.message || String(err) }))
        )
      );

      const sentCount = results.filter(r => r && r.ok && r.sent).length;

      if (sentCount > 0) {
        setLinkStatus('Selesai', 'success');
      } else {
        setLinkStatus('Gagal', 'error');
      }
    } catch (err) {
      setLinkStatus('Gagal', 'error');
    } finally {
      btnApplyPostLink.disabled = false;
    }
  });
}

// Fungsi diinjeksi ke halaman Threads untuk Post Link
function fillComposeBox(text) {
  const EDITOR_SELECTOR =
    'div[contenteditable="true"][data-lexical-editor="true"]';

  const allEditors = () =>
    Array.from(document.querySelectorAll(EDITOR_SELECTOR));

  const findNewThreadButton = () => {
    const elements = Array.from(
      document.querySelectorAll('[role="button"]')
    );

    return elements.find(el => {
      const label = (
        el.innerText ||
        el.textContent ||
        ''
      ).trim();

      return label === 'Utas baru';
    });
  };

  const extractUrls = value => {
    const matches = value.match(/https?:\/\/[^\s<>"']+/gi) || [];
    return [...new Set(matches)].map(url =>
      url.replace(/[),.!?;:]+$/, '')
    );
  };

  const type = (box, value) => {
    if (!box || !box.isConnected) return false;

    box.focus();

    const selection = window.getSelection();
    const range = document.createRange();

    range.selectNodeContents(box);
    selection.removeAllRanges();
    selection.addRange(range);

    document.execCommand('delete', false, null);
    document.execCommand('insertText', false, value);

    return true;
  };

  const removeUrlsFromCaption = (box, urls) => {
    if (!box || !box.isConnected || !urls.length) return false;

    const currentText = box.innerText || box.textContent || '';
    let updatedText = currentText;

    for (const url of urls) {
      const escaped = url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      updatedText = updatedText.replace(new RegExp(escaped, 'gi'), '');
    }

    updatedText = updatedText
      .replace(/[ \t]+\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    if (updatedText === currentText.trim()) return false;

    return type(box, updatedText);
  };

  const hasLinkPreview = (box, urls) => {
    if (!box || !box.isConnected || !urls.length) return false;

    const composer =
      box.closest('[role="dialog"]') ||
      box.closest('form') ||
      box.parentElement?.parentElement?.parentElement ||
      box.parentElement;

    if (!composer) return false;

    const candidates = Array.from(
      composer.querySelectorAll('a[href], img[src], video, [role="link"]')
    ).filter(el => !box.contains(el));

    return candidates.some(el => {
      const href = el.href || el.getAttribute('href') || '';
      const src = el.src || el.getAttribute('src') || '';
      const content = (
        el.innerText ||
        el.textContent ||
        el.getAttribute('aria-label') ||
        ''
      ).trim();

      return urls.some(url => {
        try {
          const target = new URL(url);
          const link = href ? new URL(href, location.href) : null;

          if (
            link &&
            link.hostname === target.hostname &&
            link.pathname === target.pathname
          ) {
            return true;
          }

          return (
            Boolean(content) &&
            content.includes(target.hostname) &&
            Boolean(src || href)
          );
        } catch {
          return false;
        }
      });
    });
  };

  const btn = findNewThreadButton();

  if (!btn) {
    console.warn("[PostLink] Tombol 'Utas baru' tidak ditemukan.");
    return;
  }

  const before = new Set(allEditors());
  btn.click();

  let attempts = 0;

  const openInterval = setInterval(() => {
    attempts++;

    const current = allEditors();
    const fresh = current.find(el => !before.has(el));

    let editor = fresh;

    if (!editor && before.size === 0 && current.length > 0) {
      editor = current[current.length - 1];
    }

    if (editor) {
      clearInterval(openInterval);

      setTimeout(() => {
        if (!type(editor, text)) return;

        const urls = extractUrls(text);
        if (urls.length === 0) return;

        let previewAttempts = 0;

        const previewInterval = setInterval(() => {
          previewAttempts++;

          if (!editor.isConnected) {
            clearInterval(previewInterval);
            return;
          }

          if (hasLinkPreview(editor, urls)) {
            clearInterval(previewInterval);

            setTimeout(() => {
              if (!editor.isConnected) return;
              removeUrlsFromCaption(editor, urls);
            }, 1000);

            return;
          }

          if (previewAttempts >= 150) {
            clearInterval(previewInterval);
          }
        }, 200);
      }, 250);

      return;
    }

    if (attempts > 25) {
      clearInterval(openInterval);

      if (current.length > 0) {
        const fallback = current[current.length - 1];

        setTimeout(() => {
          if (type(fallback, text)) {
            const urls = extractUrls(text);
            if (!urls.length) return;

            let count = 0;
            const iv = setInterval(() => {
              count++;
              if (!fallback.isConnected) {
                clearInterval(iv);
                return;
              }
              if (hasLinkPreview(fallback, urls)) {
                clearInterval(iv);
                setTimeout(() => {
                  removeUrlsFromCaption(fallback, urls);
                }, 1000);
              } else if (count >= 150) {
                clearInterval(iv);
              }
            }, 200);
          }
        }, 250);
      }
    }
  }, 200);
}

// =====================================================
// PANEL 5: COPY ALL URL TAB
// =====================================================

function extractUsernameOrUrl(rawUrl) {
  try {
    const u = new URL(rawUrl);
    const m = u.pathname.match(/^\/@([^/?#]+)/);
    if (m && m[1]) {
      return decodeURIComponent(m[1]).replace(/^@/, '');
    }
  } catch (_) {}
  const fallback = String(rawUrl || '').match(/\/@([A-Za-z0-9._]+)/);
  if (fallback && fallback[1]) {
    return fallback[1];
  }
  return rawUrl;
}

async function refreshOpenTabUrls() {
  try {
    const tabs = await getTargetTabs(copyAllWindows?.checked);
    const threadsTabs = tabs.filter(
      t => (t.url || t.pendingUrl) && /threads\.(com|net)/i.test(t.url || t.pendingUrl)
    );

    const usernames = await Promise.all(
      threadsTabs.map(async tab => {
        // 1. Coba minta langsung dari content script tab aktif
        try {
          const res = await new Promise(resolve => {
            chrome.tabs.sendMessage(tab.id, { action: 'getTabUsername' }, response => {
              if (chrome.runtime.lastError || !response || !response.ok) {
                resolve(null);
              } else {
                resolve(response);
              }
            });
          });
          if (res?.username) {
            return res.username;
          }
        } catch (_) {}

        // 2. Coba cek dari storage yang disimpan background
        try {
          const data = await chrome.storage.local.get(`tab_username_${tab.id}`);
          if (data?.[`tab_username_${tab.id}`]) {
            return data[`tab_username_${tab.id}`];
          }
        } catch (_) {}

        // 3. Fallback ekstrak dari URL tab jika ada /@...
        const fromUrl = extractUsernameOrUrl(tab.url || tab.pendingUrl || '');
        if (fromUrl && !/^https?:\/\//i.test(fromUrl)) {
          return fromUrl;
        }

        return fromUrl || '';
      })
    );

    const urls = usernames.filter(Boolean);

    if (copyUrlsOutput) {
      copyUrlsOutput.value = urls.join('\n');
    }
    if (countCopyUrls) {
      countCopyUrls.textContent = `${urls.length}`;
    }
    return urls;
  } catch (err) {
    console.error('Gagal mengambil daftar URL:', err);
    return [];
  }
}

if (copyAllWindows) {
  copyAllWindows.addEventListener('change', refreshOpenTabUrls);
}

if (btnRefreshUrls) {
  btnRefreshUrls.addEventListener('click', async () => {
    const urls = await refreshOpenTabUrls();
    showToast(`Memuat ${urls.length} URL tab terbuka`, 'info');
  });
}

if (btnCopyAllUrls) {
  btnCopyAllUrls.addEventListener('click', async () => {
    const urls = await refreshOpenTabUrls();

    if (!urls.length) {
      showToast('Tidak ada URL tab yang bisa disalin', 'error');
      return;
    }

    const text = urls.join('\n');

    try {
      await navigator.clipboard.writeText(text);
      showToast(`Berhasil menyalin ${urls.length} URL tab ke clipboard!`, 'success');
    } catch (_) {
      if (copyUrlsOutput) {
        copyUrlsOutput.focus();
        copyUrlsOutput.select();
        document.execCommand('copy');
        showToast(`Berhasil menyalin ${urls.length} URL tab!`, 'success');
      }
    }
  });
}
