// Background Service Worker:
// 1. Mengelola status Auto Login + 2FA + Auto Edit Profil per tab (job_tab_<tabId>)
// 2. Mengelola Multi-Tab Poster (START / STOP / runParallelPosting)

const JOB_EXPIRY_MS = 10 * 60 * 1000; // 10 menit

let stopped = false;
let postingRunInProgress = false;
let currentRunId = 0;

const SWITCH_DELAY = 80;

function getKey(tabId) {
  return `job_tab_${tabId}`;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function pick(array, index) {
  if (!array || !array.length) return "";
  if (array.length === 1) return array[0];
  return array[index % array.length];
}

function progress(text) {
  const message = {
    action: "PROGRESS",
    text
  };

  chrome.runtime.sendMessage(message).catch(() => {});

  chrome.storage.local.set({
    threads_popup_status_v1: {
      text: String(text),
      savedAt: Date.now()
    }
  }).catch(() => {});
}

function isCurrentRun(runId) {
  return !stopped && runId === currentRunId;
}

function validateProfilePhotoConfig(config) {
  const enabled = config.useProfilePhoto === true;
  const url = String(config.profilePhotoUrl || "").trim();

  if (!enabled) {
    return {
      ok: true,
      enabled: false,
      url: ""
    };
  }

  if (!url) {
    return {
      ok: false,
      message: "URL foto profil belum diisi."
    };
  }

  try {
    const parsed = new URL(url);
    if (!["https:", "http:"].includes(parsed.protocol)) {
      throw new Error("Protokol URL tidak didukung.");
    }
    return {
      ok: true,
      enabled: true,
      url: parsed.href
    };
  } catch (_) {
    return {
      ok: false,
      message: "URL foto profil tidak valid. Gunakan HTTP atau HTTPS."
    };
  }
}

async function getThreadsTabs(count, runId) {
  const existing = await chrome.tabs.query({
    url: [
      "https://www.threads.com/*",
      "https://*.threads.com/*",
      "https://threads.net/*",
      "https://*.threads.net/*"
    ]
  });

  if (!isCurrentRun(runId)) return [];

  const tabs = existing
    .filter(tab => !tab.discarded && tab.id != null)
    .slice(0, count);

  while (tabs.length < count && isCurrentRun(runId)) {
    const tab = await chrome.tabs.create({
      url: "https://www.threads.com/",
      active: false
    });

    if (tab?.id != null) {
      tabs.push(tab);
    }

    await sleep(150);
  }

  return tabs;
}

async function waitForTab(tabId, runId, timeout = 30000) {
  const start = Date.now();

  while (Date.now() - start < timeout) {
    if (!isCurrentRun(runId)) return false;

    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") {
        return true;
      }
    } catch (_) {
      return false;
    }

    await sleep(150);
  }

  return false;
}

async function sendToTab(tabId, message, runId) {
  if (!isCurrentRun(runId)) {
    return {
      ok: false,
      stopped: true
    };
  }

  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (error) {
    return {
      ok: false,
      error: error?.message || "Gagal menghubungi content script."
    };
  }
}

async function switchSweep(jobs, originalTab, runId) {
  progress(`Memproses tampilan ${jobs.length} tab dengan switch cepat...`);

  for (let i = 0; i < jobs.length; i++) {
    if (!isCurrentRun(runId)) return false;

    const job = jobs[i];

    try {
      const tab = await chrome.tabs.get(job.tabId);

      await chrome.tabs.update(tab.id, { active: true });

      if (tab.windowId != null) {
        await chrome.windows.update(tab.windowId, { focused: true });
      }

      await sleep(SWITCH_DELAY);
    } catch (error) {
      console.warn("[Threads Poster] Switch tab gagal:", job.tabId, error);
    }
  }

  if (!isCurrentRun(runId)) return false;

  if (originalTab?.id != null) {
    try {
      const tab = await chrome.tabs.get(originalTab.id);

      if (tab.windowId != null) {
        await chrome.windows.update(tab.windowId, { focused: true });
      }

      await chrome.tabs.update(originalTab.id, { active: true });
    } catch (_) {}
  }

  return true;
}

async function runParallelPosting(config, runId) {
  const activeTabs = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });

  const originalTab = activeTabs[0] || null;

  try {
    const profilePhoto = validateProfilePhotoConfig(config);

    if (!profilePhoto.ok) {
      progress(profilePhoto.message);
      return;
    }

    if (profilePhoto.enabled) {
      progress("URL foto profil diterima. Menyiapkan proses posting...");
    }

    if (!isCurrentRun(runId)) {
      progress("Proses dihentikan.");
      return;
    }

    const tabCount = Math.max(1, Math.min(50, Number(config.tabCount) || 1));

    progress("Proses...");

    const tabs = await getThreadsTabs(tabCount, runId);

    if (!isCurrentRun(runId)) {
      progress("Dihentikan");
      return;
    }

    if (!tabs.length) {
      progress("Gagal: Tidak ada tab Threads");
      return;
    }

    const readyResults = await Promise.all(
      tabs.map(tab => waitForTab(tab.id, runId))
    );

    if (!isCurrentRun(runId)) {
      progress("Dihentikan");
      return;
    }

    const readyTabs = tabs.filter((_, index) => readyResults[index]);

    if (!readyTabs.length) {
      progress("Gagal: Tab belum siap");
      return;
    }

    const combineCaptions = config.combineCaptions === true;
    const allCaptions = Array.isArray(config.captions) ? config.captions : [];
    const combinedCaption = allCaptions.join("\n");

    const jobs = readyTabs.map((tab, index) => {
      const rawTopic = String(config.topic || "").trim();
      const cleanTopic = (
        !rawTopic ||
        rawTopic.toLowerCase() === "tanpa topik" ||
        rawTopic === "-- tanpa topik --"
      ) ? "" : rawTopic;

      return {
        tabId: tab.id,
        index,
        caption: combineCaptions ? combinedCaption : pick(allCaptions, index),
        imageUrl: pick(config.urls, index),
        quoteUrl: pick(config.quoteUrls, index),
        topic: cleanTopic
      };
    });

    progress("Proses...");

    const fillResults = await Promise.all(
      jobs.map(job =>
        sendToTab(
          job.tabId,
          {
            action: "POST",
            caption: job.caption,
            imageUrl: job.imageUrl,
            quoteUrl: job.quoteUrl,
            topic: job.topic
          },
          runId
        )
      )
    );

    if (!isCurrentRun(runId)) {
      progress("Dihentikan");
      return;
    }

    let apiSent = 0;

    fillResults.forEach(result => {
      if (result?.ok && result?.sent) {
        apiSent++;
      }
    });

    progress(apiSent > 0 ? "Selesai" : "Gagal");
  } catch (error) {
    progress("ERROR: " + (error?.message || String(error)));
  }
}

// ==========================================
// MESSAGE LISTENER GABUNGAN
// ==========================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.action) return false;

  // --- AUTO POSTER: STOP ---
  if (message.action === "STOP") {
    stopped = true;
    currentRunId++;
    progress("Proses dihentikan.");
    sendResponse({
      ok: true,
      message: "Proses dihentikan."
    });
    return false;
  }

  // --- AUTO POSTER: START ---
  if (message.action === "START") {
    if (postingRunInProgress) {
      sendResponse({
        ok: false,
        ignored: true,
        message: "Proses masih berjalan."
      });
      return false;
    }

    const profilePhoto = validateProfilePhotoConfig(message);

    if (!profilePhoto.ok) {
      sendResponse({
        ok: false,
        message: profilePhoto.message
      });
      return false;
    }

    postingRunInProgress = true;
    stopped = false;

    const runId = ++currentRunId;

    chrome.storage.local.set({
      threads_active_run_v1: {
        runId,
        status: "running",
        tabCount: message.tabCount,
        useProfilePhoto: profilePhoto.enabled,
        startedAt: Date.now()
      }
    }).catch(() => {});

    runParallelPosting(
      {
        ...message,
        useProfilePhoto: profilePhoto.enabled,
        profilePhotoUrl: profilePhoto.url
      },
      runId
    )
      .catch(error => {
        progress("ERROR: " + (error?.message || String(error)));
      })
      .finally(async () => {
        postingRunInProgress = false;

        await chrome.storage.local.set({
          threads_active_run_v1: {
            runId,
            status: stopped ? "stopped" : "finished",
            useProfilePhoto: profilePhoto.enabled,
            finishedAt: Date.now()
          }
        }).catch(() => {});
      });

    sendResponse({
      ok: true,
      message: "Proses..."
    });

    return false;
  }

  // --- AMBIL FOTO PROFIL KUSTOM UNTUK AKUN LOGIN (BEBAS CORS) ---
  if (message.action === "getProfilePhotoForAccount") {
    const idx = Math.max(0, Number(message.accountIndex) || 0);
    chrome.storage.local.get(
      ["form_login_profile_files", "form_login_profile_urls"],
      async data => {
        try {
          const files = Array.isArray(data?.form_login_profile_files)
            ? data.form_login_profile_files
            : [];
          if (files.length > 0) {
            const item = files[idx % files.length];
            sendResponse({ ok: true, dataUrl: item?.dataUrl || "" });
            return;
          }

          const rawUrls = String(data?.form_login_profile_urls || "")
            .split(/[\r\n,\s]+/)
            .map(s => s.trim())
            .filter(Boolean);

          if (rawUrls.length > 0) {
            const targetUrl = rawUrls[idx % rawUrls.length];
            if (/^https?:\/\//i.test(targetUrl)) {
              const res = await fetch(targetUrl, {
                credentials: "omit",
                cache: "no-store"
              });
              if (!res.ok) throw new Error("HTTP " + res.status);
              const mime = res.headers.get("content-type") || "image/jpeg";
              const buf = await res.arrayBuffer();
              const bytes = new Uint8Array(buf);
              let binary = "";
              const chunkSize = 0x8000;
              for (let i = 0; i < bytes.length; i += chunkSize) {
                binary += String.fromCharCode.apply(
                  null,
                  bytes.subarray(i, i + chunkSize)
                );
              }
              sendResponse({
                ok: true,
                dataUrl: `data:${mime};base64,${btoa(binary)}`
              });
              return;
            }
          }

          sendResponse({ ok: true, dataUrl: "" });
        } catch (err) {
          sendResponse({ ok: false, dataUrl: "", error: err?.message || String(err) });
        }
      }
    );
    return true;
  }

  // --- AUTO LOGIN PER-TAB STATE ---
  if (message.action === "setTabJobsBulk") {
    const entries = {};
    for (const [id, job] of Object.entries(message.jobs || {})) {
      entries[getKey(id)] = job;
    }
    chrome.storage.local.set(entries, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  const tabId = message.tabId || sender?.tab?.id;

  if (message.action === "markTabLoggedIn" && tabId) {
    chrome.storage.local.set({ [`tab_logged_in_${tabId}`]: true }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.action === "storeTabUsername" && tabId) {
    chrome.storage.local.set({
      [`tab_username_${tabId}`]: message.username,
      [`tab_logged_in_${tabId}`]: true
    }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (!tabId) {
    sendResponse({ job: null });
    return false;
  }

  const key = getKey(tabId);

  if (message.action === "getTabJob") {
    chrome.storage.local.get(key, data => {
      const job = data?.[key] || null;
      if (job && Date.now() - (job.startedAt || 0) > JOB_EXPIRY_MS) {
        chrome.storage.local.remove(key);
        sendResponse({ job: null });
        return;
      }
      sendResponse({ job, tabId });
    });
    return true;
  }

  if (message.action === "updateTabJob") {
    chrome.storage.local.get(key, data => {
      const current = data?.[key];
      if (!current) {
        sendResponse({ job: null });
        return;
      }
      const updated = { ...current, ...(message.patch || {}) };
      chrome.storage.local.set({ [key]: updated }, () => {
        sendResponse({ job: updated });
      });
    });
    return true;
  }

  if (message.action === "clearTabJob") {
    chrome.storage.local.remove(key, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.action === "closeCurrentTab") {
    chrome.storage.local.remove(key, () => {
      chrome.tabs.remove(tabId, () => {
        void chrome.runtime.lastError;
      });
      sendResponse({ ok: true });
    });
    return true;
  }

  return false;
});

function isSuspendedUrl(url) {
  return /\/accounts\/suspended(\/|\?|$)/i.test(String(url || ""));
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab?.url || "";
  if (isSuspendedUrl(url)) {
    chrome.storage.local.remove(getKey(tabId));
    chrome.tabs.remove(tabId, () => {
      void chrome.runtime.lastError;
    });
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  chrome.storage.local.remove([getKey(tabId), `tab_username_${tabId}`, `tab_logged_in_${tabId}`]);
});
