/* global require */
(function () {
  "use strict";

  const APP = "238260118697367";
  const USED_KEY = "ppt-used-names-v2";
  const EXT_BASE =
    (String(new Error().stack || "").match(
      /chrome-extension:\/\/[a-p]{32}\//
    ) || [])[0] || "";

  // Mutation hapus postingan (hasil tangkapan dari Network)
  const DEL_DOC_ID = "27316812471326955";
  const DEL_NAME = "useBarcelonaDeletePostWWWMutation";

  // Cache HTML hanya jika memang dibutuhkan untuk membaca token.
  let cachedHTML = null;

  function getHTMLSnapshot() {
    if (cachedHTML === null) {
      cachedHTML = document.documentElement
        ? document.documentElement.innerHTML
        : "";
    }
    return cachedHTML;
  }

  function invalidateHTMLSnapshot() {
    cachedHTML = null;
  }

  // ---------------------------------------------------------------
  // Hook fetch / XHR
  //  - window.__chk : request cek username (dipakai panel profil)
  //  - window.__tpl : template request GraphQL terakhir dari halaman
  //                   (token & parameter asli, dipakai panel hapus)
  // ---------------------------------------------------------------
  function toHeaderObject(h) {
    if (!h) return {};
    if (h instanceof Headers) return Object.fromEntries(h.entries());
    if (Array.isArray(h)) return Object.fromEntries(h);
    return { ...h };
  }

  function saveTemplate(body, headers) {
    if (
      typeof body === "string" &&
      body.includes("fb_dtsg=") &&
      body.includes("fb_api_req_friendly_name=")
    ) {
      window.__tpl = { body, headers: headers || {} };
    }
  }

  // Tangkap request pengecekan username satu kali.
  if (!window.__chkHook) {
    window.__chkHook = true;

    const originalFetch = window.fetch;

    window.fetch = function (url, options) {
      try {
        if (
          options &&
          typeof options.body === "string" &&
          options.body.includes(
            "BarcelonaEditProfileUsernamePageCheckMutation"
          )
        ) {
          window.__chk = {
            body: options.body,
            headers:
              options.headers instanceof Headers
                ? Object.fromEntries(options.headers.entries())
                : { ...(options.headers || {}) }
          };
        }
      } catch (_) {}

      try {
        const u = String((url && url.url) || url || "");

        if (u.includes("/graphql") && options) {
          let body = options.body;

          if (body instanceof URLSearchParams) body = body.toString();

          saveTemplate(body, toHeaderObject(options.headers));
        }

        // Tangkap request perubahan privasi jika user toggle di settings
        const bStr = typeof options?.body === "string" ? options.body : "";
        if (
          u.includes("privacy") ||
          u.includes("set_private") ||
          u.includes("set_public") ||
          bStr.includes("is_private") ||
          bStr.includes("Privacy") ||
          location.pathname.includes("profile_privacy")
        ) {
          console.warn("[PRIVACY_CAPTURED]", {
            url: u,
            method: options?.method || "POST",
            headers: toHeaderObject(options?.headers),
            body: bStr
          });
          try {
            sessionStorage.setItem("ppt_captured_privacy", JSON.stringify({
              url: u,
              method: options?.method || "POST",
              headers: toHeaderObject(options?.headers),
              body: bStr
            }));
          } catch (_) {}
        }
      } catch (_) {}

      return originalFetch.apply(this, arguments);
    };

    try {
      const xo = XMLHttpRequest.prototype.open;
      const xs = XMLHttpRequest.prototype.send;
      const xh = XMLHttpRequest.prototype.setRequestHeader;

      XMLHttpRequest.prototype.open = function (method, url) {
        this.__pu = String(url || "");
        this.__ph = {};
        return xo.apply(this, arguments);
      };

      XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
        try {
          if (this.__ph) this.__ph[k] = v;
        } catch (_) {}
        return xh.apply(this, arguments);
      };

      XMLHttpRequest.prototype.send = function (body) {
        try {
          if ((this.__pu || "").includes("/graphql")) {
            saveTemplate(
              body instanceof URLSearchParams ? body.toString() : body,
              this.__ph
            );
          }
        } catch (_) {}

        return xs.apply(this, arguments);
      };
    } catch (_) {}
  }

  // ---------------------------------------------------------------
  // Token cadangan (dipakai panel hapus jika template belum ada)
  // ---------------------------------------------------------------
  const authCache = new Map();

  function pageToken(regex) {
    const key = regex.source;
    if (authCache.has(key)) return authCache.get(key);

    const match = getHTMLSnapshot().match(regex);
    const value = match?.[1] || "";

    authCache.set(key, value);
    return value;
  }

  function getAuth() {
    const csrfMatch = document.cookie.match(/csrftoken=([^;]+)/);

    if (!csrfMatch) {
      throw Error("Cookie CSRF tidak ditemukan. Muat ulang Threads.");
    }

    const mod = (moduleName, key) => {
      try {
        return require(moduleName)[key] || "";
      } catch (_) {
        return "";
      }
    };

    const lsd =
      mod("LSD", "token") ||
      pageToken(/"LSD",\[\],\{"token":"([^"]+)"/);

    const dtsg =
      mod("DTSGInitialData", "token") ||
      pageToken(/"DTSGInitialData",\[\],\{"token":"([^"]+)"/);

    let jazoest = pageToken(/jazoest=(\d+)/);

    if (!jazoest && dtsg) {
      let sum = 0;
      for (const ch of dtsg) sum += ch.charCodeAt(0);
      jazoest = "2" + sum;
    }

    const actor =
      pageToken(/"actorID":"(\d+)"/) ||
      mod("CurrentUserInitialData", "NON_FACEBOOK_USER_ID") ||
      mod("CurrentUserInitialData", "USER_ID") ||
      "";

    const revision =
      pageToken(/"__rev":(\d+)/) ||
      pageToken(/"server_revision":(\d+)/);

    return { csrf: csrfMatch[1], lsd, dtsg, jazoest, actor, revision };
  }

  // ---------------------------------------------------------------
  // Popup tunggal dengan 2 tab (di samping kanan)
  // ---------------------------------------------------------------
  const cleanups = [];

  function closeAll() {
    while (cleanups.length) {
      try {
        cleanups.pop()();
      } catch (_) {}
    }

    const w = document.getElementById("ppt-wrap");
    if (w) w.remove();

    const s = document.getElementById("ppt-wrap-style");
    if (s) s.remove();
  }

  function getWrap() {
    let w = document.getElementById("ppt-wrap");
    if (w) return w;

    if (!document.getElementById("ppt-wrap-style")) {
      const s = document.createElement("style");
      s.id = "ppt-wrap-style";
      s.textContent = `
        #ppt-wrap{
          position:fixed;top:20px;left:20px;
          width:310px;max-width:calc(100vw - 24px);
          max-height:calc(100vh - 40px);overflow:auto;
          box-sizing:border-box;background:#16161c;color:#f2f2f7;
          border:1px solid #2c2c36;border-radius:14px;
          z-index:2147483647;
          font:13px/1.3 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
          box-shadow:0 16px 48px rgba(0,0,0,.55)
        }
        #ppt-wrap *{box-sizing:border-box}
        #ppt-tabs{
          display:flex;gap:6px;align-items:center;
          padding:10px 12px 0
        }
        #ppt-tabs .tab{
          flex:1;padding:8px 6px;border:0;border-radius:8px;
          background:#24242d;color:#c8c8d4;cursor:pointer;
          font:inherit;font-size:12px;font-weight:600
        }
        #ppt-tabs .tab:hover{background:#2e2e3a}
        #ppt-wrap[data-tab=profile] #ppt-tabs .tab[data-t=profile]{
          background:#7c5cff;color:#fff
        }
        #ppt-wrap[data-tab=del] #ppt-tabs .tab[data-t=del]{
          background:#e5484d;color:#fff
        }
        #ppt-xall{
          flex:none;width:28px;height:28px;padding:0;
          display:flex;align-items:center;justify-content:center;
          background:#24242d;color:#c8c8d4;border:0;border-radius:99px;
          cursor:pointer
        }
        #ppt-xall:hover{background:#ff5d5d;color:#fff}
        #ppt-xall svg{width:12px;height:12px;pointer-events:none}
        #ppt-body{padding:0 14px 14px}
        #ppt-wrap[data-tab=profile] #ppt-del-panel{display:none}
        #ppt-wrap[data-tab=del] #ppt-panel{display:none}
        @media (max-width:640px){
          #ppt-wrap{top:12px;left:12px}
        }
      `;
      document.head.appendChild(s);
    }

    w = document.createElement("div");
    w.id = "ppt-wrap";
    w.dataset.tab = "profile";
    w.innerHTML = `
      <div id="ppt-tabs">
        <button class="tab" data-t="profile" type="button">Edit Profil</button>
        <button class="tab" data-t="del" type="button">Hapus Postingan</button>
        <button id="ppt-xall" type="button" aria-label="Tutup">
          <svg viewBox="0 0 14 14" fill="none" stroke="currentColor"
            stroke-width="2" stroke-linecap="round">
            <path d="M2 2l10 10M12 2L2 12"/>
          </svg>
        </button>
      </div>
      <div id="ppt-body"></div>
    `;

    w.querySelectorAll(".tab").forEach(btn => {
      btn.onclick = () => {
        w.dataset.tab = btn.dataset.t;
      };
    });

    w.querySelector("#ppt-xall").onclick = closeAll;

    document.body.appendChild(w);
    return w;
  }

  function getBody() {
    return getWrap().querySelector("#ppt-body");
  }

  // ===============================================================
  // PANEL EDIT PROFIL (logika tidak diubah)
  // ===============================================================
  function RUN() {
    if (!/(^|\.)threads\.(com|net)$/.test(location.hostname)) return;
    if (!document.body) return;
    if (document.getElementById("ppt-panel")) return;

    const DEF_B64 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/7QCEUGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAGgcAigAYkZCTUQwYTAwMGExNDAyMDAwMGE5MTYwMDAwZDgyMzAwMDBhMDI1MDAwMDk4MjcwMDAwODcyYjAwMDAyODQ1MDAwMGViNDkwMDAwZTI0YzAwMDBiZTRmMDAwMGE2ODEwMDAwAP/bAIQABQYGCwgLCwsLCw0LCwsNDg4NDQ4ODw0ODg4NDxAQEBEREBAQEA8TEhMPEBETFBQTERMWFhYTFhUVFhkWGRYWEgEFBQUKBwoICQkICwgKCAsKCgkJCgoMCQoJCgkMDQsKCwsKCw0MCwsICwsMDAwNDQwMDQoLCg0MDQ0MExQTExOc/8IAEQgCgAKAAwEiAAIRAQMRAf/EAN8AAAIDAQEBAAAAAAAAAAAAAAIDAAEEBQYHAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAUQAAICAQMEAQMEAgICAwAAAAABAhEQAxIgBCEwMUATMkEUFSJQBVEzQiNhQ2BxEQABAQUGBQMDAwUAAAAAAAABABARITFAAiAwMlBxQVFhgZESImADobFCwfBSYnKC8RIAAgECBQQCAwEBAQAAAAAAAAERECEgMUFRYTBxgZGhscHR8OFA8RMAAgEDAwMEAwEBAQAAAAAAAAERITFBEFFhcYGRobHB8CDR8eEwQP/aAAwDAQACEAMQAAAB8wRV4vSsjgQNigs6sBoMgmZ7Vy2KLQ7n6zurPBsURpLGUa6WQtDUlEwAebsxUIvXYC2Z6QGgt5y6wOKYqZru3wPRVjwzGactSzVEXmvFQUvfk0ajRosWrkURksx7sj9TUYXjWjbh25slSUqEE3BktdIoMMgkd/Zn0dM9XD1OLc25TZPLA9XPqEsDRApbS1aOgMFWxRZACnk0oubkqisDIJwuQYRaSpxogXM24rAopYGLcvUqZHU4DxxrlyWeo8z6g8sFQzsAtZOFJbW1Y1gsBuxzYJ1SQcFiNWfRqbbh8tl0+d1pUw5AUQlhRlrfQkNIHoXw956/E7PHsNgsk8xdr5drUZCrGWWk1WEwGDFtCUVahMh1LDWyEKWS5ctZX5gTlIQm0yc7o4dRa31qIMkirzu3mrYAJA6WvV+X9XHkBbnrLsz7NRyQXGgGLlc0DlGFcLs4Al66TG5tZ7lLnPejo8jpSlQyGJZQshJaEqI1W9O6/F0d508zdhuXMA480Ar5dmiJAHQh5dC7BKHZFsWEMsizAuMqKjooWeYClFTBqSG3O1UY3J1BFkFxgGTN1MXTDBvcc+OVYfpvP9WXz2NzLN4JOVRHUUlo04mTOlEUBuolLOgc+jPqdB+HXjR9Pk9GVtKkMERVgVaLs4L7fH7tbOtyuzvOJImy00544aTHn1u1mtjZEWcKIDZGzERRiDCurJ4zS6dUJz6M9ijbdCZFKoHUcwHDcqOWCBVQc/rDZydgq3noZGLs6etLjzXR5uwILrNooU0glv1l9FWNVLtQp8TPTxMqdiNQdvP6BN/P351DXIaIwuhgdjAfRed9RZo7HJ6Os+ZwbjZwM7GmPOiJc+1SUFQWUQUpCRkKJRqqtEtA60KIZRG6QVuy0RUI5uY5WEojEMsq4dLFywVnSZcvRHcVjM959Dl3Yo5LRMKyvG1wgsx783RsVGXjSDZAI6CKfKxi+XPK6mHVYzpYOjjY0y83MOqJjrSOiTdIR7Lynq9RnQxv1nE5LpCllHkCuc+w1YhRgiSKgLuVGLMCDSLqxs0pfU1RHSCs7AHYEqLMxI2059aJZmmmhA6sRYxVjAKAiZ11uZ2eBYBRy548YQjZh3lmoH5oC4ZVR9CqbQsXjWdwsTIYs3l2rNu57sjrNsTEVTaAbYm7qYOhvPQDRh1mNW2Q7q48tSqx1OKEeIVK+k3ZUSdhvyxXgJRnC1anQLIebotNjIFkIpKMeUuatSEzsWOgZt6UzJadgCxRNCbVd2Sd3znpuFpE7MsNz6UwrHpHpnXZBz1YlQMKxdOoWLxrMypqIMJrOrdg6HPZkV5oU2gRkQBZDrb82vc7HH7HH1lzVNkMhKPIgA46sGQITWXUCyDQ06VZYUsCiRZ0jytxpow1EdCoXTaAu4Rb1JlK3UtehS5W6ImMdaxEYdmdlGdnhd7haQ1ti0WgRoyb95bFXjTBCQVrqtMy3GsctUdoOykPzbzv383bz3tLKUugUUaVqoeA1HotIO6Y38vpc65YSzhhBDyi2Dz7WphIqmNMU0qEGQ2FTbVJNiZEaUajzh41VFFYp5wsxKVcNSWnUhUW6WUS5BY3LqZ3jYJmwQvXmO/wO5y9RbKCF49Obcm1GmAZR50shKLByy0aAFA8bMkM9RWboc/WdetPQxtE0BCCdaomiCWXvOzs53U3isZ52XkDC5KPPrs+PdZVLINsEJ1LE2wLGVKUgXEVndm1HvzNlY3OyVp5yh0gysLOUPBZUiaREW0QVPVZmjUWXBYDadFnV53R5VUNrhWTQrpnSyj56MQtZLNAIpKMMQAurFWYU3mdPl7z19ir57bapK8QCHWIDOhyutZu7HI7HTHmeZsxMP05nS6nZLFqEuXYTNhLHIpWqrk0PClsYoIzkuBOjNrIGplNNZZpEMHWs5bILldSbGGgh5Z7jQCGkztPU54PKwXAY7l9Lnaiw0ZjMQ694EhZjctgxNmR8rQGFjBsCFQhZyk5HD0x01E7nvGxlFiELaggvReb9TWvp4N1x5LKVXOhydGRXLlxFT8dgM7zUZ9ybBUw7ACaLcjWnkOd4rhzdDnbyklnqOlVmutNGs8rB1qkHVNlXcsKU+UCYsWzM7UrLuyI21usrm7cOjc9wy603rI7s+nGpCbKmaBlRGwSToiQ15bFhY2Y3J0dM7huue5QkDRWAOhRn9v4/wBnZoIstz5XQjRcteLcqOXLjJq+fa6tsoU8Vx6aiA2rJZgFnYox5t2ikbOjfPSM/UPOudx+7m3nztTP35a5iM1CDEYKLl0nlfDxXJZpQ0tTV0nVk26mDN2s9c8t2Ex0J7w9q757bajhgiEriSRoJBDMrwsy0/JqZduboagRq8atizI0aLoVxv8AQ8fsbnT4nf8AMM87UjUyxgsyu6JczF1y7spbQDOCmggeEOjAl2DTKOb3fEdbU9hOSHLfVzccJexlw57FK9d2vRx+cl7g5fBX707PG+iLjWJ5u7TLw53wl47exx5WCAxXU43orfRZm8vj6e1w+mFfOg9p4f0eXaaS1LbsHnchruGwLgyRKYa3FcnSG8s25teNWJEJJlFENF5mqO70uf1rOh5T03n5nDqp1zZw4GypQqi5d6hZg4N0YSrLursGzABGnvanzpn2Xd0x8kb9Zmb852+9OXyfY7E3nAWlWoWW6jIHQIwh1GVw0ejI8efp5HBz+xh5YPROPI4Pb+Xzrn8/oP8AL7eU3W05/H9CnWfnfd08D0+T1HS7HbT5+XvrTwIfQar5/Xv8B5HzXTzmbv8ApcJ5Ls+m6kvhR92w8BPfWfPl/RYfPa98J4vr+hyZvnsWtHLQlYsy2FqLFlItOcc9rJ6rF3DQpalcCm2L6nd9FvPL6r5vK4y6BjMIeELNLVNLBgiVvXAQ6BhQGFYmjsIWiZG04RwfQedzpbObt83s1BQ4oWqWV5H2fP7cfCdfuo7+fTt8vmr2Wfyug08L1/pTyXqHc2Jty9MshsuxsKwsaxFjxzCbD5izs8vJ0peNn9jh53y6+nn56zWSkwxR61CCkslMoL6fsNTz/regzeVRk3AonC5ONDctEWYmOapwQmKLW1a1VwqXIq7ghq3BLYsS5LBXn+7xJri6AXx779WHTx7CjfnhQC/ryzTqYvR5tG7j2douPLOxhyWSy6BGwipcqSQu6uJLqhAwFoeiECwFb1+DZ63mc7sR5zN7vjcr4kTqaRbPQVxPVdzp9M59VzeZRQoiZQ41cuCXZRRDdEYEPdneNGqKWQFSQkkIQ2KdneEs1AWNQnldLEvGza82Nt2c/b5/TpIbxvKnXk3z7ix1evx8cO2g5ZbyOfo2mLO7KuSpJCS6LuoXV0UNgApiQAYMLo6Blw19jzcPMdL0Hqca5Ha0HvKHlegy7SmMzB8hGaWwxp4d9kS7l3I5IN+EevLqOx7O/nKS7BExF3ISpC5UEPzvLSxBYEMZksE4qNeeayFauPbtN53Q4d6x71WHtwb/AF+MpJrMkhJIXKhJcqrqyrkLqQuoJYQCksXFCVAUYFS6KoqPcuhVZQ7AsmC2jyDRx11LOMzN5/S56neb1MYpoy6OxS9K0z7EL1nunwe16vGwDDpgakKuoSVBDktJndnDWaoRUhzcu7DNJVqx427XzdPD0dQ8j+e6cudOe+0P9XkqXVlyUXUlXJIkkqpIXJCVcAAwFAYlCVAiYwNFRVXR9DOVrN3bbaUniQ7DVyxL+BjefWp/j95sAs1jUtHtQ6ywYCLWYQsSXZ3z856H2eOpddOdS6Bl0JYsys2jPBLNVJkkZcHT5qji34MbRoy6ePba7K7n10HnZmtciax0Ji2+vyXJNZkkJJKlSEkhcuFSUCs1gCVA1dFCVQNEJQmB9FZZayXNz8dpgDcFdRcvEMvJ7GtWzj2IqIJgNRzku1IDFC1mOSlsWJ2Y8/THr6S/2eGquqqrESxZlZdOYJTFQFSA8nsckHJsqa4upLePfWY3y6GxJ51oYl2bLubzsLn7PT5WSTpzqXVSSEupF3UqUQgLMAKIQZKJV1FVdAiYn0Ti58dFBIshIvkdDz/Hsbwd5fZbKOWzogmgyxjVtuYpixa2LlWpyhWbTns39/xns/V5Kq668qEhEnUBzaMxYEEBJZOb08Bno6By7E43Uu/N6gISla/M/OnmtsAvQGsvZztvq8rKuuvOVcJdXElSrG6FgayAYFSSKklDRDA0QnVsSqykLKskvMUt3j9rGCzn0MxNbOiRjFs1GmJIKzWCtgSrWxYlD0WZPV+V7Pfz94Sr0eYRIVCpYvPpzlDdC7q4mTWisMuREaM+N1dF5vUBgUpsWzO3vzvlYJRlCdKN53Fg3+zx1cmsyrouSQNEFABCVVwGrhQlRQlQIlUdW6Opcsnnux57j2Y9TvN62MBuaRiSmYssJgssK5SCBrBWYKAMXIlGhFZTHLvn7+kP9fjoSqxdWMAh6bQhUirqLa2icu5IvLqxc+hkM8/pE1tlNoMzomZ7mtZ5m0aWRnHuxh249aXXq8tS6LlSIs1gVdUNyipIQSElXIAWBXUMTJcE42EWeT2NatvPqxgnmmwDomCaGwSsMLopRgCJBKAEApLk2Z8urLrHf9F4T3Hp8thS+nMqVUMzuChhhCgbKVDo5NaJCOd2eFz66IF8PRb0apTFbM7PQDJo7GLVGLKUPRrG/TyOx6/IEut4lXUUtiiquVUkAl0QSoqSFAdHTMSL5/Q4GN43rd5PYbVuzomAyUmrZRmJ2MICSwsSgIFEDCBWYC1MVYjNpz6xm9h4zudeXpAer0eRbLAoDEg3FAbWhrGGamCD5/0PnuXZ0Wzj6NJVmzt2rFrx0e1T5oqZKSDlopNjcJ7/ABNffzbqsfR5pdCsW1S1JCpIUJiVV0SpZVFR0iAyvLdvicO7HLdw9BtW3OyMGwTAOxhidhyUQLoEbGURsAQIAFMVYlGhGs4NOZ9z7t3D9D6vHnTrRrC6lkE1KOdy0GmhZlHSqVPD7vLx0w7MG/z+q8OjDnevdyt+Om7Tj0Z1ssD1FLaqVWbVnubsV9OPdB1+zw5xcgqXBd3GhkhQlQNXIG5KglR0TAl4WUWeT1satvPobAOaMwaE1bEMwOwpBKGwIBDKI2BS2KBUxVi0OTc4GrLU2e7+fer68OnAX38xC4BSHJKG7FiZCGrAVkcUvndimeb2hm0hz6L1rfnb3ofNanZtNgLauVKnLkRDHpz7JYeh7PAzG895yLauIJRRq6WVcAopAS6qVdHSx7OJjeJy2+X1m0Dxs2AcpsW0JgHYZjdhUQFDYlBYy0NiCsgBUxdikOTc4pB1H9Tklc+/XoX6/FViqG5+Vlx27B4TudGcx3y5nL6vEHdPia1euh8nuohPn0Jy3Z2x6Wyveh+oSmgJFoZqVvC4T3uDu9Pm2NFXp8tKbQkoEXRgtSRaEhKq6JVw6HmOzxuPdjAb5/QbFszsmAcGYmGYnqHctKqxKEgUasYESAFZgABrsUlqrnEB59TRa7s9n1/Meo9Pk5vC2Y+XesOrl469eFms9A1Gn0+HJ5P2ajx2rpozrGFV5faxim421q250xi2SudnfTRKWLBgSro6RCNaNY6x8zre3wpB6t4vO6xF1UVRi1VXAauiqujNjl+X1sYtvLqbAOaMxKDMGUZgywpKSCQLKqA1KgRJYIEICzCxSXJ1nHl1YdZ0Rdp2/TeL9P25Y8z18uprspaXQ3Pd6PC3enyvLGVyji9rg46ZYBeb1tapuNseludNYtitYpg8lnqDRjCxOoBbQsy9TCHbh2qtnr8edWpUJW0KGVcoy6UYVA1dHHYDfF7TYtmehsApTMTgjFlWYHYUqksSBZUkDUEoCEADAWBhYtDk3OXm9PldMOJTKf6Hzm+56Ii/GgByJQXY756exztno4N0Yrub856LzGOiTUzzepzUuxtzVNmmMWyVhrMcxTNQxOChaMKo6Eq0LudHS891/V43vyj14qXpzgCVBru1CSlqio5DVs8PvMwZNGYnmkwDDMDsO6KrqRKkpaG6BG5AAawQMBYGNikuXZm43b4vTmbFt1lmjK9N+nnuxvaKqWLJ3Tj1yyae/DQeSy/Jer8jz6A1DfP6nuQ3O3sWzOmsUyVprIc1LNRtiaCJioCwJABgmc7Rvn6NfN0ezwkghuVyUtyCEJgtUQryjBvh95mB50ZQoIwYpkJ2WYFZdSiDcUasYqoJQEIA2AK2BYtbF2K4va5XTkDBLeSYpkPbmbNbbznF7cW/ry6KdmHrycQsRPlPW+S59FNS7h6nNUzG3uQ7NYxbFY1JSuYpmo01sSS6AEwKBgQtT12Z+vyy7effHq9PkzUwFlSFwTF0Qtcswb4PoEwTlIxNSMSQ2LOw5UJLEqrGWVVFVIAJCABCCBBYAGFi+V1edvnnIL3gzWQ0lEugs7jTuwdHpy9HyDvpzl0QvynrPJ895n538PU5yW405qWytYps001mG1ZjDWdMkJBBgAiQwC2gLz6l3OxnL63s8SweO+eemLBuqGhYrymrZ4PosMDUzBkEQMCMCorqksSFaqVEGQg3QIGAAkNAJUi1sEVh6BdOfAnd43XkBgWdEQsiaIVjO1xu105N0Bp6YQAkL8v6TzmN4n5tHn9TnIdjTmpZK5ijlcxLBpAQxizptgxIJUoCYgCYwoGhYjZmT05dsYPr8QJcAqjAhhZzDovB9IzE5TISDMSDIbq4JFVIVV1A1IVIJAIARIUESChEhAE0bx3eZsV6vH5e9Wbj3ZpzbJoytlleg8/2OnLq4rV05upmZE+f9H53G+a9D/P6nNU7O2NUzNaxTJWMUwYxRjGLKmsUxDEqBAxUBIYATGlp0LuWbuN1vV44J115JFoQuiWYjA/B9IzBkpkBhMAgrkqSQlSiqKooZCpKBAqAkpKAgoaKC1uVZptLfX4uXi25MdpryvzvS1BBdvkdzrwajo8/fO60mnO4Pc4mNcjRnd5/W9yHZ21imZrWJcrDWcNNRjGKZTGKYMkllDchYmCiJDAgwLEMpHTn2RovX4QFoUkGLj//2gAIAQEAAQUCwsPhQuLFR/EqBUCoChE2RNkTYjaNG1mxlMd8GrNp3N8kLUtWWWjpjX+68LFFEiPqiiiuET8LEc1hYorNnS/ZA0CfvD5PjZd5TLLXG8N4sbGxPhJ5rj0v26zuQ+MvVY7nfNli9r1j89zvizcb0fURvRuLLNLtpL1o9lwoWFh5rF5fDsUNFPFjkWbixlFZk++b4dN9sn3NQXCXG+H5RRQis2zcyys0hxRVaf49Ry1mxYfB4rF8qwiT4WSzZZKNmxoSsklSjw0u0MTRF8H750SF7KEVz3YbHI1OzNT7c+jdlPhXF4RfCy8NnY7FLE12o28L5y7aQ2K2Lsb44R+VyrEvSyuO43Yoo7kU29TvOPvX4PLZRQyyxPN4YuG4ssbzZeNTg8KVG9C7mpEjGs6//GOSZHsWezaRQheGPpc3y6aP/k/On71/efYxcJG3jfCuTxWUanKULNlZ1YuAhdzq/T9QRCaJQXBevD+YPtZuL43m8dH90DRNX7ll4TzWLKEIa8NEisUysy5obSNN7T+WpLUW2el9/XPtAcay3ifrxP3DwWWdjtjp/tgaI33Q3Q9aJ7y0dyyxrlWPzwsbz3LLw+coMjAbs0ZbXDvLSV63VxsRe5VwkR9+Gfpe/DRRRoqtJeovbHUm0b2xFYXFD8C99jtllFcdo0VzbHKiPpnS/fry/k+zJdxFFD9wxXgl9q8qVQ/Gp9k9NtrQZHRo2IsteGy8tCHErLfGsX4ZQsWli7fSr+XUf8kxckvFQvWFnsdsXw1PaNX0uFZ7eOz2ViihlG02lFYrltK4STIwo6T3rffMiqXbFk32/O4sssssvMvQl3j6FiijaSo2lFEY25/dH3ri40sLnZeWehvhRRtKKNpQyiiuVcOkRqd5YorEvcfExI/7Rwljvxss6fvP86fvW+5cHh8r5PF43YsWKx3w8XiJLleOl9N9yBXdoSxBdq8MsT9r2RK4UUUM6X7oGiT7vg3wvFYeE+LzWaxtZtKw8yRWO5eX2GbjpvtKERw3RXCy81ws1D8kbxZfCsdN9sTS7LjuRuR2LRuNyNyLRuNx2LNxuNxdm43G83l4TNxZ2Ow8+yuFCGbcaXbTkhekiijUIe80VxoruT9CI+HS/wCP8eo8W0fxG0Wi0XizcbxTNxuNxZuLNw8bTabTajaUbSSKZTO47O4rG8WJli9f/FeEPD9w9ctxeLPyT9Yjm80UUJVA1Pt43ePZSxZfBckxSLFjcbjvi8SXBiiNiw0VhEv+NorDPWKxWKKKK5P1+COO5TKZ3O5bNzJC963KsWVi80bRcHhLhRJER4jQ4m0uhMTyxlncYsavaDI4ZIj74UbSisUVw/AsVxsh3c3/ACh71/fHuxLNFcUuDxHNZ2m0aEjvwqyiRRWWIo1/SXD8wWL8VZ/CQkbUbUbUbTaUUaC/mvel71Zq1NcbxXKiuDJFikbjcbi83i8NFcKHiI8WI6hZrKKK4V4fxFcKzZZ033QNE1WLCkKbPqMXBFDR6G8XwlhMsssvFFFYtll8XY4FVhYgu/Ue8Ml6XKiiih8bPxuo3m4TNxuzZ0/qJHtHW5XlK8XwYliiiXirN4WKKKGNDRtIxIe9f3mYuFeCsSL7F8rLxo/8aJ9oavvC4exZb4VwkSH4rL4XizcOQ8SkX20/es/5XhskQLFxrnIl6/KHis3iyP2I1/U/aFxrNFYax7EisN2Vhlll5WKK50ejcdjsMfrR+7W+4Qz87qVi8TxIZD2VxoooaI++oyuFFFHrDZeNoo0IaNpVDwxCi2NM7ossssvF5sWGJYookdP9+q/5NikeyX3ESyxMssvNlksSxpl4orNFEVbl92n76h98LjuLKKHm6xWExjNjNPp1MUUbuzRGKa1dNJYvwUUJG0axI6b7tT7kOIlRP7mRxZfgliXoXJ56ZXqL3omuxC5NcaLKs75ookrN7r6Tipae2G3Yvozv6DJacTU7Oy8JFYs3CZZYqLWaOn+6HTT1XPQemS0ZxRqca4WWWWPEyPd0VworPSL+SNLtHVELimbxlFPhRZZuLNpHVcZLUQ+r3L9TaetNrdI9mpOMSc9z46fTymQ/xLZrdLLTk4vKws9Ku+m6NV95StR6SDjqxIvFYvwvsmQiV4em9fh9oahFeBUds7iy2LKRZq6rhLR63cLX0yWtBn1UfUZ/NktI6N6W19BoyP2s/az9v0om/p9In/kmP/Iap+qlf6lMuEh6CZpdK2+HSejqXUEyBqdOpji9OT7mnqOJCK1HPTcCyyyyyxd8TlZFCZfKlnQ+01vtlAorjWaK8LNXppyNLppoejKo9NJqPRyF0UiHQkelij9Mj9LE+hQ9Fn6RH6RH6KJ+hgft8B/47TP27SP22JHo1A/TRR+jiPoYj6SKWxRInVR/jpd0o04v+XU9P9Upxel0z1Fo9JPTJabkfoD9vP29n7cz9vZ+3M/b2jVpPQ6eWu5dA6j0zP0Mj9DI/RTP0Uz9FIfQzP0Mz9DMfQzI6T0jT/ka3uyzbyo9eGxJs0+msho0VmjsjefUPqM+ozez6jPqs+qz6zPrn1z9QS1rIa59dD1Yshqo+rEc4EqtFbktOhm3vf8AP/IaVnT9Q4Pp+qhqn8SkbUbUbTaaupHSOo6xzOl6SXUFx0lKU5mn0lH02fTZ9Nn0zYz6bNuLPZLpyenKJRtxZXBvLyljdjT0HI09BIrFFFEpl+VkcxKxL0i6HlqzWVmp0+4e6Bp9W0R6tH6mB+qgPrET66RctR6HQDe3ECyy2Wbmbmbmb2fUZ9Q3imjtIl06HpOONvH2JDPQi0jcWR03I0ekoUK4+ic/OxYZDDJeovCebw0OI+ihMl/j5o/TayP02sLoNRmn/joohpKBKVYir826iGsdmS0CWnWKKKLPfFKzS6SyGjt4pD7Ep8F5JCwyGGP7fQnj3lFXmOpiii0iWpiiMa8rzGdEdY9k+nJQofPT0HM0emURLikSnRKV8V5GLEiGJD+2QhCw1iPucOG5l5SFGvM+MdRohrWUpE+mK4R03I0ekIwrlRPUG75LyMWJeo4l6/6YXCSxElCxquKgJV8aOq0R1rKrHs0els09JRK40eieoN815HmRH0S9f9SQiLy8afrGxH0z6Zt+VFmnoORo9KolCXGhyonqYujebmdy2bsLyPM/UcT9L0PCZHMkaXr5+j0hCCjzonMlO8PUwuN0RnfnmLE/RP3lMWGiDr+gXP0T1ByvEp7heGOp5p51PRqexiwmLDRB/wBJQ3RPULxrTF44y2kZbvJPM8anCxMTLypf0VEp0T1MzltSF5E6IT3eOeZY1PWJexC4qX9DPUJTvhqy3Ncl4Iy2tO/FLLxP1ieELkpV81HonqDlfDVntS5rw6M6fhln8jzqLEfAnQnfykhujU1Bu+HolLc1zXhZpz3LwSz+eMo0Q4rh6E7+TKZPU5a0xfBZ00u/gln84l7ztrxxlfyJTvlOW1C+CxPa/A+U/eZclyTv5urLc/hMZoSuPN8tThPmuDPXzNWVL4bGdJLwPKzPhLyMg6+XqS3P4bGaMts/Esy9Zl78jIO/k6ktq+Ix405bo+FZfB++V5vgnT+Rry78l52M6SRRXKhqiK7eJYsSK4sZpu18Zui7+KxkjSnteNxZufgsaK4rFiXgZpun8bXlS+K8MRoS3RHl8Vh80hsXgeGRnafxdZ3L4rGMR006lm+L4PL9iw2IWFxeGaL+K3R7+Q8IhPctvjZWNX7hDY2RYhC4vOn2l8TXfb5DH7R0kxyw+D4WPOuhYYyIsIXF4fbCJfC13cl8hj9ohLay/EhjNVXGGGNCFhC8EO6KTK+BdHvwLK8zJCx0srjxYmXlsk6N2FGuKyvBovCRJfA1n2+VIWOmnUmsXlnbMiWoOW4XYhOyTt814PRe7F/A133+SyYswluTieiU6PqMhqW9chK8NWTltG8R7PwLw6M6H8H38pkxZ6SVxkak2lqydJkfZB1LE9FTJRrFfBeE7Ky/JrPt8pkxZ6KXd0a8x91D1JNTxZss7oenZ9FI1fhM0pVl+XXff5c+HSP+etPs1a0ncUbR49mmhpFdpI1vfwmQe5Yfkbt/Ln6zpOpanci+3BmlI+s8dxuzW+74cXtf9Q8T9ZRCdpvLzpyrLY0a33fDZoyKw6H/AE0/WURZ7Kw86WluUYMp4Zrfd8WMrRf9O+KEyy+FdoOjedmTRq/d8RkJbWehyv8ApnyRfCERSZaLLJM1fu+LRpz4P+sTHjTRJCKGsav3C+L6FK1/Ty98ojxpIkuywmM1vuF8VkHRQ/6afvleYCdm3vWdf7/jshK1/TangWNPsOWEsNnUff8AITp5fF/O1PAsaavCN2ep+8Xx2aTy/wCj04qT1OmGq8EbqJNl56n7vk+i7/pYumzUjuWVisKNkIFK13JY6n7vks0n/SvDJLCFwjZJ2RQqirGdT7+Wnf8ASMj6kSGLh+VZqRoUSCHjqsL5LNN1/SwxPjZpK2ycZNIhLaakrx1XzGRdrj//2gAIAQMQAT8B+SuC42X5H4rL5r/6Q15GL5dcV4F8ysrK5Lk/lsXkY/6d/LXN5vL+Uxc3/QPwP+ofJ+N8L8a8z8dWKliXirjeWMjyfjUi0bl/oczcWWWXwRQ42TjRF/78r5XwvG43F87xHLVko0y+VllllieKKxfG/NHhqLzXiuDZfnRGQsT+BeLL+EmReJfBvlDRv2LSS/B9Nf6JaP8AoarxxYhomq+Low/PGUNxPT2+KAnicLGq+HCNsXJo1Ibf/wA8MBCxKNkoV8LShXgmr8KdYWXEnCvgaUfz4tVd/DD3xaJwrzJWRVeLVXhh7ystEo15dJfkXikvDp+8rhqRvywVeNmqq42WWaWFwYyap+OCti8bNSNrwaWY8Gay8ekvI8TjT56b7ixHhJE128cF5HjWX55ojhcGMnGm/DBdxeR4krxQtEnp134RFyZqx8OmheR5mu5pqkWS9PMF3QvA0TjtfggvK8uNvLGsafsXh1YX4F5XlZY8afsXhZqwrvzXlY+M3nT9i8UkSVcl5pcGTzp+xePWhfxJcZ50/YvGzUjXw5id8J50/YvJqRv4chdhZnnT9i8jNWNd/hMl7ZHOpmHsXlnG+H//2gAIAQIQAT8B5rleVhv/ANcEsIfB4rNZXiXNYTKK4fjCHwfznhDeEP8AoE8Vm8Ivghofyk6PeWPH44ol8xSLGx5lykMssssXy4jfL8clzr4i4WXhD4r4Vll83xrCHiivJfmeIknziP5rxHwQ+cxH48C8izeF5Fl+h8Vh+vgt0NtlMj24UVwRfgQiXFeKiiUPyUbf/Yom0orNYrO4hKzYNFYrC7c75UVlIrsfTPpIUUudFEsxdEXZRRRRQyiijabRrFl4rioleVjzpy8rVjhi+CQl8CSHiGL8rVj0/wDWUvhNEliPwaK4y1f9D1GKb/2R1v8AYnfjksIi7XxdWf44xnRCe7xSGsQlQnfw5ypD5JkJ7vDIeYyojK/hakr8EXQvAx8IyohO/gasq7eLTfhlxTNOd+ZuiTvxaT8M/Q+KZGV+XVf48cX4dT1z05V5Zu/GjTfg1MPiiDteObpD8aIPv4NTL46T8eqx+NYi7XOfoeHwRB+ObvyLGk/BLDy8Ii7Xhm+w/IsRy9QjK+Eh8kaUvx4dRj8izF9ibwsyfYfBcEyLteCT8qyn2yhYn6H4dOVeB/AfBYn6H4tOV835lxjnU9D8UXQnfxI5YiGZ+h+PTl8SPGGZ+h+SEr+HEa4QzPywlXw44eYZl682nK/hIj6HmGZeh+WMq4f/2gAIAQEBBj8Cx8o8LKFlCy/cqR8lcfK/V5U7Sz2lmKzfZZvssyzC5JSwDoP1TsGlsVPSO6ODNTvFsmSKkVIri2anc/yt/jTwjvTTvf8AFL7KQ8KS+mOj/LDdjpA2wBhDHA5WQhp3+ouyqwOZCKCGkwueL06masN7aVGDe7XWg9e2WMbksInlZLTpPq8J5iSnIDqEKaeF9Q7DSoNfyTzxK7ofybHHsbow++Nva/DCeQZPSguxRHSjF2eB9MdH+WHTf9Ue2gAcgEEL08YVJ2RvjEIxAOoRYNNtI70hw7OoWr5OGGBHBmwnlZLTppvgYoxLZ2GBP7qamFNTCmpqYuTrfN4DHGHvaYb2Sz4WUeFkHhZR4WUeFIeFIeFwwpMkpKSkziplTU1NTXBklJSUsM4haMOx5QxJaGKQsmpqamGTC4MkpIDkAghp1mvA6os7adZr7LSp6bZryeQbuTcnpQr7Z2DDshpopShhb2tQG9MMKx5QVnfTgjSDDsjkAwdBUypQjXAdQiy12ppQU08BxCJHdSUVCjNdZ8tPU0sFsjbEih9R81Z/vRH8KiXKJUJUPZQ+6inkFzBjuwyeQx5YLuCyBONkOXp9AcnOgo2lPAgFG05ETdxwSzZO4J/qL0emPvh2mHameF7gyZ8L9RULKmz0/Usx5r22nKFsKNte62oB/wB17bKmPCeV7gyBRD3OD7pZ4Yd0eacWnmumD0T8PcoJ1NAPWQrKVlKyrkolSWULKFJSWVZVkCyBZAsqyrj5Rc+KjZUlJSgi5hQVpHZQgV6bU0+y791JelzlNTU1mU1mWZOBeOa5AKYU1MKYUwuF6IYGRwZ4UaKSkyV226TItf0Q2QImE8T/ADuv6bXJTU1NTU2e6124p0rP3XKzzXps8E5POH7YKODPRrV4Fj5FRCm/dRB/KzLMoPKhBQeSn2/CcKCEMCGDGtOFD2lQIKkpFRIC9xf9lAOoosguWl98ON2FJFkFy0nvgBPrua9vi9HQTpQeyGiHSu50YoaTFQw4fD+mFGsdpPp8/LBqe1A/FGpdTQu5/nX30T9ddRu5/EH4h+Cjx4wzfGkb01od/iA/k/iINCdHdyqDZ76BtqALJ129PvVbQ1baqdz0AjUX86/el3rDZ744NA+l2rAeWgDUXcvxjmgdR7128MOFK+idyrwRxF5/NdQ11K7Udi3ZhHXS99AtDo0sfwLBciwUbudBtoA6vYVHCG3wOzuiut9zIyZ2+HOYaV3jVn3T8LldPxC1vTu1N/C9a3+F7/tdtfC3dLp+IHt8KDH3OwqnaM4qBw/2udqp+jA4k4KDRtVu1CJujb4gO9Y7nopwQnnhds99D//aAAgBAQIBPyGL2sPlCw2XmGjuI8ma3IR8hozEzOjXP7LE9nmNAUa/SfxtfkaP0BM0g4HzOYOD8r9H8iIf5IY2X8GOF6ZF/oJJ5PyQ9l7L7fJcLzt3G60lCa5TQZxZkRKcwqh+UvgZeiIbkF3l/RFCcSE+1JWLAoGiJsLZom/tVnorkhozZEf0j5fJ3IvxRQ39Fm5/fQkqdxpdyxUkrJYaWgVuRWfA0nwzKzLP2O9E5HKE3YQO0IduxCLgmcBC2qmKWrMqCnYT7UZKEqkkJfUv2IEEEUS7l/o8xj1SxC+qe/Z5fszLsVhLE/8AgJ7vgl8Evj5HwQuPzRNkE+GTy+BKEs2Jf5v9P5Iv/gzt9GeXog/mMidoI7ohuvg7keyP6fgzj0fwSKkznA5ZZ7H8RIlhWF2IJn9lw5LCJvRHAkKw3/QR2EN2colf+kPZ1CXei8i1lDodDNTSKbcHyGybvPsQ2Qtqo09zakk0SOjsrM1RbofJokS9Gd73QbMhsQtF8MPs9Kc2X0LRV0O4XyH6VFTZj6GmlZC3/wDLol7eZlD3IRsmGOTuTAhLCHDIkQU/JJYUFqGmSIkISqe1JqL7xEbu9icLt7kTkmkFy2d/dZF2NCqVAs/FGRRoihcnzSeaFuriTccLQt2GTSWjsZC5IdSy/wC/AvB34Er9w0R3iipGifgRhaeh+jzFnkOVqNTlbgYT3JFA6Gx6LbCRC2OwhsJrYVOVCW4YQnuIqogQ2OVl7OxA7CvkQXPhHukCbMwNsExQ175MaWlGrg1YYGGhLh8nyeCTMqPOxDQ0xwzQ27InmRsSOxjzJ2XyN5f0XcSGsveioi0n7Lf4KJ1k/h2FKRt/o24qaCUy1DUiQLncnkl7Ei4HaRp2LUozwdlZqVnoTyr2KsmbeuxBq8eC0kFUNISWQgRrfItqwQNEDRBmLYaUmQy8lx3PPtF+GckZZehOMxu+ZL3M9hLemHPpMV3e7f2JL+BrFt9hCoo4PhnInkXu7EKcosJ8yXaHAWdyBWumTVIrt6UXL1gixJDTZCjYSWwiEU5jXJBlpSBIixlZCktaS2GsLJLdpfJlrh8GdGxL3ErFfn2IXadjzRBA7JssCWNiYrKMptQrshKHBJBL0okb4PI9nnt7oS77jTwW9UKic/ZH9n/ejcH/AH8yODMTFDlRd3oKiuKzZJJYg7izU7hJnAS2FYQ96wNVub5+kZoZ8rrINSyWbsjMaYVw906XPs9DMTgtZCG9hZpUgggjDbPf8DXa80RCoil2W0eh3Ft0W21/30LaSZnu2IJzNLyIaz2Q2JLHgJQbEHnRyIkiiVEwT8KKBtFizUmohISWaqzkUWDXBqcscPhfubjjntJlmSZrskxyNorP6CXj+kW8l3Cxc61Re07i+lZJwNECWPl8mVyiaJosRSxYhEB8B8DzGM45EH8EJFrDzTPyIS2GkuBNZGTvIzMbehMTpnoNFxtH0VLFjIQEglRMsxoXaIpGC94F2Zssjq8xohyJ/TY71U/IpYEtQhmehLTuWogsWLEDoksNmohQWLCxYkQti5B3kBHsy1W8L2yxlb0appfIjUQaC7i524LPggbIFZkk+Ru4gy3I1QWWvJyjgRUkkjkXc7hKNRhsmkjGzMaoI82L8H4KLt/y58QKpT01L0iEWpMGncgSIIxND1Ll4pK6VMtyEQtiGO4toyQmXG7CRssZkGhW7qQzwImi7VoUaXwQJIdE7EjKuEhpokSEk7hmRMT7iQ7cyBWokNIYcRoaZc0xnHmP632NPd+kXZCrhIbRATJb2ErGJ6pSthtDKQooicCYHsLxUSbCaBMTQ37j92V8jz3/AKFleEPdeKFgSBwIQux5HgTIuLFhRXJ8kuhD1IM6GJPIbiCbYuJ6k1zRdRIY3VFUy3CR7kQJVIEsW1xZbfikEEUjAtu7VBqO4+wSLdhJ0IkY7Cbk7ix7OfSFdnu2LLjT2JUKt2QvPwhtFHkTe9fBkOhXGrDpcZR3JvQT3EmxKpuE9Jg7hWzJTJobc7MVwXJk2kZajzkcDlaiuNtF8xUrc5X0SNy2NEJFcoSEhZUOjaZFLEU+wkzQ9DIdxEa0aO47hUCd5PdhBc3uxpXIhVk1+BuNF/dhf1oHbX1c7hQxIOBBOgmnRoY32JkUQx9iBAtwnqTIa5H4FSM8i6GOYr0sQRMhneX9DL1JbJrYyI2KXIK1GyymeKpo3deRBvkLJ2pYJeolpzo12JF0fxGZan2F9BmIVf4Icb2Tf90nAIbXlC4/lHHfk/8AYGm69kOBvciC0CXciNDYFESkCBeSQnAXIkIW5DuWGGFZkyNIewmI3QlwXHNAiobRoNkdxJZ7UaIIDSnggih/EQfchhCcaHohbIiRoklbVsb+oEF6QhCEM0aVvBk5ZfA0KQv8ERfpEf8AINr/AADTb0Q+C9IlsvSOBekdi9InsvQ2/khiRNibZ6GnReiFsIbBJ/GQ/wDTO97En/oiEFqG7yD/AALYEbxEs0TtexMwbMByhshkmjoa4TjvT+xnPUWEPbMgaWbWFjuuLwSTWYqSQPrVEuNPAgWxC3wYGtWB8P2Yl8iyO7QhCFR7FhMciLNkpC7hMzGJtCSJUeY0PDhYaITPQYhkNRORgriGuBdjWYtEcyZJhQVMjEt9vshHKERoJYeoiyW5YeKIwDvZHLPJ5IibsidRdTQWUuJC+31QcqIf2Dnr7ErovZ/Zn8WLDJKD2XyKiq9BkN3bQseZMf6TdshpsagTEiyqRmGiwIaEKRCXPYXkiwjD1kT3G2iTgEjgaLmO0oLKJQpMjJGgcIaRNR06VuJPYiTOlhCO9LtIwkymIqtC/BHAyVRLfk+yT1ehZ7UNKrb7Cwwjcz+NP9I2/wAEty95eTiWRdkMvQSIPAtLKoobWol0HLUYlQcORuBNMyyHMd5NUqV5IljORlgd5b/WSEO440I5HEjzcFidyyELDESSSQRUlzRFOwnatdwVBoQEvgc+kXNyzOZdWjj0N5IJp6rBdt/cD/pJ5/eQlb95Ez/QP0Sth3p2CkiBXGGHhQ7SUSqJEGlocVMRSC7NiwiBLmYhsUB5ZNDvRy6IE8+RKkIgihIdJHk+w4EkRmKlikDEDk7BjyC/dCludx7YwmM3fujRbehdpFYkjVsSSCoWDhFhNIFEhmxOmOxEgRZ7iHpSU9BwFcSjYh+C4jIZBINPMlApZOndHqKlxGSTC5LBC3qVFBCBpEJjQrH2dKUR2GeUdBRpXpwWJl+2b6GybJCEhKr05cI0sv0SeBXbUlaDcjTlQdhVDJEyaRS4pJCJ3IEqiExF8B9xLcc0OSJwQpnzEfWNFxyNkjP4LiGqEhUjkdLDFtC0+MaJ2Gg6JkjEyGJLZ7nwJbuXvML2PLiFRFJXc+AizeY34G4qsSksolLpKi4i5cRJnSRMlj4kO1EPMQb5JCdEg9rMmRhKRlxedhlPguFzQlm+R31zwIuchDapA/2JCGZzAlY2o8CBwIGyBNCwrefZi5DJb/RDS1RUgjKFdnIUCU9hhhcDBZD2HkY4mhlEOmxkqkszIEHezvo6LuQQISGs5DbjDXIhPeODHL2NBWO7oeENk0bpGBqKZ08iy72QkOi+45qZYiBLaPdN1+x3EhBKrooxqfolUEZbVhM8yELBIJhlcMzCSJG0zSz4ElOg1mypyJCcnsdp2k1eCCGW5lqXF0SGhexbHoSe7pQCuoSXeKIbCdiI0IErYlbHYdg8z4ElsWCu2yxN7sSD7slRcljDD9+R8l3BYzzxiQVxIQSFRQv/AAitCT4oQTcSEj2CcjDbWapW8kGPNlyE051/QKtZIMSpRDb8hjWx/YwK9bbCU80wxMTYnysRzSXuSxE8nqhm+JEIIE5E+DM5yJLHbGcZZ3KixZiboQZYhCVEyaUhxko1ZYkhUTMyCGomNLc7Ab9EXs+RM2T978VkQKiTeyRDr+RCVGxlb0QQSEsb7kButRuRcUBPXdCgRtG6hEG5zmnLMVow4m+XYPTvsmRYm7EWqfdTcKRhYT5Ld6Ea0RH5HIxpZpyNIfIW4PTXNu7QmO4XPJq6ZEqbWlrYiYLEECYbaJZLEVh3MvJieCpAkRIwxA0d5PyWpvhi3ODR7EEEsC0iG36IPMWxsXcG4EyQhuKOYlGLiQyxllkLqWFxrYSTYckxQiSZLOBtzPZGpmI7ipkosQQRFJ0M3++SMiuwQmwEM1RtDkoaBzuXJG8L5JDWzEXcPbYxbw0+hpZE7bfyGpo8xMu1E2zFRLE6okm5cgxvQb2IKvFJVLDGxYf2Q1fzC+aI28EAhYJSE07DCNwhuORtsSGCMe0DUUHEnbPcQkeVCV/wQjinZjb+omyFy3I3suxbc5kGjylx9wbajwW5PoV1L5g3n7DKQrn/AA0KhOzJbzj9Cyx6j6P7XMufo0VAejrDHIt3doSvMwTUZy3yhMFyTZv2Nnut+kD0bwS2GSSdiNG1mhXRcnfcM9pAu1LC8WUSN3jRHiPlkt/gvHaJ0k9ELgekRA0QUVnIyMvI+Rr+BggglSBi2ovwJcQNSO5HJerFI7kkhrLhmfpG/wAMjnxE13b+xuLLy0ItbsjdPcl/RQkmQPKINDZpOKJ4MhtD+ljZqT7sQ2yJBpFCfSUA1JOO/kuLttceQ9UjiThr0QL2QeykkLXUtRCfJpXWd7GNG5XUWYgcibtZiZ/4J7BF4BxzgehSHAVqAWe58DxG6by7CLaSJCsNit0cw5UcL2Je3s7Xsh2h+RVlEZPQtQiW/gg8kcnC5FIGi4p/1hrchuc28Cjmilk2FRwhwyGNkPgwjSKpSJBKh0T3R7ot05REgkT2oKCDSkSXQvKgeyMaCLsDgUhBdoIy5CDVb7gOCd2+xiJXfaYjNjI08uCCZJvef8PVENpOOcA4hHYR3QqlC2S7eCdTtLN3Y2nLzyeiGVOxZeWWUoT0Q6DU3tsdisSrE9hprQt0JWdCIbeb00GH55HoMK3AtxwrkMWYlK+bE2+DNuR5LwbpNizQVzshpoo4BRoXCqxoggisECiEDQuYw0P/AByOXU9HmWDdhuV2FtqLJkMXY/AxrNr+yZarG37juQ7WC4/eRp/VMXyfF9j1mS8Xfsyg15Zy725eWRFY4WghYuT3JbnMT3OQ5Bbgl60uVyOwkPgfA9fwaHEfQ1vYf8RDX+Elhxq5E9AjhvIZNuBi7I7ljah3ZUhYggaEiFQtyIQqMfT8jNdfy1RmTSY7DEJlGiS6Jrkuc9pXR9nEMes+GmJn7kj5kHJdmcVZ+xFCk4E2q7G5JAl0nRsTNY0BZ3Qh7OGM/qBqM7cjn/g27/ZAs7F9UKjG4zJHNYbe0KTKkEEEoyL3VUKr6blZkprM7+5Duo8isGh2GsxzWzggiLo/0Ch5XrvOMa7WUUiB02Oh0YFOwhLuiS7+HkPe9xL/AEmXyJEkkifljTKxo0shwRTVkG4Cwn07IzIMyPtTpIw4w6eQ1wls8kECscjJvV1k60dDwyjMNSGkhrNHL9lmQrjmSIHlkQ3CkshIgikCgRDemPpxlHSP9h1IQ6CcDWE3KzG5lWKMfXDHR4pXayxwfQ2tNRKcBmYyRCSs0QbVBJ0kjfQzCyJHtQY/oEre1EGwhjSnYQ1I3cEdxJuJFp1mMY+jMufiG4kvAtqODBAgoyDcjTMx7V+DtCe47Ak7CoVYHjzYDIM+AfAGhRELGo6DW+Rf8rq8eskCSyBIikECQoEI0TF2MfDcgQVJGxPk9CuD2FgeN51yGVDM427ISGGhogjGmpkBf8cjY+ksCpBFEiwjHDIn2/1QhCqxqkNsu/7E56Tzq1hZLAJ8KIZhuk1JTXaZdv8AidGPpoiqCaNyppv5sKIQhCo0QNEDXtlsLSV54H0HnXKjSmRdxi5Ugdm8CFRkTZ5/8Lox9FiWBUSQd6Tz1yXcTV50IQhCFR0Yx7yhCys9VsPHrXRX7B4C2hxhMkVN/wB/8L6bqkZEA7AtqysX5pWBYDHRjGyL1uJVJk8etdI6ZgxLq5/GAkkRJB4Ar9dj6TEuRBtCPDMo4ON2KJCqhUIYxjHRl85ZOP8AWPWudDo8gzI+1bSdMgqSIVINCIydVjH0n0NIbSNvJDHN44QgqoQqmMdGMdEHqyfdf04XgzIdPoqtUamw7t3oVVQqQbhfd1GMfSZBTbnDNbpn3EIFRUQhCGMYxjHTG2lPlf5hYh0zIdFm7VS6rU2ZF7aiwIQqQOx5HUfTZfYr5rp3FehUVUIVGOjGMdEYmjn0fWB0dM6HRZ1LgaRDqqEIgaMrkbnXpvpvHkmSyEhCFRCEIVGMdGxjqdj3fziMDo6JcdFnVowfkFVUVCoxBNtKE5v0n1Fh79Z41EIQsCEIVGMYxjHV+NT6f4wOrMw6au9VssGddhDqqIVWISoeT++k+osMzsrIQhCwJCFTyMdGMY6sx5h9rMTGPMdNfeq4QsCqmJk0YhG5XQY6vDHQmXq7LyIQqKiEKiwMYxjHVeZvxEPus8LGPMdMtcjwfIFVCo4CbYhUO4yOfvt0HgfQeGb+EsQhCELAVXiYx1frH0/xWgggaNaL6iirrNxUVCHQoQQRBIlHfLP1jfVVYDb0HI29RCEKqohEnxgYxjHgHF7v21+DzRLcbDyhtsWY2PIWRI6LhAhCwFYdAqySNVQO1n6IwsfVVbDu+FcQhCQqIVVTPxR0Yx4DFHITe5+PggWBNkHyoy5kqGhB1QmTWLhCEQNEE4CCe6/vkZkk0f8Aw2zZHnUQhCqqI2wMeBjHhDgFvnQh0e9LpFbZOHay5YmXMmk4wqFVosJELWw58P8A0eDMfXgN7XJlL1uIQhCIEIQlgbqxjoxjo1fcaIIvyd9fmmBoTIEOwxkUS9SQ3NxPDAahhUY6cqPY7BkGVX1VSGO74QhUWBCwu2JjGMeAI2zWzus/j6NiiCq1HUnoQz6AuxaqlqsUVxpLY0MsN9V1GKlk2R+6EIQhCEIVhUeF0dGMeBGoNUiaaTWTUrsxhOR2oxsdJGqETolOL+jNgCCCoajGMaFYanyNKe31ajQzuWDo+ohwN7XG5S9XIhVWEqPJlidHRjozqhHLfuyGKjTwWWYlRkwvZqnAketJKbOKMgSEEKhUYxjQy6991+RqlGQMQ+miOO6PGohUQhCEIQqyMeFjoxjNI1IPa55y+cIhCrLVkSh2ezHTe3Ya1a7cD7m22PmTvQyH9kOqEIVC/sqNDIGNCbZNZq6HEkydL1Do+tLxPl3EIWFUTEZrIdJwsdGMdGihCcCFzIfnX5HLOhCNjYs3PwPa3np4HlrXBkO/JSBDFyRxwiSjwCHRCFRYTQ6MaLjfddzcqu46Z9KYlvJDcm93IhCohVQhYGOroxjGPAJo+HcXh3X5GstWbKnQYnsLcjdtJeRryQWzt7ETvkTFr6Ma8ORKRQTfj3VCEIQhCIxIZPsQ0/6ROxqCRRrpwx7P2IQsKEIWVXiYx1Y6MgxJJFuEfp/6PC5OlGSeYkDdF69jsEdn/pCgav3IgSSRrKFd8ZbEn9YdEIQhCEKrwQISJZfYZmWC5HFFYfQkjs+WIQhUVVRU3ox4WOrGMyiZJJDxE+P8LhSR7dDUZHFxElCyGrZspofA9Ozs1DQm7uBM5OwxD/w3ohCFVUQqQPAxDvizEQIQOiY8cw92IQhVQuoxjGMYxmcJkkk82QkqDYyo1DdMidRidRsNAS1YnKhvqE0QhCFVCFiaGi6aa9iObFqNUdERjQhYlT8lzxjnAx0MzBUVFo1WAfBU07ju0iP+MiY/xfVEIQhCEIQtBVjAxDV/zYfISF0FmDPCxCEKqEIVIIo3RjeF1YxmZ2EIVEBIReA12rSdSGQZpkUt8f0hUQhCEIQhUWNodrrMu3vuSSHyOuQ10kIQhU2wvExjGMZlfZiohDUlTYzPkTJbCBlInWXzcnRjsQOx8/8AAhCEKqeBCq8Do7c8/wB+DPQbVEY6MTGqsQqIVV9CELCx0yqxjGOjoQhCEMIK5I2Md1oITKtSXYyHYkoiEIQhCExCEIVWh1Yxh0ccuw06PCWBCEIVEIVMqz80/pJJ6DGMY1diqhMmlmGPUM7tBcSQoauw6IqEIQhCqhXPnExjGS2laEE6PCh1QqJCwLFZYHhdGMYxLu4qqkjD0Y/wPSLQLnciNTRdHyvwhUIQhCEKqJxNDGhiE6NH91GiMCHaiFRVQqecHfoMeBjHgEKkigKtCJtPmO5wPkRBLPkr6QhCEIVExCEIQnXzWBjGhDNs0MggeDOiohC6HwLEx0eFjEv4xImtrHExoSEuOCTggm0P4OBCEIQhCqhCotsLoxjRetNexbS5OInQhYkLC30GPA6MXLGqmIi99hwSvoX2TclxozAVCEIWBCohW1r4wsYxCVT0y7YTq1IsSEIQsDpPQeBiSiU59wQ63D/Y1oah4EhISpImiIzDuQRPhKFKGfS/IhCEIQhCYqoQsTVHRickmgkRPerwSIQqKiVMiSIGMbwMY6PGzghqhbN1kOwhCCVWgEq+XLJmfk3Ltgjin9HLEIQhCFRYEIVfxV4GIQ/NUgao8CEIVcxDyyHWccjwuqEyk90hy+yMChiTzHL8A2J0HkZsvyQx819iEIQqqiwomk44GO10R08DqqKqFRcV+B9B0dGPCeziVRnP5rQmIkzE0EJTaRjTJbCRT6fwFQhCEIVFVVmkjGOjpAxCds+1HR0dEIQhVVZxyT0mPk8jujMMQhMcEQj0OS85GYhWDNWHtDyYrRFP4eBCEIQhVQqoVYo6fdWMdF2996ujP//aAAwDAQICEgMTAAAQ/L6gioQ1NKfBttGxe2zrxVkPO0/+Q2uWKzRdjEtKJWwCXv2/aSQDMQeqhw2gIcLReQnQeBT61bJF/HgWcy9d1vrf1FiCDbzxiJlZbxUDiCz7UDdcRpI4n/lEkYoMdRZHfW+IHW4qiRqxdGajmuUrraSUt07PMMmEVywG3r/LQCuwUoxnNT6J7ZXWHdU5u2k4mOPHvJx97BpmgEfvR7k2qhaE4L1KWR6Y0qmwYtHhqbxzp96SS2i2UMKhWz5mWaR/zxv1Ps6JTo6OErRdXNzv9cwOtx2p5kSUft1KCz8GNNYPkEqA7ebHh5hwqUrbyAQynGDBUBWj/UK2Zr5I02lxoUIeRKQ7p7B6IAsSFha0UP5ynu/Fm8fSjOoPO3LvxdAioLHPLHzu108toya2iNBWTAfGoQdbXBAWRPa9hbyro1Tz908M0ymHPrmE7doz332/dfRHOWUXLKfyFpzOJHXJ5+NKyOq8TULGc+xzA74QwGcENyRaEAHZEoetsAMlFLpYYMQvao1m5KgDlR3+J+YY4hGLTTrNxUODrOXNZuaaG0q9kkTmHHllcJEsnDMxwsQgjkqyNA8kyazduiyNooYf2TxQhKeQAigb9ySwSuYobpRvm6Y1uzdZP9NIFRJLcX0c1s7u8PXRR1Y82S+aHfnXNnp6jKmCSV66SCb77xoLDvK4yQ4WlBEVUcamuevOcGecqOd0D7VcX11XeuEb/iENykiSMlWOw0MoVhfhcY6mB9xtypV1h1tp3TbbUdgtBq/szmw04ocd5dz/AAdinU4ggjsedXXVY3xw+5J2j6wcvnhRuwnLBebH/wCaWit0qYZwJl32k3FXevM/Rve+iSI40utaCTQXqwu2sJgO/kILAhXG11k1uffsS0BQ7ysHju8zMASFmMN+nxWHrw4rTwa2EmH0d+vLmnf7KC7ddfBAZhSVW5+aFtq3m2l1RBoX2VWumOM0HWX8hMQsdbqTDnxjFg6iAL60zR92SBUbUGlFnmtkHuxuYCCO8WPRqJkcjWySY6Oo8YAo0SA7/wBtBVrhpFcdHFjjKXzO8rn8Ch208ys4d4RsTpKk+mdJFV9dpWi7jsYvX8zCNvhRhpg9xpmXJMZYZqOlkMZtRRZ1BL5oL1TH5i2uPg/kl58dlG6raPjjxIOeYxAtJD1RoOZ0ZhPPv/l2UDlntBRAExfhxxRdKPdP4XZEQL9tCtmHCnnSVdteAbtx8CV15nsUgQmhPi/8A0DV5VFRaZKjKw7ng7p+krG10TCcdIaadV/6bOpP6AYd4ZdtUasn4wTWpNlig1GfEl4rORuXVvVWMn59W0SYMohNbMkz4xnUrttqyfBYQpnjINBT/wAMHrNsKLMgpvxpcRnBq92C4NEYcu+ikmxrHkYXx7ElPmGxBXo1+ejUbWQsynvewNTFbk5y8E+rUtFX8dKsbpG5/QUF9ZCmeWg4FTT89jasejTSy/8AjziQg+z33iCLbIa/pL5aIQTMhHmzFC30FEQl72GmvesBzojuV2kfVv7gLR45q6HVLVNElkFkYz826RB9hwYA2fNGO439Vtez+CElDoXWF2NnknEnXK83Cq2jWBSTl+c08hc+2qG/GoDA+A7/2gAIAQMSAT8Qxus4nRSSTRuaN1T0RIx4liRWR0fQHgNVWN9RDqx4FRioxYVjY8LxRgjAhVmkUZBGIkmr/wCCMLRmvbCg1IpBA1jsfQdZ6TV3IeQlJno8V1wQQRQ+rFIwT1pWdZxk0kkkkmiZJPVd3girzxn00QQqQQQQQRhZvwSTTMImianiikEUVYIIxOuUW2CBkUJEEEdKKOixxgbFjzXSITq2PCicEDwyTSaxgzdVha+F4zokRgLsTROB0eDNhgdFnhfQRgRIEog0ZVkTJJrPYg1wJwG7C6Fikkkk0BUJFkkXUOomklzRuFBr8CG4sW6uZfskkkkdxWwsTDNEk0YmLnaTGzxyo90O6LkeHkWqiSSSRUS3J4otliNjM9OaZvInXX6qcCxg6J6aqmoaLkyaRgjoTAqWH/wkRElFHaf+FJNUht1i21N2dxt0idccMa0NR0k6bSiYazn/AIZokQarwRgVm8DuS3F0ENetF5HvDXXmiVI5aaiRiksyRbNl0cww1FLf2OffnrpURB5eB1ZCaGobW3QmSJ7DCdJhuW6+uqlWdy0EsbGQS36LWIQhEEhPlZP460hLcjJbVeOZdujlCFU0TJjnjq3/AIVTR4ppW41Da2pNJwyFUxkTnqxkhdPInckkknAMzJoSEiBBTznTgOBBVfQ+J6DXdEJhWJ2JJE+hmMQqPDODEkkscCFw8QlaqxwQJIVX0SLa9sbQ0Xqd8chBObVWKRBRLqERGtyIFJxA3V2IEPNUJCS2EFhQnUrNYFh1qF1CGQMZ4rlhGDdVkoEKjqyYkF6rIsEKSEKjHjdTLrtetxA3TL4pQsTRB5WWBYFFiWF1MzCGNBe3RfhWsTEJkMnn3wJ4KxrGSITwn1flUIWNk6ZLaemBOiCxZYngLC/VQhCwKrIErNYUIVH00wN4kQicM0aEJfDwIQqvG65BORkUeB9FC6E1hx6HgWGOikplzsxpIGaa5FK6idDXP/jLAZVSBr1yMFdBjIDW41Fq/wD/2gAIAQISAT8QwxhXxkiKEOomCkKNDEEUwRgTSMRUkmkVRZj5EN6KmjEp0MdJJJJ/4ZETSCKEJSnCIWVHhVXgROGcKJJHmZcJGVDRkonBuCEEEEC6k4JJE8CuOKNBuoxNJJ6Av+ZisQzoPYQr4qfRAvqyT0HScCnCeO6RSKIIokNED6TrasZk6E+kyS5LJZOATV0SLbDVIIogyiEVIwOs1miR0kZJNVirJcwySaxiSaLqIY6RWSRVitIQ8eoepBFEKjpFEiKyIdWIgjCqmQdHhyk1gSq6PAkYmqxBBGBEVNEGUNSSSarKIpIqvotTKuE9RncgihiMCBJoMaIwL2NjPGlUZAbkgvdssyJ0QRRFGRmKBAO4goiiDUHeq6FKolVvgR3FyGgEEKsEESAlhWZJKlEOaYYgxIkCBtk0oThJUVDrUikmgT1EZjbHbAglISCOq6aUzIdEk4IxpzDuX3RKil/wQTYAtCOuisFsWrXPfQb1g3YZlfyJuTnpPOm1A0C0R/wQRSaSWeR1kZlE8HtidWLWlrbUXcuuqN0knroXYIpBcjXzWJUZkFGqPewlfxWOpNZfCHRUdZ0jSk9+gkiDQ1SRmdm+q3WNDUfQROu2N0WwxjpAavNdaA2TJHRCxQON+jmUMdEREVdWz7DH0YBOb79IY8ErqyGOq6GVRtSMWUihk4HjOnIc0OqwTRUxd2CMGRVbDea36eiMPqIx4mJNBYqBrpyGPqGaON3pmBsJiMfRgah9CaKhjQ09qNwbCNdV2Gluh0Q6MRPl0dLCXSJEyEjFce6rcUMeAxUo5++hO2PAumhDE6Go9B4YIETuH0TxukVQhKhiEWrBGPC6JkaNegeN4VWxoSFnAIMeF1lIhzieBLorCILhjGPC1REdnlif/CYliR9JMi8rE+kqIzjVRsWBkGh9JEwz/wCJoY1KEGI1YJj6LomRo2o/+E0oZ6raudQx9B1mJic33r//2gAIAQEDAT8Qlg4WT6GdKc48lEPzjuRcCff7InUopTYb7wIbMO31i73IkdqbLDGgbFiFUnUiP8Kiw2eXsS2NRgcSpRYC3B2fI9o7gwnsvktIJnHgD/En8D/dAP8AYo7KipCkbKhAjF+kHmFhv0MY2dNMvKMwuiT1bWYwr947yO6LD6Cwc/obuxKGkKr0wSvtm3kbLIu5XlCy6oTYRM2AxrZvYpYZBwhuNnkkhHyHmHS0+gpM3Ni6Iks2HMf4M6JKUtuCFKtTrPHuNm9ug5PRsTwFHDij7lMtzwIlV+w7AHu9z9/VR8k5uP1Zz14k40IyTup7/uR2nZawJVZVsNY6J6FhfUo+xLwIyiVXSi3Vk7442ZEdsPAjqFyZNg29BUk7k5FlkZpyGJEEnxDcVdySqFehMVbK92hKK51gbuq+sDHaCG4xGImXthCkbOSVNxojzRSh0bIahhBbUjLKMELf4ERKoX6ECXC8G048kZ4WO5Ce/lio6PyEt/uDtVKaX3Il5EnLwjb9AyEY5/A+9Bs19Uq2eQ8L3r5OzuPUZ/shNNU/XI5BZlIr6iH+4fS4m4TZXV99iGUnVv0TNvA+kzIHcVnwsWLyN8kGC/1JIFLOP9+BIOC9BVXeupPOs5jqIlCjL9CtcPNVfPwNseMaCpX9+D3lBJt8QJL1aw83GSCjqtxZv0KwajbJLiHUsFth3YlghLvUJn6Nmz5JEO0upgZ6IWJ90SK9BDdyFRvAoZGl1R3sDce03EyOokHAJREia3mdNiE1KSrEmNwJ3/XH2LcQRDTvJAu7qIqOWLv7BXUcDhpbaXEx+SXsXFu0xJsJci+8bKgo2l1kdxnZ/wCmx6hPlsuSnr/BzS0f3lFOIZvsLYkSYqhJdAuU1dAhGodABLN0fHyyrq8/WnyJCkDY3K1+D/Z7qB6/IQqClW30PYRMQdKf4KJlO+a3J1EUb0+5H5iCXEmzHVe5B3FQbQJmYXb2EWdpcjxc+CogzoheGbz9DWyN5BJIBNlbqmiS6NqVIrcbIfAhtAl23L5GG/Rm1FyIUkusvRIvq2hJi5DfbiQ+a/6LoVL6RKpEDWhWjuJ4+4SE0pbiBqOBAtr3DTyCr/g6yOsuOXkMx0e4ujsIL7HuZf4RXZ/eRMZa2FQOSfIupR94Y5wKaPCH3aaidPV7s60J8v2FpQ9uW1nvD7GB+HT0Y8aOFZ6Kwkqstik+xFhL59LlTDj7URFMrOPQZVDcll2wfTcdEZbCaN/thGmvaBE4vBdTQerWl4IZSEmwQjCF9EFFhFfqoYbQM1BVy5UmC3eSBR1ERmGS4HAeSRK6D3koriWqWCd3EVxvpJmT4F4fYBqDhhCty7mZ8yqP+zbRIbkTxEX9fwMfcpyQMUNCfeSnwUdpBKguEigKVWKbSNZ7BMSn5ZeO7eBjwwYdHwQS3diKfHgS6pvmsEvk8MQ8ZLDX4JztFdiRSOT2RFvJeEkIXTYPWnrP9EkbTcpqz4dxU+RE8rtcTn6cqSQypTFanURhf9juX69CouLKzGWroqIVl0Y3chU1E8CXDHJwhUnhJ7G4nYldIYYzLdCd/BSRO9FOUKFqHQZNiqA1G6J5JdSSuoG3hFAp/fJPavYm2IyGaEqrS4HMmssryTR9Cm/RBAoluM3tRkIsYKomsXImKazJ5zehRPeWJaLRRyOk5CpNbpoqA38aXcqUE4KwLbDJVQxTvCqs9BwI8v3oJZO4W1HpUmkmXsSOX4ODk3cXARvnBnvSEm2h8nRx5aS/Qi8SXRfShDq3+0GlR5t61OUq+JYtx3VK13jYRJX96jZVqXJFwoa7DZPdE6BWbfrRBITeaoc+xmsCe4oWvmouDFPPgbRAdme43/ukIblm0CTVtdiIgM5EswRITJTsP5aruiASbHKYBJQlLY6TjUnK9Skm8KT+rgg0K2h0ES16D2l3sQvkPt2Y9yhiKcImL1WQpVwNFSRDY7aOA74nyin3GhdIhJORBXyHaxCIr5O4guGyup7DbjufxMXASn/gVd3yiHBIWqn7kkby/R1eXgSE1UZ9n9DZ271/oVcuz9Cx0VcqfYScN2LfI0ditNChfyNkXEQImr9y5/TM+xBqLkwqV4EQaNawykm0i4QJGdRErV8EngJW9z6GjdYncmN9sz0g0hKcnVpTwUHkZlHAXAvkRDOOXcmWp87soWr1yeo/KGUM+0VUksvJyQmqtxwRU+4RjFDekL3XsKBo9ESgZI4EhIORDwIQIpWBRJpPI30fcZlrI3YJDmhNv4G9tC5PcXaREc1e4keH+jvHyc1D1HCPziIynqH6uENSb1j7FC5SvX/KCbTz7+fdMWnKa6hs/fgkVVc7iRiS5NtzIpowLgFGwnPXf7gYmKq8EmfUluKfYRLiXPYb3QJ/2DWuJZGeC4uRhc8NC6wK51sPSkVkbkafU6omYJ3Jg/secIu2qNhygvUCH/GxDcJcD/wFybKpwgm69Ef4NcSs+DXUaQx4OlEzENnhCjIW+hINIZEC3gUGjoMD+IOoTl2RAVBvaJLwxtRclMjTDKAx5aBL/wCZI+ChnHv/AA/05FR6kLeTqpnueAaSXpAzaZJsiE2c89hNiQNL/wA/YthuqfyUYit5gsf+f0XZBaUGRw0LZEckrkvcarN9xtNAyVE1MsqolaQJvgaTElNA2X0KUQk5TKNajKBcRKq1IawhtNhqthrlDaEJ+PUIYQCKZWo3LFujPoRcZk9hxXy5lEndYfJBaOnJIkusV6jHKMp9qOwuTZegkI7kBLYdB0EBB3OgFPhlHYaKIZTYeCo0xNnsOiwnJpieA1bpX7wMneGQah7Hs7Empc+Tc+R1YVBbCFaa/jpn0JvjJNtIP/1hdnb4UG+Pqz/Zf4Gxr8P4G7csutjyX3koQvT/AGUVXS7CqlMPkhVVT3UCfMdkCLERFFRgQioPbQwYnanQNda+5svUl9Y5XBSiPUbxgTZaF9am19wxk2MoOYEt0JbaLkMIyOLCAiyqMlOtwjH6oULx/Rk3IeqCVOP0ZIan2GRqqfobFDqQllHQcEEbmiU+BZ5efI9CLInsNxohrBXYndDS3KIrS6GKQvqhc4+CsbpCo4SGVgbcV6kGDImzRCBwB9QfNhZFdG3vQ+tshJ5Un2whf6MLUqupLs/S5mhxMjjMe4ovAdqcjQabwJe3wOkUZFcn3grJvjqLQl2+CPcbtJoXX2HuLyUhiyTA+QjVcF4oSmNEKsCdmDkBDo20+hA0h8xAonInnuMbCGbhjRDImFaS7cjlyFEbIV0SKZarD0BIQkiguVBaB4CBLx8rnG058D2k2dBVjQka5RPdBCx6R9UYMkXKfqM1ilPBK4W0sKlhhzslI4Kil7FRPWNUu0igKacG9DhLiN1kn3SIB9GQbFn5cCCCQxUv7ii7949CO0+KCNpT4MKq6DSrR61E2gosEyJvDGGGQ4RggPYJkdhP8liddbcUFRr1G6JoOWCpQcBSLF3Qx0cqTFkJroTQiUhU4KcDcb4ENUNxDJ2NxQUY2OkmBqRZXdeWRZn/AAIEigixqkdZ0wkcf0fIksE0N51WCZEjTGJQImxN8UxLNvcSXGBvBCUVoMs4iFXyI1p4HMIJkrJ5Qlkct+8x+aXqTLZkwtj6ToQSIFbKPj77sm81fS5gk5hPcoIrjchuHn19im7nv+hJbCtiJLomljkI9xYtElRwOWa8JQeEXApWyy1s6DwNjngZUKRcXA0irtjN4a5FljoyqOp4F5UfKJugaf4NLinoMNtrckOCk3sYu4OwRFRJ04SipDQ1ShF9AmZNdx5egjPvBLBjSgFTxTC7EW86+RJI+wnoESYFLaR7CEQbX7hC2E+UmiJG6TEuBqFVEHs7C6EanPgQ8vyQWQpvEYsGSypLSiqcw/YmaO6HudVvpTWQ6iVq3Zvkro2KzPsEUYX23kdO/wBF+qY5VbdY9hrybGMR4EjRqZ6HL8Do3EWEkCUqIpp3FNdBPdsUr2FtNo5DgE8wYUGNuBsCvIDYihDVEk6QmxMLKSqiadDGnIjObCgGTWHLcFNRyNDkqghI+8RociXkDTaa2E6w8M6OUOoAjo2EIGojsOdhV4QkKENvJ2mQhCmn296PODnFRIoghsoJDR2SEti6kOioM/0Pg7IbuJjRw/XN+5UNmK68S9JE5N7tvy9ZEDhrPgcEDcY07yOCgnj8iR0d3S+TiC6g1gGpXsg986ocOCtzCNxr9xhM7mShHlEm5VipiGqmns0YTEjJyLyJcvUgITcddTS65J1WQt4Z55sOgbh7ncRRLYTt4EkqbghVodMvQVKvBdWQXJ4RW7S/QqpkA3sSOmRok8DHIjkOXRHDmnUb5Gtj510EBwiJEtjpHuLTafl6U8GFzDGLFXuIauodxTTQHgldEMS2SIcvsxPv5JkJWlE7NPrQTZS+FgpbmEPK5+tBdDDDUKpMVpXsVpEEZXIQ9DK8hPoYQ1Wlf6WFFKX9diNm73sMx9LgVn6XQZVP7HBNfW9D+C/Rw/pwVMeF+iB9x1TU8tIU/SG3sV7BMv14G3B5/YndH3/YnyDi82gE2nqf4LifRlHFbdIYp35EQf7GYW+RbwF1JZfKHf0S1l5GyUtyyJLigOVYY+SHV7Ff6jqUuKihLaCZJ7iXYErd0+5trQ7CJHd2Nwf0tDhkIjgJdhLI0yNrgbmDCfQQh79/AnV5ESNBZG6CcElRF6tySvMFxVkGqU6kleGYhlgpkm4aLYPkQoGGGyiiC8qvg7Xegm5HdIkZLUqWKxx/RrbyUqrdBsURHUl7IQ9YKI4YqVRCuSkVIVhhkWNxEHkZPqJtmpaKvYoSw8E1yHK8iAiwuLLrI7oh9SKX7IL0boVTY8kNQV5qLCasQqgZgLe7NjQ8ViPer5CclMlCdySWwisGg9qE25YWwqUGksGQwiOxHmBot/IleX5If6ij+0be47hTZTLEv6Gc3YQ3oCWx4FZY9tIWzxMk/wB/0XsnDY46N0lNuhcb4PE4iHoTp7kXU+ELTOhMbIVCsJKY/RR+n2hQU1Zn2Gk1w5E16iXsbFC5H0JerNk5YrjwXBORVOlpXx0Gq0qP0h+hKps1sxpXJm0Jyaqh1SuI9xTUmiZlqdhRLUJlNRFJonBLl7nREljMl4N15FAN6KocFOhFrPsVp4EfW4J0l5nUbgUWxlXsfYqvRDZED6hMXEy7EU6F1Iy3wXodX1kb4GiHD9tONBSJyh3A1/Zi3S7lG6LFWJ8M4E46EYdhDZBHyFEIkkvKq+Bjwm5A3SnC8fIc6tS1mLACCpB71HVu3wPCiHPg6hwpYPQOlAxMaHgtyZxHyXWSRXrtGhhUSSJYfUqiGySZSZArCMm0cLkujQ8mRYGkOD4Covckkm4fuMaFCG2AZppRYdtRC2BkXTIdIcIEQ5hZUbxsedpYJeY2bpUtTcmojgpdRpuJJoxu7DZjZITacuyT9hULoJgJJpqcP20nIoshFL5CBSDRlBWKxycpNgl8nB6lIFU8plf3fViTyvYmLNLF2H+GiwM6NawPNDtM/sNejb3/AEExNvNCLhXZJurV0eBuO1l8EPu4bK5Avt+CbwpSF1v0IrkJwRBtxxAyqQSxkK45Eycck3yE9OZT9BK2IlO4pqqTLrwwS3EU6DDo0bpjoN0ubOBjpsOCo+vJkCuzcSTewqUkS3uvcmfRAk0qWQ1BEcjdNvAxpssQpCd5LLwLe/AIEQmhzGSbORYvTQJGmU2ftoSxR2QoCnYjNjPXSmLJ5KdoEX0cgSs9ylPMsof9SDSPgRsruEsn1hj3X65HQ/gfuSvaT4qx1Zb5q/vcouOF9hDaphcX8kGtXx+yVKaJiwVYlb2EbuNuZJ4Jc3PXo52LKLEZ4EzinoMC2X5EjzBQqJmjKAoKiB3UDLodGYill+YXYXQOINxao10IRCa9T+EIUIOzWoiQ4Qyb9GSh3PVlcQdReVJpN6eSd97wKhPI1N2xdARsxO7KRuUMIWDZRRdQOJqKuPfTQseuP2DDmBQkpoTBGHHcdM+zQg7ki+DJau3oooFPJLKhwNy7FQUutIbkS6p4M15bFWVDL+qj3uFtZD/0W/0hLljinZCUpaZdiGyBFVR7Bkyx4LkW4kcdKpUFsNwQiRwExp1c5TcJqqoTwQ22oN+ajpPdDFATO5GNIPBWG/RYSZBnWBToif0qit04UajoHyZS3GL4UDQkxyEI2I0qWE2soc3LEENckNmRFHKuSzFgard+R5TECIFRPI3DGzVWhlBbWNJk2f4iweSQ8H+9+jpiELMaUEGYE+63gsiW+r4FbrqiqEukfITZcZMC3SPVJCK1alFYZUIqtiBEIW5WUCaVSjYSVYmqYG9gpE+BzVxpGqE/AmpURKmjIzYRKhUg3OwwrGxgpci2rKFpYTpEBKg6lkeYV0+Ri4EGbDYYyNDtrZ4QqVPQaa1GmSWQ9bFSGypQQmp142uhAVQHyKpWpTuMhIRBMsCZ4Q3CBtsQXQmZIbjRHH/yBLyMaOWfTqT3kXIslJcYdaQUF16tsVVWR9g2UwHJ9bEDlr+dCz2D1YqQUmMqEtkibS5C8KPkQgmTkQ+UQWCbYW0LdQ5CLsPf5Ci0+pEXqJ1QqZLxN3c8D6xXKFsN8jlXoN08CrYV7BGRUoS9R7DKXAzKQspHHhHOmDl3IJNEmKlW4m9h/PkrkgVMVR0TIPAq5bKCK+QOkQT7MWsFsxoo2CGNxsYGwzo2ehInZHVh90fBWfUVrCRGCrz0FNKb5jYfsu6GtFTage4Sv9rQcHRyygM64QiSxKbWRyDF2SJWSMoGq9KySbeyMcYSCQyaaz5ICOQaoyncViiZE7RNeXkUhW7MSRFZ5HPAo/wLCODGlUkKVHIzEnoIJbimSRJAsyYN6FC+qEGotTdESiNhJTFBHYSg2reok4Q3hDSjIHFSo5lqlFJgLJNj+gLBUG4FQMmH8hgSbAmcjZEpawmDHYYsn8zYn0O8PQhJZtTwdh3xUUV/whA0iczsFatI5cty6inyyCxToFpxF2IfA1bcNrimUS1Uz0FkMnoLczBsUmIoZEfbFDCMmIpKyEFKUVaoohMooKIqqyhGMmzZPYZ9gNxn1G4RFq0NrOpVDjwyjDQuZdhNPcS4IP8AGTPMlQbYpliruPgOucwTPrpsxhBKZH6DJUWR5FqI+YbpMkbiIOyHzFgZssUqhQsPfQg52fwIW4pNmBqP6GRY2RDcrhj5HbcdSUweBaCgbgcItG8Nyze5PyMrq+ghYWhRBNG0zwJXrUYlr4r8CEX67V2PrYhLnQY6q6wXVAyuZ3yLWiER4noNdwn7yONpdh8CalitgYejrry9jIB0/uRZVA3vaEWo8KaOo3JEoazL7giEY+odYUpWZJQxNKKCNuVkscEymKoLIgmmluUYzwQU3RRrIrVhNwdRtKA9jfsQ6LyI61m9xICI1xHYRai4dAoFBHJmqR8ENnlqZBmEsGQ3OoeGloJMEGBiJxYRQdSRhAlF0Whz9Eip4EG7VEWs5K5KiYHdSX/R0QIVtNr0N8hEZKXoPK7m7sRqCQkQVxfMQPdPqn+iJXweT3BDlomOZgQlLQLkSHEJWt1GUJ8kCYg2kTwqOq5kW5JFsTgMspxdrPAzUB/MS4PSQINVc3ZLFr7i9iVYqKdxJsJBTka9w2UtcGEG12VVA4acoRNJyXM8DcUdfTRJgTMNiEiWp5KDgtLiR8NEK8iItpcKEQjJQz+Ch0qBrmVYEGHQ2OcbC5E+fqIQNNMZszoh6iZ8EjG8FR2sVMbWgndgSaG7QPYL1DM3iTA3RZWqOGIWRYWJp5RG5MXZSbyMfz+8oX9n+BpnJeaDS1sQ6gtVNKWjHCVI4j3EtzXCp+zBhC5je37Eii9y89RnMhsd46jSt4EFL8SVLIrtmVYQslXWKFZU6OBvd2JK5p3kaWAieqbuy0HGhHFU1TlGkLAxubquxECGfPZH7mCHI2mKqI8Bh+7UFl3Vj0DjoW1XyVBXchbXSjKjP7jhuJ5X6M+XkvUiyqSk4MUG6tUcNrxQcu1xuWDsDU3WB4RZZIxdwLZvuMllTh2HVFhRB0ZsUbGwjjo8NbjLJvVJQ3I9lzYAAoblkMS277DE7JlVwuZDWwJtw8wqgJZYuaPkEtTh9wrBLqyOQ4CUJB1/wNt0Lr3CSVxO7GTdLHYHR1L7L/SRXKXXgOy2vwVWpfgndk1S2nZCXh0IuHNRsdGnqTxKNyjYltS3XpQT6sZuxmek4fofpnTRKMJAsm8VILTkQCBTD3CuzSqhRVW3zFtVt6zId2keB8KBS4l3Z8igXjQa4eA/zukGy9mGHoEK1SXuZzAEuVAmI5CKMV212P6IycQnKUSRFjRNOAlEtlKWZN0TEXh7Ack5m9yOUT5kkbs6GG09L044JtyZoceUPrUHrUF1fqvfiyrTcP8AxjYV2Gn9B/HYz22HsWDNHcXDk+4WnUW8AUU6jjyf2R9FkP8AockJ4M2ZZAk0kJJxBRTuV1UwBrRZHSSrOakbpDkbtbBPdkhSJC0Dk+Nl8u3uc5dvlVnNBjXGyU7kOU7DcLKRE2XwOtEPBbVClu6gi1bnYUEakPTiQVhBpI/gdcyxJeBtkvQdSHBOvRvokEobkSEnGhVkhFbJZsLKGxeiSBRjRULTepGCE9Ml7lJDeKhEk8o2LsKae40YB+YckkfzC3vlL4XbB0GsF9ElAG/s2tCC1ioZjGltv0AlSvLcvDeyMpqr6N/U2s7deqxzEof3sb7ATowyLcR0PJ0/J0vI9lDWcvK14loQ1s1JLFhHWxraOXmpu4kd6n4HL7KJb/YJbzXAlu0+6HQoxb2l3kmUxffJbJzN58laz8kll3UFyk8Kw2kG44Vx2ELA7Wz7lxQdIrjkacQ2+B/Vdwp3birUQyVxSsXTshSohO2lCQhIPXQRoSkWriT6CnoFogbukvK6fYgNqzJWXcjN2qNtZfcuuh2WvgfPqvuDmdCzx1GH9UPH5PKG3tVHF7Bfg3b1PwL/AEKPkK/pX2Ch85V8+Cut0TJ+V0LaqVKCTpoertbouhyhLyOYLfeRbjycjybqPU06iw5KuRPLgk2g4/g3IiOIXlUeyyy936HGeqrdyCz4fozKnNngVS6rf6kU+SG6iwq8l9j0NkrLdX5KMIxR6VwQh/RXQnewv6EanZ4LKsUU6PgSqayxcKOjZGuglZZJRDLhdLaIIP8ACPwrQg9IJTqGixnpn1bH5IrDJVtWFFLHRDurFwITYRQ9gSU+wgky2VejGXqosg6IYPvQ9kRjP9HIXOPkeXdloPZHNLcvI2DyQJLYjSCCBIQ0NaHpShoJPcEqJp2GX96LyP6ptzd0ZIolsF2LvQ/GRWYp+qoUIsFE9R+wRcYJt/A/l2wivBHquiIp7uKkKoEosoE2RhNoFbeRzCKsS/EMTRkaQPUtNPTF/qNj+hnnJ6BXQzpJ2QbqLTqJkK9n6DYrDPqLDYTsmQ1kW6UvZYWqy6BBIK6HS7JlEd86OZUFbzd3pBH4LRj/AAC6M6M99CnQtoXKE+sIUr5lRi5Yw/Y23eDGxsl5KnGN2UTJJvnqVFC9QqxpbKghTApaaMgbOxkYlgMLiELUQkNfmTELUWmnphPXobyhJny/RC0KMEVBE1QmGnJbr2PTRU3cN9aVlOgkE7p3cSIGOksi13e4vxgWrGPUQaGJwWVsj1S9ziILRf8AoNv2E7TCIT4sJc3Ldv4JIkhyLfa5XrW/8FRoqLZYnKBIgxp6iBTF1sQsIeVZAkIQhhCsMYsE/imNUs0vaLDQzhie71CjoxxbFNBZ0fEhkicpH+CDKZ+gggQgvNELSF50S/FaLVj1WpEGiNE4HF5RihjqNS/0WwKWqMlFEOZJW7FyaQt3c93GIYFpVpOKa3NsY9XpGqFoRI9AyBL8EVilNFSPQPpSdHMaIHJEJsKopqIxaslf1FBhFykx3YPe+BG7MtYZH5T+L0MNpgaGtYIJgp3SeSZYDrwJzVneBaUQIariCIIFPBvotjQxqMZcWwXv4uJzvl0EuztPuxvDwhIum9DI8reRttDaQMJ+UjhW0aosjDkShxIm1s2SSSS6aZKiFyxVyQVWCTgfu0ST/wBEPVjHXS76n+EDEOIjbcgCdCoiKtEheMWrSY4oxojZCV26IptO7d9FjrcWTu+/+6GFBDhocTzgUv6tt9SH/wAUnS0DZQvLGjpDD+MVuAdxzpVOo5NQOhonDuIEVaJu/P8A3L8G4HoG1Yx/gxKQqIT8SVkorcTJJjAbSNtpJKW3ZJZGwUK6L3P4WBNPKpIX2BiaDXlD41MM18uopE05TyqoQx/jJOhI2Uq5KekNnqNIf69iJHugyQ3iHTQPyd4Mc3bm/wDgWjJ/NLRi/BBr8logerEIIIa0Vo5ykx1+kjwqH1Y7LvnpqW4G4g3FWxGizIMZIa72f6fKJI2sd25/eh/gydZsY3kJo6IbHocC4veq0chvIFNFJahMiqlUaLej0P8AF/mxfif/AAWtWEohEISkzCFo0OdpDO7RHRTu9vF2SOo2vzN2LA1j64GGGOgdRPrHqpb4a8Ph8Fiiddv1s/kQf5mxsYOw2PMAwko9mRpUcwWfGhQ0UWGpIaW42dT7P/Nfgxhj0f4P81CvFZj29NUj9qQ8vIlNCF7+otDSLkgUywMo0LWK+CZQ5mUU/T5WR/g9FoY9QwyvvaJPMIaPbDdmJYYQRYUsjDqXX2dBkkpyn/yX4P8AIZGj0ejmdiXoJeRYY8vVFBbBwfSPwYv6KP0JfoY6GPR1kyE1G9NeP5j4eB/ixB5G9AxJX0XoSUbsLSgcUfRieC0LQTEGG1Mae5YYsnuWV/4Q9GtYIGIUq0QtHBdqNaW9EIeFCJb4R0yE8C/fJgEF0EtHgfyJQR8BvXcaewz+dFY0V9T7cb5Udwx/gVx6ynROesHpE3wyBKNrOg1rVrB5XRiaIYbQkOQm2g4Yl2S6/XH/AAj/AIBj1Y9HoQrqT0TG3MUZELSbNSr2l299NCjmRVyZQJHYJkTgoNgn3bQh6BtSXncLz+sl20ej0XDfivpCHQREjnVKQSnhjRK2qNEaIcc+mQPuJPKo1kQuyXX6/wCbelsf4sejeh7QeR1FohHPFF93a5JpdXkQWglAnQS2IMRLlYu1MsaLIsvcb7jZmhCpvgapX3H3Yr3n6SSnVXVXR1XoP8CWhja32xAkQdmsF/f8aUIFqMJq3LpKNWYuayWbf5/yY2jI/NrQtUIRK3U+277+x6wv8KK7mHPoJ/rsIqUorFLW/sdojvHgbenv/GK1H96CW1HGCDC/DUOSZXavqNAMepaGUuv2mqVbjVF30xpZGhLSw2iFE8jluthapLP/AIMeifxesDGWi1RR08T3PjuLWRPcWpWthTsJUFUSiYmLyLvjwJ0Y6L3KBtlpysbBp/CSPRQZGhDWj2dSaSJnaofte5/hJ9tC0sJjQmh/HLcNfm0PRGj1esDGIJaQJEoT9gWe7MxJgQqm4q29Rdewk9rFCdhMRgWz5FmPJtMiSnmyOobxHc3PxoVSKtCEsWf1DEyND0ZAw2sSLOTD0mbjVD18JaHohRIT0OTQ6oXSo72XysP7lfitH+BH5N2kDFrBG3yVz7IrE0pGDEo6iQLkT1uIeZhTp2HveD6RUti7nRUZFmikb7vQ3lE9x6PRBBAmnuvRCSrjVDz1HpQcbJ0pogcIS3IDlFI2mxFup9n8mPQx/wDMQlrHrZa+R+kCxovoe4SUVNryUCTsL/BK9BYdex6xyN96jq0PLGp4Hfdj6XGn8PiTPeXj+GXYbbEiY9CAiorgZBSm1SRqpXdRiC8rgWG+ohFTdX7jDY0iCQYkb2dBfUjLxUH5GbRRXc8PqO35NjaMSH+bGvwIsJG32GVw3bfcUTRsF7C6aF64ExNCgUPaCMUqnqN4e9BzkbuVdjdo934BaPgas/c09Qdb0+afwlKwaW1IbdBiNgiq8CxK+hcFoHKiKBpZFUIkrA0uRMbuJLKRjWkwn08iZ9wVElhuHUSKEe5PX/XuT2Y1BH/Ef5Ma/BE5xeo9YFFEsMnsLb6xGFI5KjFrCVn9RJNxlMWFfHQXwWHtsNWSIoslPVm16G8DY2mk+hSRA3Xxiu+sE3Ya0CVNyTsPCVXuUUEMSw+wJkkyIi89Cc6tGgxAqkQ8p0oILx66pxKql01lCtWo8dRiN2m+tn6GMZE2dErS/wAGQP8AJoQhE4jor3PVTsKJXgQSnUX2RIlTnSiYEqJncVCYnzWhjco4Kopb3G63vo6d9Hgy0q1Xhtcv3K0dHw3+67kA6OpFqFxMqCN1GJnpaQWJtQTReoyJTRm4nFe49FewUIqidBz6yJI48DZe5JdJdJMiXiT67PXVDGTYJH4PR/kxaIY2V+CGzLjNurc6Ugt1Fd5MBd7mKuxkidW47kuKw4oP70OHI+py7ohSBi1jrHP4gqEczJw1VPZqzIjwo2WiBvV7Coa0pqaFSdbKfJYH0KgsybqKeZGjtV5L96aQlzUiKr0fGN76Cqmw56R30NYSRVQzgicEffdeqEKhuwkkrU6JD1f4sehF/wBYvUfwKIJaEppJwJVjAv8ARKc2FbkVIwKa1iXYdEWF46D5LTuNjfsN99Demn2a1zsYCbJ+CO9Qmpb6DscAkFxJTGMkDnwUaad8CJCagYqT2DqXPYuK/A27VXyVktxDCV0Mf7GtW5xheBtnfq4dPI1O/ca0Zho8kB5j7MRT7DJrFb0RI2CI0aIGhoekfiI4Aruv+nYTQnqewuPQdNT0CwXPXkhV80kVuvoSrOS8PI53G/Ubt6jSM9xuS/DWunsMXCkJzF13VC3nmcEorULJlc9BjEJEHJcPEfbYTS1AlTmtP64kSele+uQjIoppeL2O1PuTTMdY87nd8D0MiYWUERp4e5l5FPrU9h0ZSPQHNAm2lX4tDX4vQpjZW3Yay8xu7kUSyFUWPY9xHkWfQRtJb/Ao5Z7j0bD3ueCYJZ33J3XQdhpXHdDrWaDUHigo2Wa3uBhiVZ1fl8HK8Dw2NUVVDEE0rO/QZAQsT1EiikE1XcnceVdM4dDGBgzKO9hjjKnRWfedGkY4tBDoG3xydr+2GvYTwxKiaxnUeqlR3VewnNyR3gfF3TsMJoSB/gyB6vR0cdioUQXsJnR/BuKnTBR0RXKSMFPUTdawvBCsPLg9RU42G/QcruN+o6YNgnI8nv17m5fxpJkDbj6xxAYmUQuBM6HJMsrkDzJcWLCrclEYoEqy0LfguZLkgUiPAiNO6JnzC9HxqS/FOwft9dR/YqKEuMJpUwnpnKEWUz03XZ0GtmKbW2Go0smaavV6PRiKOtF6j4QotkIKvVCgwnuz7BVCE5T6HkKfkjcJv1GV9r0JVYz6jh1+wT99x0TJqNcjeNDgannSuj3PjQw2pUeOuCUA+ksv2D/Kdjc5hkXarkpZE/AZhu4TGtrsnLoydWw+D7jYhyJnDySiukDb/wBCUE4WE2+y0sL8AlcpM0J7oa3GygIhoSZIicyq/cLuvYVPAMkQJBManox6MgY1WwG30Ske1yeX5QleRSvIrp3wLFEI6fzyJFcTuYfanQmjikjbf6PQhrbDu0XtY9hlyejI2yGtqZC0XX4G0IiG5CIpPKRiakLYNLtN0vMsoJXSfkrb4BCdKrhuzulc/wBDpONiNF+wSrUilF11I8UO7QxosdvV+uCaElQgn+icCTorR1ydH7GMa9fQgaJCWpqjZNPlClubrbJeRJK0iCUlGgnA1NVo9XoxnJm8L/BCyIIJUF1FQSvXQtsl1Ls+1yF9RbJRldMk+FbjRuaDdWSrLAl9yX7GUj+R276jep7y1CHGg+L2DmCMCMQ+wTvBUi07/CgqJifgqp6LEy0wPVaid6kNcs330fuNJhaKP3F0wS2VY+y65FSqlW/CPkayExtLQIeDGlTc8B7CfMPsh8ZLLmNIkejqJFjjHzZ9iGGLcJKhXwI1RDGCTVfg9HpCLap5H6RoQs40oljNyFKEbhKzivUTGL0IlpQ0eS26DcRS+xR60Gtk+ontycKw2MkUN8DfgbyZi6LvVaS0IbMeoyXqhcpxRbG4rIGDJkJbqhaRgKzdWh4axSHzglPGoaUwMTTO/oHB9k5qJWBRqK9htWX1KJsz8/4G/wAQQjj3F8iDbf6P7UuniOP6KO+jQmlVHtfF9GvUQgmLdhhBogoJGsDWjGO7ufli10po7kd6aNgq9hO3rknwvkUtuCkXmRzWSeegqU3yOL4GqPeR3RKoy0N/D5ehc9dvR99JaHOPfSYfuQHzD5Q83FJyiSgmTCRTls6e621OhRKSU7VKl2cFEkk9uBrRNFYfwT5l6FpU9ohVFaiyJ0Gs8DV+BL/0a9hqmw0xoaJIJxqOkv1i6FOGpNVdCFuijsh6IEgY00HCmrQxi0LcTcX8ExTSLCUSxerEpBNVtAvC8hNJ+9iyU1UL0H7ZJTf6JfbYbyP3G0le4/yVfCMJjDlVdTdDnIhJjkkhug3IpnNG2QF7Xk+eC1WS2YdJEJnYEvpExtDaWt7nSMqVq/gombXLNkxvAZcyyOiSJzVz4HAvbI64gj+CT30EX+W9/khLsFTceVTxXnTdSCxbOdX+AhAQQrdT0HuJFYoUvKMK1nKHdhefUmVRw/WCSPcrFKsdW2vAhDG/IxjDGMNpq6oYYYaw900LzEQpUjHQbgSKiVSjsKolMNqj2GxQdUxNJfB5DQEY6G50MJYu40VCzzbAn2401dfA1DHggY1pI2sI5T6EUt7Lt/q6HLgdkthIES0YmJqr8GIQmISl9BbiCCdyxkY9TcLLVv0ZVnQtPoP71JT1IJle5yNjVdF0fgfQLP2KaF+JLsMruNIsMiSSVWCIoEsOqF/MQ0VGaW1B+SbYwVWShvr2DDa8BO3IsToLGyE/AnS9R7WgakunWpHUiLzHIk3twP1Q1oghXnWkvGOr2Dj58MbVQ9uBBhOdVB+QVdCSJW0dT6ho+2EKH8CiHdVtwUrB3qrDGok7ntG6+4nBwsj8DPrcShQ/QpGHoSUxBBBh9CBouITqVpO26JR1IovuJ1mY8MlmGjZ3Ex2nwRB/I9lpcfW+B6rnQgu6myrqNUbAz7kzV+v9gvOfYsPc9G4/TA5r1EFrpXI5Sfg7exnJjGeha5EVJHoQTR4CdNxqrECWKKRcuT1ibM2HB7eROE5gmc0QujBVPBMod4ihM+R4ew3kfkfwWD6sCNm/cUQhtBWEhQnK0Xotwl5W4osOasayKirkSJu7I3c9c9loYbS+pXjqSprIndFQ6y9BPwFTqxvdxPA3Xag0+o1RieNtRSAZDaUbMPGzyhoWFI1XSdGgXJA9SdDqEuC9xJDWYq3z4HKiKHWsktWuNu7wRQtI9sPBN6RA6TyShDd0mPYbgbpVZGzgf4BPgg6rUnoT0Ue5K12HVFNn6+C41zrhrZxIywBu8oIhvcYezGTt5Fj8qGYQYonn0E4rgTqotncoi7qJMXyJnxyc3KVpBedhEm7QS5IV9t9MH8MW5G3URq2BJQNnqFEJYiolgbiwmwn7ipQLLwKqb3psKvMbHuHDVpgvVOCZG4IrMjsOiKFCY3I34GxmWokPykxMT0MJ6PEGlrqMeIjYhet9JT6jHsNfB1A4xqtRf8CXKZQKuyGpRn+OTPcai39zoUE8q/BGHnJ/QlV0GPwKsfhh0TY3zs+60Nn+MmOjlDEEhPXQgkxCUsQq4qrDee0E92y31UZRwRQboPFRqJ9CsSeBVyN166XQa5GPQhQvf2PSRMTJGFIeWN0RMv6604H3UbvAqCr9zGfsG+K8lAqGijnTekeNe7UaCz4ETZmWw0JF3sJ7zXgb6uLpEd7js/gdOo1ZO+Ddb8C4NV0uTX/aJhPc6jfYngTR6tD0pQxyKncVBOIFQw3ybrwVpHsVVb1rQnL8CV71drkmIUkDyP2G8xo64Jggr3Khqr6DtqZkUG5a86oTExajE0RVt4UbkC+cspQWkm88BvyWISEmv4ILYKmb+gmvjWfWbcTsKjoJwNB0GS4bkWKVFl0IvEjU7F603Hh9jfqNX9iNxL6U0N0K/c8P3G0tIMa/BA5FuKwlMci9hKRQ30GnGhaXKnwJLo7FYdehjtV5HaszImDp3H3aOg9hrA3xwOtB6HfoMaEIOzW8RI0096EtvxF9rH3Q9NIw9EJEpDoJWIMqtsLqb4rwLrFToOo9iqxEVdy65Y5019Lajj00ODgQpjkuLOgywu48r72HV70GlZZFm1Pslq7nIOeryeSGhRt4NP79BQapJQ6jSEgdSBi1EDYSLCtMVKCFlssmjQkRkT6iWVBnTr6EkcY0bhwdFQqJeCrI2SqZqR7EaMi+jlbev6H3Y4Ioy3wLqYNBCIa2GJE4Sz8Ch24riE6JI+oJRkSt2EKr8Y0TuL6Aun2D6E576VoUQLECv1GneS5ZGvNKku14tuOHEUWS9Go4ZEnWVcxsJ5Y/VF0QIXCU2z5MoYxQIEHoj0ajGzFcUSkWbYwM1J0PYtStPka5qhNqKlXca9BvSw0mYpQw0vRu5Z6IGSF/3HoQKCBWHYgj62EmuMciELkQjnKhlm+28laKNyeJa7K0DTARLiBK26PvuOPqtQT/AMExhZOq/uJ0E1QTFxb5GmKS9yrrYz8EHuum5Fnnknd9R1vgnEDUvoOLbj9AkyTZUGqzyhCXN+GroYxqRBoehX0LFBXjYT0GbqhWEYm3A2nDVhOZoG7jwNpXdyIgaipXRqkHLA3I3qPYQuOo88DX70Sq3fIvRliK+wSHt2Hn6I5pfohxCYEt0PXPhdBsE4ZXI7sIbODcEOIt6jgWr8Hrqm9tDaG3GF7jCfgTg6rCcR1FePDFRWBOsL9krrIlXLsSaOVh/UZehfRVoSrcH1uPUoxBCUKtHUJB0JxuSmuBtq6yLNbCbuOq5Y1NJtkckvSbigjJlOo3KOth6Oo6/J8jV+op6J8C0Kewbagz3PFEggGRlEuuyKJJFQEuIUHNFwiV3jEuMuxEUQWMjYlNR0aF0WciFUb0LpkSE46DXQwrOIvRETWa+CTbX8RSE+RL8jTiL8lYrYNRz0yRShgJoSIapnuR2duhcggUa0f/2Q==";
    const DEF = EXT_BASE ? EXT_BASE + "default.jpg" : DEF_B64;

    const NAMES = [
      "deline","gracie","maura","kenzie","alesha","brielle",
      "calista","dahlia","elodie","farrah","giselle","hazel",
      "ivana","jolie","kalila","lavina","mirela","nadine",
      "odette","priya","qiana","rosalie","selene","tamara",
      "unika","valera","winola","xenia","yasmin","zahira",
      "amara","bella","carissa","diandra","elara","fiona",
      "galina","helena","isadora","jasmine","kiara","lunara",
      "melody","naomi","olivia","petra","queenie","raisa",
      "sabrina","tessa","ursula","vanessa","willa","yvette",
      "zelda","anindya","bianca","citra","dewi","evelyn"
    ];

    const getUsed = () => {
      try {
        const data = JSON.parse(localStorage.getItem(USED_KEY) || "[]");
        return Array.isArray(data) ? data : [];
      } catch (_) {
        return [];
      }
    };

    const markUsed = name => {
      if (!name) return;

      try {
        const used = getUsed();

        if (!used.includes(name)) {
          used.push(name);
          localStorage.setItem(USED_KEY, JSON.stringify(used));
        }
      } catch (_) {}
    };

    // Generator ringan: tidak membangun array seluruh kombinasi.
    // Format: deline.maura692 atau deline_maura692.
    const pickName = (current, skip = []) => {
      const used = new Set(getUsed());
      const skipped = new Set(skip);

      // Percobaan acak dibatasi agar tetap ringan.
      for (let i = 0; i < 300; i++) {
        const first = NAMES[Math.floor(Math.random() * NAMES.length)];
        const second = NAMES[Math.floor(Math.random() * NAMES.length)];

        if (first === second) continue;

        const combo = first + "." + second;

        if (used.has(combo) || skipped.has(combo)) continue;

        const separator = Math.random() < 0.5 ? "." : "_";
        const number = String(
          Math.floor(Math.random() * 1000)
        ).padStart(3, "0");

        return {
          name: combo,
          user: (
            first + separator + second + number
          ).toLowerCase().slice(0, 30)
        };
      }

      // Fallback jika percobaan acak kebetulan berulang.
      for (const first of NAMES) {
        for (const second of NAMES) {
          if (first === second) continue;

          const combo = first + "." + second;

          if (used.has(combo) || skipped.has(combo)) continue;

          const separator = Math.random() < 0.5 ? "." : "_";
          const number = String(
            Math.floor(Math.random() * 1000)
          ).padStart(3, "0");

          return {
            name: combo,
            user: (
              first + separator + second + number
            ).toLowerCase().slice(0, 30)
          };
        }
      }

      return null;
    };

    const fromHref = anchor => {
      const match = (anchor.getAttribute("href") || "")
        .match(/^\/@([A-Za-z0-9._]+)\/?$/);

      return match ? match[1] : "";
    };

    // Deteksi username: URL terlebih dahulu.
    // Tidak memindai document.documentElement.innerHTML.
    const detectUser = () => {
      const match = location.pathname.match(/^\/@([^/]+)\/?$/);

      if (match && match[1]) {
        try {
          return decodeURIComponent(match[1]);
        } catch (_) {
          return match[1];
        }
      }

      try {
        const username =
          require("CurrentUserInitialData").USERNAME || "";

        if (username) return username;
      } catch (_) {}

      const links = document.querySelectorAll(
        'nav a[href^="/@"], ' +
        '[role="navigation"] a[href^="/@"], ' +
        'header a[href^="/@"]'
      );

      for (let i = links.length - 1; i >= 0; i--) {
        const username = fromHref(links[i]);
        if (username) return username;
      }

      return "";
    };

    const style = document.createElement("style");
    style.id = "ppt-style";
    style.textContent = `
      #ppt-panel{position:relative;padding-top:10px}
      #ppt-panel *{box-sizing:border-box}
      #ppt-head{margin:0 0 8px}
      #ppt-title{font-size:14px;font-weight:700}
      #ppt-sub{font-size:11px;color:#9a9aa8;margin-top:1px}
      #ppt-avatar{
        display:block;width:56px;height:56px;margin:0 auto 6px;
        object-fit:cover;border-radius:99px;background:#24242d;
        border:2px solid #2c2c36;box-shadow:0 0 0 2px #7c5cff
      }
      #ppt-panel label.f{
        display:block;margin:6px 0 2px;font-size:11px;color:#9a9aa8
      }
      #ppt-panel input[type=text],#ppt-panel textarea{
        display:block;width:100%;padding:5px 8px;height:30px;
        border-radius:8px;border:1px solid #34343f;background:#1e1e26;
        color:#f2f2f7;font:inherit;font-size:12.5px;outline:0
      }
      #ppt-panel input[type=text]:focus,
      #ppt-panel textarea:focus{border-color:#7c5cff}
      #ppt-pick{
        display:flex;align-items:center;gap:6px;margin-top:6px;
        padding:6px 8px;font-size:12px;border:1px dashed #44445a;
        border-radius:8px;color:#c8c8d4;cursor:pointer
      }
      #ppt-pick:hover{border-color:#7c5cff;background:#1e1e26}
      #ppt-pick input{position:absolute;opacity:0;width:1px;height:1px}
      #ppt-pick svg{width:15px;height:15px;flex:none}
      #ppt-fname{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      #ppt-row{display:flex;gap:6px;width:100%}
      #ppt-row input{flex:1;min-width:0}
      #ppt-check{
        padding:0 12px;border:0;border-radius:8px;background:#2c2c3a;
        color:#f2f2f7;cursor:pointer;font:inherit;font-size:12px
      }
      #ppt-check:hover{background:#3a3a4c}
      #ppt-status{
        margin:8px 0;padding:5px 8px;border-radius:8px;
        background:#1e1e26;color:#b4b4c2;font-size:11.5px;
        word-break:break-word
      }
      #ppt-status[data-k=ok]{background:#14301f;color:#7fe3a4}
      #ppt-status[data-k=err]{background:#3a1b1b;color:#ff9b9b}
      #ppt-status[data-k=busy]{background:#241f3d;color:#c4b8ff}
      #ppt-upload{
        display:flex;align-items:center;justify-content:center;gap:8px;
        width:100%;padding:8px 10px;border:0;border-radius:8px;
        background:#7c5cff;color:#fff;font:inherit;font-weight:600;
        cursor:pointer
      }
      #ppt-upload:hover:not(:disabled){background:#6a49f0}
      #ppt-upload:disabled{opacity:.55;cursor:not-allowed}
      #ppt-upload.busy::before{
        content:"";width:14px;height:14px;
        border:2px solid rgba(255,255,255,.4);border-top-color:#fff;
        border-radius:99px;animation:ppt-spin .7s linear infinite
      }
      @keyframes ppt-spin{to{transform:rotate(360deg)}}
    `;

    document.head.appendChild(style);

    const panel = document.createElement("div");
    panel.id = "ppt-panel";

    panel.innerHTML = `
      <div id="ppt-head">
        <div id="ppt-title">Threads Profil Greysyaa</div>
        <div id="ppt-sub">Ganti foto profil dan username</div>
      </div>
      <img id="ppt-avatar" alt="Pratinjau foto profil">

      <label class="f" for="ppt-url">URL gambar</label>
      <textarea id="ppt-url" rows="1"
        placeholder="Kosongkan untuk memakai foto default"
        style="resize:none;overflow:hidden;white-space:nowrap"></textarea>

      <label id="ppt-pick">
        <svg viewBox="0 0 20 20" fill="none" stroke="currentColor"
          stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
          <path d="M10 13V3M6 7l4-4 4 4M3 13v3a1 1 0 001 1h12a1 1 0 001-1v-3"/>
        </svg>
        <span id="ppt-fname">Atau pilih file dari perangkat</span>
        <input id="ppt-file" type="file" accept="image/*">
      </label>

      <label class="f" for="ppt-user">Username saat ini</label>
      <input id="ppt-user" type="text">

      <label class="f" for="ppt-newuser">Username baru</label>
      <div id="ppt-row">
        <input id="ppt-newuser" type="text"
          placeholder="Contoh: deline.maura692">
        <button id="ppt-rand" type="button" title="Acak nama"
          style="padding:0 10px;border:0;border-radius:8px;background:#2c2c3a;color:#f2f2f7;cursor:pointer">🎲</button>
        <button id="ppt-check" type="button">Cek</button>
      </div>

      <label class="f" for="ppt-bio">Bio</label>
      <textarea id="ppt-bio" rows="2" placeholder="Bio profil..." style="resize:vertical"></textarea>

      <label class="f" for="ppt-extlink">Tautan / Link</label>
      <input id="ppt-extlink" type="text" placeholder="https://example.com">

      <div id="ppt-status" role="status">Siap.</div>
      <button id="ppt-upload" type="button">Simpan perubahan</button>
    `;

    getBody().appendChild(panel);

    const $ = selector => panel.querySelector(selector);
    const URLInput = $("#ppt-url");
    const fileInput = $("#ppt-file");
    const avatar = $("#ppt-avatar");
    const status = $("#ppt-status");
    const uploadButton = $("#ppt-upload");
    const currentInput = $("#ppt-user");
    const newInput = $("#ppt-newuser");
    const bioInput = $("#ppt-bio");
    const extLinkInput = $("#ppt-extlink");
    const fileName = $("#ppt-fname");
    const defaultFileName = "Atau pilih file dari perangkat";

    const setStatus = (message, kind) => {
      status.textContent = message;
      status.dataset.k = kind || "";
    };

    // Cache token untuk menghindari pembacaan HTML berulang.
    const tokenCache = new Map();

    const token = regex => {
      const key = regex.source;

      if (tokenCache.has(key)) {
        return tokenCache.get(key);
      }

      const match = getHTMLSnapshot().match(regex);
      const value = match?.[1] || "";

      tokenCache.set(key, value);
      return value;
    };

    const getCsrf = () => {
      const match = document.cookie.match(/csrftoken=([^;]+)/);

      if (!match) {
        throw Error("Cookie CSRF tidak ditemukan. Muat ulang Threads.");
      }

      return match[1];
    };

    const checkUsername = async name => {
      if (window.__chk) {
        try {
          const params = new URLSearchParams(window.__chk.body);
          const variables = JSON.parse(params.get("variables") || "{}");

          variables.username = name;
          params.set("variables", JSON.stringify(variables));

          const response = await fetch("/graphql/query", {
            method: "POST",
            credentials: "include",
            headers: window.__chk.headers,
            body: params.toString()
          });

          const result = JSON.parse(
            (await response.text()).replace(/^for \(;;\);/, "")
          );

          if (result?.data?.xdt_check_username) {
            return result.data.xdt_check_username;
          }
        } catch (_) {}
      }

      const csrf = getCsrf();

      const mod = (moduleName, key) => {
        try {
          return require(moduleName)[key] || "";
        } catch (_) {
          return "";
        }
      };

      const lsd =
        mod("LSD", "token") ||
        token(/"LSD",\[\],\{"token":"([^"]+)"/);

      const dtsg =
        mod("DTSGInitialData", "token") ||
        token(/"DTSGInitialData",\[\],\{"token":"([^"]+)"/);

      let jazoest = token(/jazoest=(\d+)/);

      if (!jazoest && dtsg) {
        let sum = 0;

        for (const character of dtsg) {
          sum += character.charCodeAt(0);
        }

        jazoest = "2" + sum;
      }

      const actor = token(/"actorID":"(\d+)"/);
      const revision =
        token(/"__rev":(\d+)/) ||
        token(/"server_revision":(\d+)/);

      const params = {
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name:
          "BarcelonaEditProfileUsernamePageCheckMutation",
        server_timestamps: "true",
        doc_id: "28469084019418579",
        variables: JSON.stringify({
          username: name,
          device_id: crypto.randomUUID().toUpperCase()
        }),
        __user: "0",
        __a: "1",
        __comet_req: "29",
        dpr: "1",
        __crn: "comet.threads.BarcelonaProfileThreadsColumnRoute"
      };

      if (dtsg) params.fb_dtsg = dtsg;
      if (lsd) params.lsd = lsd;
      if (jazoest) params.jazoest = jazoest;
      if (actor) params.av = actor;

      if (revision) {
        params.__rev = revision;
        params.__spin_r = revision;
        params.__spin_b = "trunk";
      }

      const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-csrftoken": csrf,
        "x-ig-app-id": APP,
        "x-asbd-id": "359341",
        "x-fb-friendly-name":
          "BarcelonaEditProfileUsernamePageCheckMutation"
      };

      if (lsd) headers["x-fb-lsd"] = lsd;

      const response = await fetch("/graphql/query", {
        method: "POST",
        credentials: "include",
        headers,
        body: new URLSearchParams(params).toString()
      });

      const raw = await response.text();
      let result;

      try {
        result = JSON.parse(raw.replace(/^for \(;;\);/, ""));
      } catch (_) {
        console.log("Cek username raw:", raw);

        throw Error(
          "Respons cek username bukan JSON (HTTP " +
          response.status + "). Lihat console."
        );
      }

      console.log(
        "Cek username JSON:",
        JSON.stringify(result.data),
        JSON.stringify(result.errors || null)
      );

      const findAvailable = object => {
        if (!object || typeof object !== "object") return null;
        if ("available" in object) return object;

        for (const key in object) {
          const found = findAvailable(object[key]);
          if (found) return found;
        }

        return null;
      };

      return findAvailable(result.data) || { available: null };
    };

    const initialUser = detectUser();
    currentInput.value = initialUser;

    setStatus(
      initialUser
        ? "Username terdeteksi: " + initialUser + ". Pastikan benar."
        : "Username tidak terdeteksi. Ketik manual."
    );

    avatar.onerror = () => {
      if (avatar.src !== DEF_B64 && !URLInput.value.trim() && !selectedFile) {
        avatar.src = DEF_B64;
      }
    };
    avatar.src = DEF;

    let selectedFile = null;
    let pendingName = null;

    const fillRandomName = () => {
      const picked = pickName(
        currentInput.value.trim() || initialUser
      );

      if (!picked) {
        setStatus("Daftar kombinasi nama habis.", "err");
        return;
      }

      pendingName = picked;
      markUsed(picked.name);
      newInput.value = picked.user;
      setStatus("Username baru: " + picked.user);
    };

    $("#ppt-rand").onclick = fillRandomName;

    if (initialUser) fillRandomName();

    const onKey = event => {
      if (event.key === "Escape") closeAll();
    };

    document.addEventListener("keydown", onKey);

    cleanups.push(() => {
      if (avatar.src.startsWith("blob:")) {
        URL.revokeObjectURL(avatar.src);
      }

      document.removeEventListener("keydown", onKey);
      panel.remove();
      style.remove();
    });

    URLInput.oninput = () => {
      if (!selectedFile) {
        avatar.src = URLInput.value.trim() || DEF;
      }
    };

    fileInput.onchange = () => {
      selectedFile = fileInput.files?.[0] || null;

      if (!selectedFile) {
        fileName.textContent = defaultFileName;
        avatar.src = URLInput.value.trim() || DEF;
        return;
      }

      if (
        !selectedFile.type.startsWith("image/") ||
        selectedFile.size > 20 * 1024 * 1024
      ) {
        selectedFile = null;
        fileInput.value = "";
        fileName.textContent = defaultFileName;
        setStatus("Pilih gambar maksimal 20 MB.", "err");
        return;
      }

      if (avatar.src.startsWith("blob:")) {
        URL.revokeObjectURL(avatar.src);
      }

      avatar.src = URL.createObjectURL(selectedFile);
      fileName.textContent = selectedFile.name;
      setStatus("File dipilih. Kolom URL diabaikan.");
    };

    $("#ppt-check").onclick = async () => {
      const username = newInput.value.trim().replace(/^@/, "");

      if (!username) {
        setStatus("Isi username baru dulu.", "err");
        return;
      }

      setStatus("Mengecek username...", "busy");

      try {
        const result = await checkUsername(username);

        if (result.available === null) {
          setStatus(
            "Server tidak memberi hasil cek. Simpan akan tetap divalidasi server.",
            "busy"
          );
        } else if (result.available) {
          setStatus("@" + username + " tersedia.", "ok");
        } else {
          setStatus(
            result.error_message || "@" + username + " tidak tersedia.",
            "err"
          );
        }
      } catch (error) {
        setStatus("Gagal: " + (error.message || error), "err");
      }
    };

    uploadButton.onclick = async () => {
      const current = currentInput.value.trim() || detectUser();
      currentInput.value = current;

      const requestedName = newInput.value.trim().replace(/^@/, "");
      const imageUrl = URLInput.value.trim() || DEF;

      // Mempertahankan perilaku lama: URL default digunakan
      // ketika pengguna tidak memilih file atau memasukkan URL.
      const hasPhoto = !!(selectedFile || imageUrl);
      const changeName = !!(
        requestedName && requestedName !== current
      );

      const bioVal = bioInput ? bioInput.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").trim() : "";
      const extLinkVal = extLinkInput ? extLinkInput.value.trim() : "";
      const hasBioOrLink = !!(bioVal || extLinkVal);

      if (!current) {
        setStatus("Username tidak terdeteksi. Ketik manual.", "err");
        return;
      }

      if (!hasPhoto && !changeName && !hasBioOrLink) {
        setStatus("Pilih foto, isi username baru, bio, atau link.", "err");
        return;
      }

      let success = false;
      uploadButton.disabled = true;
      uploadButton.classList.add("busy");

      try {
        const csrf = getCsrf();
        let newUsername = current;
        let usedName = null;

        let uploadId = null;

        setStatus("Memproses username & foto secara paralel...", "busy");

        const resolveUsernameTask = async () => {
          if (!changeName) return;

          let candidate = requestedName;
          let picked =
            pendingName && pendingName.user === requestedName
              ? pendingName
              : null;

          const skipped = [];
          let attempts = 0;

          while (true) {
            const check = await checkUsername(candidate);

            if (check.available !== false) break;

            if (!picked || ++attempts >= 8) {
              throw Error(
                check.error_message || "Username tidak tersedia."
              );
            }

            markUsed(picked.name);
            skipped.push(picked.name);

            picked = pickName(current, skipped);

            if (!picked) {
              throw Error("Daftar kombinasi nama habis.");
            }

            candidate = picked.user;
            newInput.value = candidate;
            pendingName = picked;
          }

          newUsername = candidate;
          usedName = picked ? picked.name : null;
        };

        const uploadPhotoTask = async () => {
          if (!hasPhoto) return;

          let source = selectedFile;

          if (!source) {
            let response;
            try {
              response = await fetch(imageUrl, {
                mode: "cors",
                credentials: "omit"
              });
            } catch (_) {
              if (imageUrl === DEF && DEF !== DEF_B64) {
                response = await fetch(DEF_B64);
              } else {
                throw Error(
                  "Gagal mengunduh URL (CORS atau link kedaluwarsa). " +
                  "Simpan gambar lalu pilih lewat file."
                );
              }
            }

            if (!response.ok) {
              throw Error(
                "URL gagal diunduh: HTTP " + response.status +
                " (link mungkin kedaluwarsa)."
              );
            }

            source = await response.blob();
          }

          const bitmap = await createImageBitmap(source);
          let jpeg;
          const width = bitmap.width;
          const height = bitmap.height;

          try {
            if (source.type === "image/jpeg") {
              jpeg = source;
            } else {
              const canvas = document.createElement("canvas");
              canvas.width = width;
              canvas.height = height;
              canvas.getContext("2d").drawImage(bitmap, 0, 0);

              jpeg = await new Promise((resolve, reject) => {
                canvas.toBlob(
                  blob => blob
                    ? resolve(blob)
                    : reject(Error("Konversi JPEG gagal")),
                  "image/jpeg",
                  0.92
                );
              });
            }
          } finally {
            bitmap.close();
          }

          uploadId = String(Date.now());

          const uploadResponse = await fetch(
            "/rupload_igphoto/fb_uploader_" + uploadId,
            {
              method: "POST",
              credentials: "include",
              headers: {
                "x-csrftoken": csrf,
                "x-entity-type": "image/jpeg",
                "x-entity-name": "fb_uploader_" + uploadId,
                "x-entity-length": String(jpeg.size),
                "offset": "0",
                "x-ig-app-id": APP,
                "x-instagram-rupload-params": JSON.stringify({
                  is_sidecar: "0",
                  is_threads: "1",
                  media_type: 1,
                  upload_id: uploadId,
                  upload_media_height: height,
                  upload_media_width: width
                }),
                "Content-Type": "image/jpeg",
                "Accept": "*/*"
              },
              body: jpeg
            }
          );

          const uploadText = await uploadResponse.text();

          if (!uploadResponse.ok) {
            throw Error("Upload gagal: HTTP " + uploadResponse.status);
          }

          let uploadResult;

          try {
            uploadResult = JSON.parse(uploadText);
          } catch (_) {
            throw Error("Respons upload tidak dikenali.");
          }

          if (uploadResult.status !== "ok") {
            throw Error("Upload ditolak.");
          }
        };

        await Promise.all([resolveUsernameTask(), uploadPhotoTask()]);

        setStatus("Menyimpan ke profil...", "busy");

        // Snapshot HTML hanya dibaca saat proses simpan.
        // Endpoint dan parameter autentikasi tetap dipertahankan.
        const html = getHTMLSnapshot();

        const bloksVersion =
          (
            html.match(/"versioningID":"([a-f0-9]{20,})"/) ||
            html.match(/"bloks_version_id":"([a-f0-9]{20,})"/) ||
            []
          )[1] || "";

        const headers = {
          "Content-Type": "application/x-www-form-urlencoded",
          "x-csrftoken": csrf,
          "x-ig-app-id": APP,
          "x-asbd-id": "359341",
          "x-fb-friendly-name": "useBarcelonaEditProfileMutation"
        };

        if (bloksVersion) {
          headers["x-bloks-version-id"] = bloksVersion;
        }

        // Nama lengkap mengikuti username baru.
        const variables = {
          biography: bioVal,
          external_url: extLinkVal,
          username: newUsername,
          name: newUsername,
          is_private: false,
          profile_picture_upload_id: uploadId,
          remove_profile_picture: false,
          copy_ig_profile_picture_to_text_post_app: false,
          __relay_internal__pv__BarcelonaHasStylingInforelayprovider: false
        };

        const body = new URLSearchParams({
          fb_api_req_friendly_name: "useBarcelonaEditProfileMutation",
          fb_api_caller_class: "RelayModern",
          doc_id: "28671854302499863",
          variables: JSON.stringify(variables)
        });

        const saveResponse = await fetch("/graphql/query", {
          method: "POST",
          credentials: "include",
          headers,
          body: body.toString()
        });

        const saveText = await saveResponse.text();
        let saveResult;

        try {
          saveResult = JSON.parse(saveText);
        } catch (_) {
          throw Error(
            "Respons bukan JSON (HTTP " + saveResponse.status + ")."
          );
        }

        console.log("Edit profile response:", saveResult);

        const result = saveResult?.data?.data;

        if (result?.status === "SUCCESS") {
          success = true;

          if (usedName) markUsed(usedName);

          const oldUsername = current;
          currentInput.value = newUsername;
          newInput.value = "";

          window.postMessage(
            { type: "PPT_USERNAME_SAVED", username: newUsername, oldUsername },
            "*"
          );

          setStatus("Berhasil! Memuat ulang otomatis...", "ok");

          setTimeout(() => {
            const path = location.pathname;

            if (
              newUsername !== oldUsername &&
              path.toLowerCase().startsWith(
                "/@" + oldUsername.toLowerCase()
              )
            ) {
              location.replace(
                path.replace(/^\/@[^/]+/, "/@" + newUsername) +
                location.search
              );
            } else {
              location.reload();
            }
          }, 300);
        } else {
          throw Error(
            result?.error_message ||
            "Respons tidak SUCCESS, cek console."
          );
        }
      } catch (error) {
        setStatus("Gagal: " + (error.message || error), "err");
        console.error(error);
      } finally {
        uploadButton.classList.remove("busy");
        uploadButton.disabled = success;
      }
    };
  }

  // ===============================================================
  // PANEL HAPUS POSTINGAN
  // ===============================================================
  function RUN_DEL() {
    if (!/(^|\.)threads\.(com|net)$/.test(location.hostname)) return;
    if (!document.body) return;
    if (document.getElementById("ppt-del-panel")) return;

    const ALPHA =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

    // Shortcode URL (/post/XXXX) -> ID numerik media
    const codeToId = code => {
      let n = 0n;
      for (const c of code) {
        const i = ALPHA.indexOf(c);
        if (i < 0) return "";
        n = n * 64n + BigInt(i);
      }
      return n.toString();
    };

    const sleep = ms => new Promise(r => setTimeout(r, ms));

    const style = document.createElement("style");
    style.id = "ppt-del-style";
    style.textContent = `
      #ppt-del-panel{position:relative;padding-top:10px}
      #ppt-del-panel *{box-sizing:border-box}
      #ppt-del-head{margin:0 0 8px}
      #ppt-del-title{font-size:14px;font-weight:700}
      #ppt-del-sub{font-size:11px;color:#9a9aa8;margin-top:1px}
      #ppt-del-panel label.f{
        display:block;margin:8px 0 2px;font-size:11px;color:#9a9aa8
      }
      #ppt-del-panel input[type=text]{
        display:block;width:100%;padding:5px 8px;height:30px;
        border-radius:8px;border:1px solid #34343f;background:#1e1e26;
        color:#f2f2f7;font:inherit;font-size:12.5px;outline:0
      }
      #ppt-del-panel input[type=text]:focus{border-color:#e5484d}
      #ppt-del-count{
        margin:6px 0;padding:5px 8px;border-radius:8px;
        background:#1e1e26;color:#b4b4c2;font-size:11.5px;
        word-break:break-word
      }
      #ppt-del-status{
        margin:8px 0;padding:5px 8px;border-radius:8px;
        background:#1e1e26;color:#b4b4c2;font-size:11.5px;
        word-break:break-word
      }
      #ppt-del-status[data-k=ok]{background:#14301f;color:#7fe3a4}
      #ppt-del-status[data-k=err]{background:#3a1b1b;color:#ff9b9b}
      #ppt-del-status[data-k=busy]{background:#241f3d;color:#c4b8ff}
      #ppt-del-bar{height:6px;border-radius:99px;background:#24242d;
        overflow:hidden;margin:6px 0}
      #ppt-del-fill{height:100%;width:0;background:#e5484d;
        transition:width .2s}
      .ppt-del-btn{
        display:flex;align-items:center;justify-content:center;gap:8px;
        width:100%;padding:8px 10px;margin-top:6px;border:0;border-radius:8px;
        background:#2c2c3a;color:#f2f2f7;font:inherit;font-weight:600;
        cursor:pointer
      }
      .ppt-del-btn:hover:not(:disabled){background:#3a3a4c}
      .ppt-del-btn:disabled{opacity:.5;cursor:not-allowed}
      #ppt-del-go{background:#e5484d}
      #ppt-del-go:hover:not(:disabled){background:#c93a3f}
    `;
    document.head.appendChild(style);

    const panel = document.createElement("div");
    panel.id = "ppt-del-panel";
    panel.innerHTML = `
      <div id="ppt-del-head">
        <div id="ppt-del-title">Hapus Postingan</div>
        <div id="ppt-del-sub"></div>
      </div>

      <label class="f" for="ppt-del-user"></label>
      <input id="ppt-del-user" type="text">

      <button id="ppt-del-scan" class="ppt-del-btn" type="button">
        1. Pindai postingan
      </button>
      <div id="ppt-del-count">Belum dipindai.</div>

      <div id="ppt-del-bar"><div id="ppt-del-fill"></div></div>
      <div id="ppt-del-status" role="status">Siap.</div>

      <button id="ppt-del-go" class="ppt-del-btn" type="button" disabled>
        2. Hapus Postingan
      </button>
      <button id="ppt-del-stop" class="ppt-del-btn" type="button" disabled>
        Berhenti
      </button>
    `;
    getBody().appendChild(panel);

    const $ = s => panel.querySelector(s);
    const userInput = $("#ppt-del-user");
    const countBox = $("#ppt-del-count");
    const statusBox = $("#ppt-del-status");
    const fill = $("#ppt-del-fill");
    const scanBtn = $("#ppt-del-scan");
    const goBtn = $("#ppt-del-go");
    const stopBtn = $("#ppt-del-stop");

    const setStatus = (m, k) => {
      statusBox.textContent = m;
      statusBox.dataset.k = k || "";
    };

    // Username dari URL profil: /@username
    const userFromPath = () => {
      const m = location.pathname.match(/^\/@([^/]+)/);
      if (!m) return "";
      try {
        return decodeURIComponent(m[1]);
      } catch (_) {
        return m[1];
      }
    };
    userInput.value = userFromPath();

    let ids = [];
    let running = false;
    let stopFlag = false;

    const updateGo = () => {
      goBtn.disabled = running || !ids.length;
      goBtn.textContent = ids.length
        ? "2. Hapus " + ids.length + " postingan"
        : "2. Hapus Postingan";
    };

    cleanups.push(() => {
      stopFlag = true;
      panel.remove();
      style.remove();
    });

    // ---------- Pindai: scroll otomatis, kumpulkan link /post/ ----------
    const collect = (user, bag) => {
      const lower = user.toLowerCase();

      document.querySelectorAll('a[href*="/post/"]').forEach(a => {
        const m = (a.getAttribute("href") || "").match(
          /^\/@([A-Za-z0-9._]+)\/post\/([A-Za-z0-9_-]+)/
        );

        if (!m || m[1].toLowerCase() !== lower) return;

        const id = codeToId(m[2]);
        if (id) bag.set(m[2], id);
      });
    };

    scanBtn.onclick = async () => {
      if (running) return;

      const user = userInput.value.trim().replace(/^@/, "");

      if (!user) {
        setStatus("Isi username akun.", "err");
        return;
      }

      if (userFromPath().toLowerCase() !== user.toLowerCase()) {
        setStatus(
          "Buka halaman profil @" + user + " dulu, lalu pindai.",
          "err"
        );
        return;
      }

      running = true;
      stopFlag = false;
      scanBtn.disabled = true;
      stopBtn.disabled = false;
      goBtn.disabled = true;
      fill.style.width = "0";

      const bag = new Map();
      let stale = 0;

      try {
        window.scrollTo(0, 0);
        await sleep(600);

        while (!stopFlag && stale < 5) {
          const before = bag.size;

          collect(user, bag);

          window.scrollTo(0, document.documentElement.scrollHeight);
          await sleep(1300);

          collect(user, bag);

          stale = bag.size === before ? stale + 1 : 0;
          countBox.textContent = "Memindai... " + bag.size + " postingan";
        }

        ids = [...bag.values()];
        window.scrollTo(0, 0);

        countBox.textContent = ids.length + " postingan ditemukan.";
        setStatus(
          ids.length
            ? "Pindai selesai. Klik Hapus Postingan."
            : "Tidak ada postingan ditemukan di tab ini.",
          ids.length ? "ok" : "err"
        );
      } catch (e) {
        setStatus("Gagal memindai: " + (e.message || e), "err");
      } finally {
        running = false;
        scanBtn.disabled = false;
        stopBtn.disabled = true;
        updateGo();
      }
    };

    // ---------- Hapus satu postingan ----------
    const setHeader = (h, name, value) => {
      for (const k of Object.keys(h)) {
        if (k.toLowerCase() === name.toLowerCase()) delete h[k];
      }
      h[name] = value;
    };

    const hasHeader = (h, name) =>
      Object.keys(h).some(k => k.toLowerCase() === name.toLowerCase());

    const buildDelete = id => {
      let params;
      let headers;

      if (window.__tpl) {
        // Pakai request asli dari halaman (token, av, __rev, dll. lengkap)
        params = new URLSearchParams(window.__tpl.body);
        headers = { ...window.__tpl.headers };
      } else {
        // Cadangan: bangun sendiri dari token halaman
        const a = getAuth();

        if (!a.dtsg) {
          throw Error(
            "Token belum ditemukan. Scroll halaman sebentar lalu coba lagi."
          );
        }

        params = new URLSearchParams({
          __user: "0",
          __a: "1",
          __req: "1",
          dpr: "1",
          __ccg: "GOOD",
          __comet_req: "29",
          fb_dtsg: a.dtsg,
          __spin_b: "trunk",
          __crn: "comet.threads.BarcelonaProfileThreadsColumnRoute"
        });

        if (a.actor) params.set("av", a.actor);
        if (a.lsd) params.set("lsd", a.lsd);
        if (a.jazoest) params.set("jazoest", a.jazoest);

        if (a.revision) {
          params.set("__rev", a.revision);
          params.set("__spin_r", a.revision);
        }

        headers = {
          "x-csrftoken": a.csrf,
          "x-ig-app-id": APP,
          "x-asbd-id": "359341"
        };

        if (a.lsd) headers["x-fb-lsd"] = a.lsd;
      }

      params.set("fb_api_caller_class", "RelayModern");
      params.set("fb_api_req_friendly_name", DEL_NAME);
      params.set("server_timestamps", "true");
      params.set("variables", JSON.stringify({ mediaID: id }));
      params.set("doc_id", DEL_DOC_ID);

      setHeader(
        headers,
        "Content-Type",
        "application/x-www-form-urlencoded"
      );
      setHeader(headers, "x-fb-friendly-name", DEL_NAME);

      if (!hasHeader(headers, "x-ig-app-id")) {
        headers["x-ig-app-id"] = APP;
      }

      if (!hasHeader(headers, "x-csrftoken")) {
        const m = document.cookie.match(/csrftoken=([^;]+)/);
        if (m) headers["x-csrftoken"] = m[1];
      }

      return { params, headers };
    };

    // Endpoint hapus sesuai tangkapan manual: /api/graphql
    const deleteOne = async id => {
      const { params, headers } = buildDelete(id);

      const res = await fetch("/api/graphql", {
        method: "POST",
        credentials: "include",
        headers,
        body: params.toString()
      });

      if (res.status === 429) throw Error("RATE_LIMIT");

      const text = await res.text();
      let json;

      try {
        json = JSON.parse(text.replace(/^for \(;;\);/, ""));
      } catch (_) {
        console.log("Hapus gagal (bukan JSON):", id, text);
        throw Error("Respons bukan JSON (HTTP " + res.status + ").");
      }

      // Cari did_delete di mana pun posisinya dalam respons
      const findFlag = o => {
        if (!o || typeof o !== "object") return undefined;
        if ("did_delete" in o) return o.did_delete;

        for (const k in o) {
          const r = findFlag(o[k]);
          if (r !== undefined) return r;
        }

        return undefined;
      };

      const flag = findFlag(json);

      if (flag === true) return true;

      const dump = JSON.stringify(json);
      console.log("Hapus gagal:", id, dump);

      const err = json?.errors?.[0];

      throw Error(
        (err && (err.summary || err.message || err.description)) ||
        "did_delete=" + flag + " | " + dump.slice(0, 200)
      );
    };

    goBtn.onclick = async () => {
      if (running || !ids.length) return;

      const total = ids.length;

      running = true;
      stopFlag = false;
      scanBtn.disabled = true;
      goBtn.disabled = true;
      stopBtn.disabled = false;
      fill.style.width = "0";

      let done = 0;
      let failed = 0;
      let streak = 0;
      let lastError = "";
      const queue = ids.slice();
      const left = [];

      try {
        while (queue.length && !stopFlag) {
          const id = queue[0];

          try {
            await deleteOne(id);
            queue.shift();
            done++;
            streak = 0;
          } catch (e) {
            if (e.message === "RATE_LIMIT") {
              setStatus("Kena batas laju. Berhenti, coba lagi nanti.", "err");
              break;
            }

            lastError = e.message;
            left.push(queue.shift());
            failed++;
            streak++;

            if (streak >= 3) {
              setStatus(
                "3 kegagalan beruntun, dihentikan: " + lastError,
                "err"
              );
              break;
            }
          }

          fill.style.width = ((done + failed) / total) * 100 + "%";
          setStatus(
            "Menghapus " + (done + failed) + "/" + total +
            " (berhasil: " + done + ", gagal: " + failed + ")",
            "busy"
          );

          // Jeda acak agar tidak memicu pembatasan
          await sleep(1200 + Math.random() * 900);
        }

        ids = left.concat(queue);

        if (!ids.length) {
          setStatus(
            "Selesai. Terhapus: " + done + " postingan.",
            "ok"
          );
        } else if (stopFlag) {
          setStatus(
            "Dihentikan. Terhapus: " + done + ", sisa: " + ids.length,
            "err"
          );
        } else if (failed && streak < 3) {
          setStatus(
            "Selesai sebagian. Terhapus: " + done +
            ", gagal: " + failed + " (" + lastError + ")",
            "err"
          );
        }
      } finally {
        running = false;
        scanBtn.disabled = false;
        stopBtn.disabled = true;
        countBox.textContent = ids.length
          ? ids.length + " postingan tersisa di daftar."
          : "Daftar kosong.";
        updateGo();
      }
    };

    stopBtn.onclick = () => {
      stopFlag = true;
    };
  }

  // ---------------------------------------------------------------
  // Buka / tutup popup dari tombol ⚙
  // ---------------------------------------------------------------
  function togglePopup() {
    if (document.getElementById("ppt-wrap")) {
      closeAll();
      return;
    }

    RUN();
    RUN_DEL();
    getWrap().dataset.tab = "profile";
  }

  window.__pptRun = togglePopup;

  // Eksekusi Publish Post via API Internal di MAIN world (agar Origin = https://www.threads.com & bebas error CSRF)
  async function handleMainWorldPublish(data) {
    invalidateHTMLSnapshot();
    authCache.clear();

    const auth = getAuth();
    const csrf = auth.csrf;

    let csrfSum = 0;
    for (const ch of csrf) csrfSum += ch.charCodeAt(0);
    const jazoest = "2" + csrfSum;

    const hasImage = Boolean(data.jpegBuffer && data.width && data.height);
    const uploadId = String(Date.now());

    if (hasImage) {
      const jpegBlob = new Blob([data.jpegBuffer], { type: "image/jpeg" });

      const uploadResponse = await fetch(
        "/rupload_igphoto/fb_uploader_" + uploadId,
        {
          method: "POST",
          credentials: "include",
          headers: {
            "x-csrftoken": csrf,
            "x-entity-type": "image/jpeg",
            "x-entity-name": "fb_uploader_" + uploadId,
            "x-entity-length": String(jpegBlob.size),
            "offset": "0",
            "x-ig-app-id": APP,
            "x-instagram-rupload-params": JSON.stringify({
              is_sidecar: "0",
              is_threads: "1",
              media_type: 1,
              upload_id: uploadId,
              upload_media_height: data.height,
              upload_media_width: data.width
            }),
            "Content-Type": "image/jpeg",
            "Accept": "*/*"
          },
          body: jpegBlob
        }
      );

      if (!uploadResponse.ok) {
        throw Error("Upload gambar gagal: HTTP " + uploadResponse.status);
      }

      const uploadJson = await uploadResponse.json().catch(() => null);
      if (!uploadJson || uploadJson.status !== "ok") {
        throw Error("Upload gambar ditolak oleh server.");
      }
    }

    const endpoint = hasImage
      ? "/api/v1/media/configure_text_post_app_feed/"
      : "/api/v1/media/configure_text_only_post/";

    const uuid = () =>
      typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
        ? crypto.randomUUID()
        : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, ch => {
            const r = (Math.random() * 16) | 0;
            const v = ch === "x" ? r : (r & 0x3) | 0x8;
            return v.toString(16);
          });

    const seg = () => Math.random().toString(36).slice(2, 8).padEnd(6, "0");
    const finalCaption = String(data.caption ?? "").trim();
    const rawTopic = String(data.topic || "").trim();
    const cleanTopic =
      !rawTopic ||
      rawTopic.toLowerCase() === "tanpa topik" ||
      rawTopic === "-- tanpa topik --"
        ? ""
        : rawTopic.replace(/^#+/, "").trim();

    const linkAttachmentUrl = data.linkAttachmentUrl
      ? String(data.linkAttachmentUrl).trim()
      : null;

    const extractQuotedPostId = raw => {
      const s = String(raw || "").trim();
      if (!s) return null;
      if (/^\d{10,}$/.test(s)) return s;
      const m =
        s.match(/\/(?:post|t)\/([A-Za-z0-9_-]+)/i) ||
        s.match(/^([A-Za-z0-9_-]{8,16})$/);
      const code = m && m[1] ? m[1] : "";
      if (!code) return null;
      const alphabet =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
      let id = 0n;
      for (const ch of code) {
        const idx = alphabet.indexOf(ch);
        if (idx === -1) return null;
        id = id * 64n + BigInt(idx);
      }
      return id > 0n ? id.toString() : null;
    };
    const quotedPostId = extractQuotedPostId(data.quoteUrl);

    const webSessionId = `${seg()}:${seg()}:${seg()}`;
    const textPostAppInfo = {
      community_flair_id: null,
      composer_session_id: uuid(),
      entry_point: "main_tab_bar",
      excluded_inline_media_ids: "[]",
      fediverse_composer_enabled: false,
      gif_media_id: null,
      is_genai_invocation_post: false,
      is_reply_approval_enabled: false,
      is_spoiler_media: false,
      link_attachment_url: linkAttachmentUrl,
      link_preview_default_render_style: null,
      quoted_post_id: quotedPostId,
      ranking_info_token: null,
      reply_control: 0,
      self_thread_context_id: uuid(),
      snippet_attachment: null,
      special_effects_enabled_str: null,
      tag_header: cleanTopic ? { display_text: cleanTopic } : null,
      text_with_entities: {
        entities: [],
        text: finalCaption
      },
      threads_draft_id: null
    };

    const formObj = {
      async_publish: "",
      audience: "default",
      barcelona_source_reply_id: "",
      caption: finalCaption,
      chain_id: "",
      chain_index: "",
      chain_length: "",
      container_module: "ig_text_feed_profile",
      creator_geo_gating_info: JSON.stringify({ whitelist_country_codes: [] }),
      cross_share_info: "",
      custom_accessibility_caption: "",
      gen_ai_detection_method: "",
      internal_features: "p92_tags",
      is_meta_only_post: "",
      is_paid_partnership: ""
    };

    if (hasImage) {
      formObj.is_threads = "true";
    }

    formObj.is_upload_type_override_allowed = "1";
    formObj.music_failures_supported = "1";
    formObj.music_params = "";
    formObj.nav_chain = "BarcelonaProfileThreadsRoot:ig_text_feed_profile:1:via_cold_start";

    if (!hasImage) {
      formObj.publish_mode = "text_post";
    }

    formObj.should_include_permalink = "true";
    formObj.text_post_app_info = JSON.stringify(textPostAppInfo);
    formObj.upload_id = uploadId;

    if (hasImage) {
      formObj.usertags = "";
    }

    formObj.web_session_id = webSessionId;
    formObj.jazoest = jazoest;

    const form = new URLSearchParams(formObj);

    const res = await fetch(endpoint, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "x-csrftoken": csrf,
        "x-ig-app-id": APP,
        "x-asbd-id": "359341",
        "x-instagram-ajax": auth.revision || "1053351095",
        "x-requested-with": "XMLHttpRequest",
        "Accept": "*/*"
      },
      body: form.toString()
    });

    const json = await res.json().catch(() => null);

    if (!res.ok || json?.status !== "ok") {
      const errMsg =
        json?.message ||
        json?.error_title ||
        `Publish gagal (HTTP ${res.status})`;
      throw Error(errMsg);
    }

    return {
      ok: true,
      filled: true,
      sent: true,
      sentViaApi: true,
      permalink: json?.media?.permalink || ""
    };
  }

  window.addEventListener("message", event => {
    if (event.source !== window || event.data?.type !== "PPT_MAIN_PUBLISH_POST") {
      return;
    }
    const reqId = event.data.reqId;
    handleMainWorldPublish(event.data)
      .then(result => {
        window.postMessage(
          { type: "PPT_MAIN_PUBLISH_POST_RES", reqId, result },
          "*"
        );
      })
      .catch(err => {
        window.postMessage(
          {
            type: "PPT_MAIN_PUBLISH_POST_RES",
            reqId,
            result: { ok: false, sent: false, error: err?.message || String(err) }
          },
          "*"
        );
      });
  });

  async function handleMainWorldUpdateBioLink(payload) {
    const csrf = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1];
    if (!csrf) {
      throw new Error("Cookie CSRF tidak ditemukan. Muat ulang Threads.");
    }

    const html = getHTMLSnapshot();
    const bloksVersion =
      (
        html.match(/"versioningID":"([a-f0-9]{20,})"/) ||
        html.match(/"bloks_version_id":"([a-f0-9]{20,})"/) ||
        []
      )[1] || "";

    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      "x-csrftoken": csrf,
      "x-ig-app-id": APP,
      "x-asbd-id": "359341",
      "x-fb-friendly-name": "useBarcelonaEditProfileMutation"
    };

    if (bloksVersion) {
      headers["x-bloks-version-id"] = bloksVersion;
    }

    // Deteksi username akun yang sedang login di tab ini
    let current = "";
    const m = location.pathname.match(/^\/@([^/]+)\/?$/);
    if (m && m[1]) {
      try { current = decodeURIComponent(m[1]); } catch (_) { current = m[1]; }
    }
    if (!current) {
      try {
        current = require("CurrentUserInitialData").USERNAME || "";
      } catch (_) {}
    }
    if (!current) {
      const navLinks = document.querySelectorAll(
        'nav a[href^="/@"], [role="navigation"] a[href^="/@"], header a[href^="/@"], a[aria-label="Profile"][href^="/@"], a[aria-label="Profil"][href^="/@"]'
      );
      for (let i = navLinks.length - 1; i >= 0; i--) {
        const href = navLinks[i].getAttribute("href") || "";
        const mm = href.match(/^\/@([A-Za-z0-9._]+)/);
        if (mm && mm[1]) {
          current = mm[1];
          break;
        }
      }
    }
    if (!current) {
      const mUser = html.match(/"CurrentUserInitialData",\[\],\{[^}]*"USERNAME":"([^"]+)"/) ||
                    html.match(/"username":"([A-Za-z0-9._]{2,30})"/);
      if (mUser && mUser[1]) current = mUser[1];
    }
    if (!current) {
      const allLinks = document.querySelectorAll('nav a[href^="/@"], [role="navigation"] a[href^="/@"]');
      for (let i = 0; i < allLinks.length; i++) {
        const href = allLinks[i].getAttribute("href") || "";
        const mm = href.match(/^\/@([A-Za-z0-9._]+)\/?$/);
        if (mm && mm[1]) {
          current = mm[1];
          break;
        }
      }
    }

    if (!current) {
      throw new Error("Username profil tidak terdeteksi pada tab ini. Pastikan Anda sudah login.");
    }

    // Deteksi display name
    let currentName = current;
    try {
      const curData = require("CurrentUserInitialData");
      if (curData && curData.NAME) currentName = curData.NAME;
    } catch (_) {}
    if (!currentName) {
      const mName = html.match(/"CurrentUserInitialData",\[\],\{[^}]*"NAME":"([^"]+)"/);
      if (mName && mName[1]) currentName = mName[1];
    }

    // Deteksi status privasi saat ini
    let currentIsPrivate = false;
    try {
      const curData = require("CurrentUserInitialData");
      if (curData && typeof curData.IS_PRIVATE === "boolean") currentIsPrivate = curData.IS_PRIVATE;
      else if (curData && typeof curData.is_private === "boolean") currentIsPrivate = curData.is_private;
    } catch (_) {}
    if (!currentIsPrivate) {
      const mPriv = html.match(/"is_private":\s*(true|false)/);
      if (mPriv) currentIsPrivate = mPriv[1] === "true";
    }

    // Pertahankan status privasi yang sedang aktif di akun (tidak mengubah privasi)
    const isPrivate = currentIsPrivate;

    // Upload foto profil baru jika disediakan
    let uploadId = null;
    if (payload.photoDataUrl && typeof payload.photoDataUrl === "string") {
      try {
        let jpegBlob;
        if (payload.photoDataUrl.startsWith("data:")) {
          // Konversi base64 dataURL ke Blob secara in-memory tanpa fetch (bebas blokir CSP browser)
          const parts = payload.photoDataUrl.split(",");
          const mime = (parts[0].match(/:(.*?);/) || [])[1] || "image/jpeg";
          const binary = atob(parts[1]);
          const array = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            array[i] = binary.charCodeAt(i);
          }
          jpegBlob = new Blob([array], { type: mime });
        } else {
          const res = await fetch(payload.photoDataUrl, { mode: "cors", credentials: "omit" });
          jpegBlob = await res.blob();
        }

        const bitmap = await createImageBitmap(jpegBlob);
        const width = bitmap.width;
        const height = bitmap.height;
        bitmap.close();

        uploadId = String(Date.now());
        const uploadRes = await fetch("/rupload_igphoto/fb_uploader_" + uploadId, {
          method: "POST",
          credentials: "include",
          headers: {
            "x-csrftoken": csrf,
            "x-entity-type": "image/jpeg",
            "x-entity-name": "fb_uploader_" + uploadId,
            "x-entity-length": String(jpegBlob.size),
            "offset": "0",
            "x-ig-app-id": APP,
            "x-instagram-rupload-params": JSON.stringify({
              is_sidecar: "0",
              is_threads: "1",
              media_type: 1,
              upload_id: uploadId,
              upload_media_height: height,
              upload_media_width: width
            }),
            "Content-Type": "image/jpeg",
            "Accept": "*/*"
          },
          body: jpegBlob
        });

        const uploadText = await uploadRes.text();
        console.log("[Profile Update] rupload response status:", uploadRes.status, uploadText);

        if (!uploadRes.ok) {
          throw new Error("Upload foto ke Threads gagal: HTTP " + uploadRes.status);
        }

        let uploadResult = {};
        try {
          uploadResult = JSON.parse(uploadText);
        } catch (_) {}

        if (uploadResult.status !== "ok" && uploadRes.status !== 200) {
          throw new Error("Upload foto ditolak oleh Threads");
        }

        uploadId = uploadResult.upload_id || uploadId;
      } catch (photoErr) {
        console.error("[Profile Update] Gagal upload foto profil:", photoErr);
        throw new Error("Gagal proses foto profil: " + (photoErr?.message || String(photoErr)));
      }
    }

    // Persiapkan bio multi-baris & link (fallback ke profil yang ada jika tidak diisi)
    let finalBio = "";
    if (typeof payload.bio === "string" && payload.bio.trim()) {
      finalBio = payload.bio.replace(/\r\n/g, "\n").replace(/\r/g, "\n").trim();
    } else {
      const mBio = html.match(/"biography":"([^"]*)"/) || html.match(/"raw_text":"([^"]*)"/);
      if (mBio && mBio[1]) {
        try {
          finalBio = JSON.parse(`"${mBio[1]}"`);
        } catch (_) {
          finalBio = mBio[1];
        }
      }
    }

    let finalLink = "";
    if (typeof payload.link === "string" && payload.link.trim()) {
      finalLink = payload.link.trim();
    } else {
      const mLink = html.match(/"external_url":"([^"]*)"/);
      if (mLink && mLink[1]) {
        finalLink = mLink[1].replace(/\\\//g, "/");
      }
    }

    const variables = {
      biography: finalBio,
      external_url: finalLink,
      username: current,
      name: currentName || current,
      is_private: isPrivate,
      profile_picture_upload_id: uploadId || null,
      remove_profile_picture: false,
      copy_ig_profile_picture_to_text_post_app: false,
      __relay_internal__pv__BarcelonaHasStylingInforelayprovider: false
    };

    const body = new URLSearchParams({
      fb_api_req_friendly_name: "useBarcelonaEditProfileMutation",
      fb_api_caller_class: "RelayModern",
      doc_id: "28671854302499863",
      variables: JSON.stringify(variables)
    });

    const response = await fetch("/graphql/query", {
      method: "POST",
      credentials: "include",
      headers,
      body: body.toString()
    });

    const text = await response.text();
    let resultJson;
    try {
      resultJson = JSON.parse(text);
    } catch (_) {
      throw new Error("Respons bukan JSON (HTTP " + response.status + ")");
    }

    console.log("[Profile Update] Meta response:", resultJson);

    const result = resultJson?.data?.data;
    if (result?.status === "SUCCESS") {
      return {
        ok: true,
        username: current,
        status: "SUCCESS",
        photoUpdated: Boolean(uploadId)
      };
    } else {
      const errMsg = resultJson?.errors?.[0]?.message ||
                     resultJson?.error_message ||
                     result?.error_message ||
                     "Gagal update profil (Meta menolak perubahan)";
      throw new Error(errMsg);
    }
  }

  window.addEventListener("message", event => {
    if (event.source !== window || event.data?.type !== "PPT_MAIN_UPDATE_BIO_LINK") {
      return;
    }
    const reqId = event.data.reqId;
    handleMainWorldUpdateBioLink(event.data)
      .then(result => {
        window.postMessage(
          {
            type: "PPT_MAIN_UPDATE_BIO_LINK_RES",
            reqId,
            result: { ok: true, ...result }
          },
          "*"
        );
      })
      .catch(err => {
        window.postMessage(
          {
            type: "PPT_MAIN_UPDATE_BIO_LINK_RES",
            reqId,
            result: { ok: false, error: err?.message || String(err) }
          },
          "*"
        );
      });
  });

  async function handleMainWorldUpdatePrivacy(payload) {
    let auth = {};
    try {
      auth = getAuth();
    } catch (_) {}

    const csrf = auth.csrf || (document.cookie.match(/csrftoken=([^;]+)/) || [])[1];
    if (!csrf) {
      throw new Error("Cookie CSRF tidak ditemukan. Muat ulang Threads.");
    }

    if (!auth.lsd) {
      const matchLsd = (getHTMLSnapshot().match(/"LSD",\[\],\{"token":"([^"]+)"/) || [])[1];
      if (matchLsd) auth.lsd = matchLsd;
    }

    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      "x-csrftoken": csrf,
      "x-ig-app-id": APP,
      "x-asbd-id": "359341",
      "x-fb-friendly-name": "useSettings2UpdateBooleanStorageMutation"
    };

    if (auth.lsd) {
      headers["x-fb-lsd"] = auth.lsd;
    }

    const isPrivate = payload.privacy === "private";

    const variables = {
      storage_id: "threads_profile_privacy",
      value: isPrivate,
      callsite: "igs2.undefined"
    };

    const actorId = auth.actor || (document.cookie.match(/ds_user_id=([^;]+)/) || [])[1] || "";

    const bodyParams = {
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "useSettings2UpdateBooleanStorageMutation",
      server_timestamps: "true",
      doc_id: "30348287188092506",
      variables: JSON.stringify(variables)
    };

    if (actorId) bodyParams.av = actorId;
    if (auth.lsd) bodyParams.lsd = auth.lsd;
    if (auth.dtsg) bodyParams.fb_dtsg = auth.dtsg;
    if (auth.jazoest) bodyParams.jazoest = auth.jazoest;
    if (auth.revision) {
      bodyParams.__rev = auth.revision;
      bodyParams.__spin_r = auth.revision;
    }
    bodyParams.__spin_b = "trunk";
    bodyParams.__spin_t = String(Math.floor(Date.now() / 1000));
    bodyParams.__crn = "comet.threads.BarcelonaSettings2Route";

    const body = new URLSearchParams(bodyParams);

    const response = await fetch("/graphql/query", {
      method: "POST",
      credentials: "include",
      headers,
      body: body.toString()
    });

    const text = await response.text();
    let resultJson;
    try {
      resultJson = JSON.parse(text);
    } catch (_) {
      throw new Error("Respons bukan JSON (HTTP " + response.status + "): " + text.slice(0, 100));
    }

    console.log("[Privacy Update] Meta response:", resultJson);

    if (resultJson?.errors && Array.isArray(resultJson.errors) && resultJson.errors.length > 0) {
      const errMsg = resultJson.errors.map(e => e.message || e.summary || JSON.stringify(e)).join("; ");
      throw new Error(errMsg);
    }
    if (resultJson?.error) {
      throw new Error(resultJson.error.message || resultJson.error_summary || JSON.stringify(resultJson.error));
    }

    return {
      ok: true,
      status: "SUCCESS",
      is_private: isPrivate
    };
  }

  window.addEventListener("message", event => {
    if (event.source !== window || event.data?.type !== "PPT_MAIN_UPDATE_PRIVACY") {
      return;
    }
    const reqId = event.data.reqId;
    handleMainWorldUpdatePrivacy(event.data)
      .then(result => {
        window.postMessage(
          {
            type: "PPT_MAIN_UPDATE_PRIVACY_RES",
            reqId,
            result: { ok: true, ...result }
          },
          "*"
        );
      })
      .catch(err => {
        window.postMessage(
          {
            type: "PPT_MAIN_UPDATE_PRIVACY_RES",
            reqId,
            result: { ok: false, error: err?.message || String(err) }
          },
          "*"
        );
      });
  });
  // Terima sinyal dari auto-login.js setelah login + 2FA + buka profil selesai
  window.addEventListener("message", event => {
    if (event.source !== window || event.data?.type !== "PPT_AUTO_EDIT_PROFILE") {
      return;
    }

    try {
      invalidateHTMLSnapshot();
      authCache.clear();

      if (!document.getElementById("ppt-wrap")) {
        RUN();
        RUN_DEL();
        getWrap().dataset.tab = "profile";
      }

      if (event.data?.jpegBuffer) {
        try {
          const fInput = document.getElementById("ppt-file");
          if (fInput) {
            const file = new File([event.data.jpegBuffer], "profile.jpg", {
              type: "image/jpeg"
            });
            const dt = new DataTransfer();
            dt.items.add(file);
            fInput.files = dt.files;
            fInput.dispatchEvent(new Event("change", { bubbles: true }));
          }
        } catch (err) {
          console.warn("[Threads Panel Auto] Gagal set file foto:", err);
        }
      }

      setTimeout(() => {
        const randBtn = document.getElementById("ppt-rand");
        const newInput = document.getElementById("ppt-newuser");
        const uploadBtn = document.getElementById("ppt-upload");

        if (randBtn && (!newInput || !newInput.value.trim())) {
          randBtn.click();
        }

        if (uploadBtn && !uploadBtn.disabled) {
          uploadBtn.click();
        }
      }, 100);
    } catch (e) {
      console.error("[Threads Panel Auto]", e);
    }
  });

  function addButton() {
    if (
      !document.documentElement ||
      document.getElementById("ppt-launch")
    ) return;

    const button = document.createElement("button");
    button.id = "ppt-launch";
    button.textContent = "⚙";
    button.title = "Profil Threads";
    button.setAttribute("aria-label", "Buka Profil Threads");

    button.style.cssText =
      "position:fixed;left:12px;top:12px;width:40px;height:40px;" +
      "border:0;border-radius:50%;background:#7c5cff;color:#fff;" +
      "font-size:18px;cursor:pointer;z-index:2147483646;" +
      "opacity:.9;display:block";

    button.addEventListener("click", () => {
      try {
        togglePopup();
      } catch (error) {
        console.error("[Threads Panel]", error);
        alert("Error: " + error.message);
      }
    });

    document.documentElement.appendChild(button);
  }

  if (document.documentElement) {
    addButton();
  } else {
    document.addEventListener("DOMContentLoaded", addButton, {
      once: true
    });
  }

  console.log("[Threads Panel] v3.6 - Privasi Boolean Storage Dimuat");
})();
