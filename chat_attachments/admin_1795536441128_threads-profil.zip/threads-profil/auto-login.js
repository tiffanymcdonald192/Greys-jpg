// Content Script (ISOLATED world):
// Menjalankan alur otomatis:
// 1. Isi Username & Password + Klik Login
// 2. Tunggu halaman/input 2FA muncul -> Generate OTP dari Secret Key -> Isi & Klik Kirim
// 3. Setelah masuk Threads -> Otomatis klik menu Profil (/@username)
// 4. Kirim sinyal ke content.js (MAIN world) untuk otomatis ganti Foto Default + Username Random

(function () {
  'use strict';

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // =====================================================
  // AUTO CLOSE TAB JIKA AKUN SUSPENDED
  // =====================================================

  function isSuspendedPage() {
    return /\/accounts\/suspended(\/|\?|$)/i.test(location.pathname);
  }

  function checkAndCloseIfSuspended() {
    if (!isSuspendedPage()) return false;
    console.warn('[AutoFlow] Akun suspended terdeteksi, menutup tab otomatis...');
    try {
      chrome.runtime.sendMessage({ action: 'closeCurrentTab' });
    } catch (_) {}
    try {
      window.close();
    } catch (_) {}
    return true;
  }

  if (checkAndCloseIfSuspended()) {
    return;
  }

  setInterval(checkAndCloseIfSuspended, 700);

  // =====================================================
  // KOMUNIKASI DENGAN BACKGROUND STORAGE PER TAB
  // =====================================================

  function getTabJob() {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage({ action: 'getTabJob' }, res => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(res?.job || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function updateTabJob(patch) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage({ action: 'updateTabJob', patch }, res => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(res?.job || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function clearTabJob() {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage({ action: 'clearTabJob' }, () => resolve());
      } catch (_) {
        resolve();
      }
    });
  }

  // =====================================================
  // LISTEN MESSAGE DARI POPUP
  // =====================================================

  function hasLoginForm() {
    if (/\/login(\/|\?|$)/i.test(location.pathname)) return true;
    const pass = document.querySelector(
      '[data-sharklabel="password"], input[type="password"]'
    );
    if (pass && isFillable(pass)) return true;
    if (find2FAInput()) return true;
    return false;
  }

  function isAlreadyLoggedIn() {
    if (hasLoginForm()) return false;

    // 1. Path yang hanya ada setelah login
    if (/^\/(archive|@[^/]+|notifications|activity|search)/i.test(location.pathname)) {
      return true;
    }

    // 2. Cookie session login Threads / Instagram
    try {
      const c = document.cookie || '';
      if (c.includes('sessionid=') || c.includes('ds_user_id=') || c.includes('c_user=')) {
        return true;
      }
    } catch (_) {}

    // 3. Elemen antarmuka pengguna saat login (link profil di navbar)
    if (document.querySelector('nav a[href^="/@"], [role="navigation"] a[href^="/@"], header a[href^="/@"], a[href^="/@"]')) {
      return true;
    }
    if (findArchiveElement()) return true;
    if (findProfileElement()) return true;

    // 4. SVG icon navbar Threads saat sudah login
    if (document.querySelector('svg[aria-label="Beranda"], svg[aria-label="Home"], svg[aria-label="Cari"], svg[aria-label="Search"], svg[aria-label="Arsip"], svg[aria-label="Archive"]')) {
      return true;
    }

    return false;
  }

  let cachedNewUsername = '';

  window.addEventListener('message', event => {
    if (event.source === window && event.data?.type === 'PPT_USERNAME_SAVED') {
      if (event.data.username) {
        cachedNewUsername = String(event.data.username).trim().replace(/^@/, '');
        try {
          chrome.runtime.sendMessage({
            action: 'storeTabUsername',
            username: cachedNewUsername
          }).catch(() => {});
        } catch (_) {}
      }
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.action) return;
    if (message.action === 'getTabUsername') {
      // 1. Username yang baru saja berhasil di-edit
      if (cachedNewUsername) {
        sendResponse({ ok: true, username: cachedNewUsername, url: `https://www.threads.com/@${cachedNewUsername}` });
        return true;
      }

      // 2. Link profil di navigation bar Threads (selalu ada di setiap halaman)
      const navLinks = document.querySelectorAll(
        'nav a[href^="/@"], [role="navigation"] a[href^="/@"], header a[href^="/@"], a[href^="/@"]'
      );
      for (let i = navLinks.length - 1; i >= 0; i--) {
        const href = navLinks[i].getAttribute('href') || '';
        const m = href.match(/^\/@([A-Za-z0-9._]+)/);
        if (m && m[1]) {
          sendResponse({ ok: true, username: m[1], url: `https://www.threads.com/@${m[1]}` });
          return true;
        }
      }

      // 3. Dari URL jika sedang di /@...
      const m = location.pathname.match(/^\/@([A-Za-z0-9._]+)/);
      if (m && m[1]) {
        sendResponse({ ok: true, username: m[1], url: `https://www.threads.com/@${m[1]}` });
        return true;
      }

      sendResponse({ ok: false, username: '' });
      return true;
    }

    if (message.action === 'updateProfileBioLink') {
      const reqId = "ppt_bio_" + Date.now() + "_" + Math.random().toString(36).slice(2, 9);
      const timeout = setTimeout(() => {
        window.removeEventListener("message", onBioRes);
        sendResponse({ ok: false, error: "Timeout menunggu respons dari halaman Threads." });
      }, 30000);

      function onBioRes(ev) {
        if (ev.source !== window || ev.data?.type !== "PPT_MAIN_UPDATE_BIO_LINK_RES" || ev.data?.reqId !== reqId) {
          return;
        }
        clearTimeout(timeout);
        window.removeEventListener("message", onBioRes);
        sendResponse(ev.data?.result || { ok: false, error: "Respons kosong" });
      }

      window.addEventListener("message", onBioRes);
      window.postMessage({
        type: "PPT_MAIN_UPDATE_BIO_LINK",
        reqId,
        bio: message.bio,
        link: message.link,
        photoDataUrl: message.photoDataUrl
      }, "*");

      return true;
    }

    if (message.action === 'updateProfilePrivacy') {
      const reqId = "ppt_priv_" + Date.now() + "_" + Math.random().toString(36).slice(2, 9);
      const timeout = setTimeout(() => {
        window.removeEventListener("message", onPrivRes);
        sendResponse({ ok: false, error: "Timeout response privasi dari Threads." });
      }, 25000);

      function onPrivRes(ev) {
        if (ev.source !== window || ev.data?.type !== "PPT_MAIN_UPDATE_PRIVACY_RES" || ev.data?.reqId !== reqId) {
          return;
        }
        clearTimeout(timeout);
        window.removeEventListener("message", onPrivRes);
        sendResponse(ev.data?.result || { ok: false, error: "Respons kosong" });
      }

      window.addEventListener("message", onPrivRes);
      window.postMessage({
        type: "PPT_MAIN_UPDATE_PRIVACY",
        reqId,
        privacy: message.privacy
      }, "*");

      return true;
    }

    if (message.action === 'checkNeedsLogin') {
      sendResponse({
        ok: true,
        needsLogin: !isAlreadyLoggedIn(),
        hasLoginForm: hasLoginForm()
      });
      return true;
    }

    if (message.action === 'startAutoFlow' && message.job) {
      sendResponse({ ok: true });
      startRunner(message.job);
      return true;
    }

    if (message.action === 'executeLoginOnly') {
      const result = handleLoginStep(message.identifier, message.password);
      sendResponse({ success: result });
      return true;
    }

    if (message.action === 'execute2FAOnly') {
      const result = handle2FAStep(message.code2fa, message.autoClick);
      sendResponse({ success: result });
      return true;
    }

    // Tidak return false agar tidak menutup port Chrome messaging secara prematur
  });

  // =====================================================
  // STATE MACHINE RUNNER (TAHAN RELOAD / PINDAH HALAMAN)
  // =====================================================

  let runnerActive = false;
  let currentJob = null;

  async function startRunner(jobOverride) {
    currentJob = jobOverride || (await getTabJob());
    if (!currentJob) return;
    if (runnerActive) return;

    runnerActive = true;
    console.log('[AutoFlow] Memulai alur otomatis, tahap:', currentJob.stage);

    try {
      while (currentJob) {
        const stage = currentJob.stage;

        // -----------------------------------------------
        // TAHAP 1: LOGIN (ISI USERNAME & PASSWORD)
        // -----------------------------------------------
        if (stage === 'LOGIN') {
          // Jika ternyata sudah berada di layar 2FA, langsung lompat ke WAIT_2FA
          if (find2FAInput() && currentJob.secret) {
            currentJob = await updateTabJob({
              stage: 'WAIT_2FA',
              loginDoneAt: Date.now()
            });
            continue;
          }

          const logged = handleLoginStep(
            currentJob.identifier,
            currentJob.password,
            false // jangan klik dulu sebelum stage di-update di storage
          );

          if (logged) {
            const nextStage = currentJob.secret ? 'WAIT_2FA' : 'OPEN_PROFILE';
            currentJob = await updateTabJob({
              stage: nextStage,
              loginDoneAt: Date.now()
            });

            await sleep(150);
            clickLoginButton();
            console.log('[AutoFlow] Login diklik, lanjut ke tahap:', nextStage);

            // Beri jeda singkat agar halaman memproses submit login
            await sleep(500);
            continue;
          }
        }

        // -----------------------------------------------
        // TAHAP 2: TUNGGU & ISI KODE 2FA + KLIK KIRIM
        // -----------------------------------------------
        else if (stage === 'WAIT_2FA') {
          const input2fa = find2FAInput();

          if (input2fa) {
            if (!currentJob.secret) {
              console.warn('[AutoFlow] Input 2FA muncul tapi Secret Key kosong.');
              currentJob = await updateTabJob({ stage: 'OPEN_PROFILE' });
              continue;
            }

            // Jika sisa waktu window TOTP 30 detik tinggal <= 1 detik,
            // tunggu sebentar agar kode tidak kedaluwarsa saat tombol Kirim diklik
            const rem = 30 - (Math.floor(Date.now() / 1000) % 30);
            if (rem <= 1) {
              await sleep((rem + 0.2) * 1000);
            }

            const code2fa = await generateTOTP(currentJob.secret);
            if (code2fa) {
              const filled = handle2FAStep(code2fa, false);
              if (filled) {
                currentJob = await updateTabJob({
                  stage: 'OPEN_PROFILE',
                  twoFaDoneAt: Date.now()
                });

                await sleep(150);
                const btn = await waitForKirimButton(5000);
                if (btn) {
                  clickKirimButton(btn);
                  console.log('[AutoFlow] Kode 2FA diisi & tombol Kirim diklik.');
                } else {
                  console.warn('[AutoFlow] Tombol Kirim 2FA tidak ditemukan.');
                }

                await sleep(600);
                continue;
              }
            }
          } else {
            // Jika akun tidak meminta 2FA dan sudah masuk ke beranda Threads
            const elapsed = Date.now() - (currentJob.loginDoneAt || currentJob.startedAt || 0);
            if (
              elapsed > 1500 &&
              isThreadsHost() &&
              !hasLoginFields() &&
              !find2FAInput()
            ) {
              console.log('[AutoFlow] Sudah masuk Threads tanpa 2FA, lanjut buka Arsip.');
              currentJob = await updateTabJob({ stage: 'OPEN_PROFILE' });
              continue;
            }
          }
        }

        // -----------------------------------------------
        // TAHAP 3: LANGSUNG ARAHKAN KE https://www.threads.com/archive
        // -----------------------------------------------
        else if (stage === 'OPEN_PROFILE') {
          if (isThreadsHost() && !find2FAInput() && !hasLoginFields()) {
            try {
              chrome.runtime.sendMessage({ action: 'markTabLoggedIn' });
            } catch (_) {}
            const isArchivePage = /\/archive(\/|\?|$)/i.test(location.pathname);

            // Jika opsi Auto Ganti Nama OFF, cukup arahkan ke /archive dan selesai
            if (currentJob.autoEditProfile === false) {
              if (!isArchivePage) {
                console.log('[AutoFlow] Login selesai, mengarahkan ke https://www.threads.com/archive');
                location.href = 'https://www.threads.com/archive';
              }
              await clearTabJob();
              currentJob = null;
              console.log('[AutoFlow] Selesai (Auto Ganti Nama OFF).');
              break;
            }

            // Langsung arahkan ke https://www.threads.com/archive
            if (!isArchivePage) {
              console.log('[AutoFlow] Login berhasil! Mengarahkan langsung ke https://www.threads.com/archive ...');
              await updateTabJob({
                stage: 'EDIT_PROFILE',
                archiveOpenedAt: Date.now()
              });
              location.href = 'https://www.threads.com/archive';
              await sleep(3000);
              continue;
            } else {
              // Jika sudah di halaman archive, lanjut ke edit profil
              currentJob = await updateTabJob({
                stage: 'EDIT_PROFILE',
                archiveOpenedAt: Date.now()
              });
              continue;
            }
          }
        }

        // -----------------------------------------------
        // TAHAP 4: OTOMATIS GANTI FOTO & USERNAME RANDOM (DI ARSIP)
        // -----------------------------------------------
        else if (stage === 'EDIT_PROFILE') {
          if (isThreadsHost()) {
            const isArchivePage = /\/archive(\/|\?|$)/i.test(location.pathname);
            if (!isArchivePage) {
              console.log('[AutoFlow] Memastikan berada di https://www.threads.com/archive ...');
              location.href = 'https://www.threads.com/archive';
              await sleep(2500);
            }

            const accountIndex = currentJob.accountIndex ?? 0;
            // Hapus job terlebih dahulu agar setelah simpan & reload tidak mengulang lagi
            await clearTabJob();
            currentJob = null;

            let jpegBuffer = null;
            try {
              const photoRes = await new Promise(resolve => {
                chrome.runtime.sendMessage(
                  { action: 'getProfilePhotoForAccount', accountIndex },
                  res => resolve(res || null)
                );
              });
              const dUrl = String(photoRes?.dataUrl || '').trim();
              if (dUrl.startsWith('data:')) {
                const comma = dUrl.indexOf(',');
                if (comma !== -1) {
                  const meta = dUrl.slice(0, comma);
                  const b64 = dUrl.slice(comma + 1);
                  const mimeMatch = meta.match(/data:([^;]+)/i);
                  const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
                  const bin = atob(b64);
                  const bytes = new Uint8Array(bin.length);
                  for (let i = 0; i < bin.length; i++) {
                    bytes[i] = bin.charCodeAt(i);
                  }
                  const blob = new Blob([bytes], { type: mime });
                  const bitmap = await createImageBitmap(blob);
                  let w = bitmap.width;
                  let h = bitmap.height;
                  const MAX_D = 640;
                  if (w > MAX_D || h > MAX_D) {
                    const r = Math.min(MAX_D / w, MAX_D / h);
                    w = Math.max(2, Math.round(w * r));
                    h = Math.max(2, Math.round(h * r));
                  }
                  try {
                    const canvas = document.createElement('canvas');
                    canvas.width = w;
                    canvas.height = h;
                    const ctx = canvas.getContext('2d');
                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(0, 0, w, h);
                    ctx.drawImage(bitmap, 0, 0, w, h);
                    const jpegBlob = await new Promise((resBlob, rejBlob) => {
                      canvas.toBlob(
                        b => (b ? resBlob(b) : rejBlob(new Error('toBlob gagal'))),
                        'image/jpeg',
                        0.92
                      );
                    });
                    jpegBuffer = await jpegBlob.arrayBuffer();
                  } finally {
                    bitmap.close();
                  }
                }
              }
            } catch (err) {
              console.warn('[AutoFlow] Gagal menyiapkan foto kustom, pakai default:', err);
            }

            console.log('[AutoFlow] Di Arsip / Threads siap. Menjalankan Auto Edit Profil...');
            await sleep(300);

            window.postMessage({ type: 'PPT_AUTO_EDIT_PROFILE', jpegBuffer }, '*');
            break;
          }
        } else {
          await clearTabJob();
          currentJob = null;
          break;
        }

        await sleep(200);
        currentJob = await getTabJob();
      }
    } catch (err) {
      console.error('[AutoFlow] Error:', err);
    } finally {
      runnerActive = false;
    }
  }

  // Saat halaman baru dimuat (misal habis redirect login / 2FA), cek apakah tab ini punya job aktif
  getTabJob().then(job => {
    if (job) {
      startRunner(job);
    }
  });

  // =====================================================
  // DETEKSI HALAMAN & ELEMEN THREADS
  // =====================================================

  function isThreadsHost() {
    return /(^|\.)threads\.(com|net)$/.test(location.hostname);
  }

  function isOnProfilePage() {
    return isThreadsHost() && /^\/@[^/]+/.test(location.pathname);
  }

  function hasLoginFields() {
    const pass = document.querySelector(
      '[data-sharklabel="password"], input[type="password"]'
    );
    return !!(pass && isFillable(pass));
  }

  function clickArchive() {
    // Sesuai snippet yang diminta: document.querySelectorAll('span,a,div')
    // juga dukung [role="button"], [role="link"], button dan bahasa Inggris 'Archive'
    const els = document.querySelectorAll('span, a, div, [role="button"], [role="link"], button');
    for (let i = 0; i < els.length; i++) {
      const txt = (els[i].textContent || '').trim();
      if (txt === 'Arsip' || txt === 'Archive' || txt.toLowerCase() === 'arsip' || txt.toLowerCase() === 'archive') {
        try {
          els[i].click();
        } catch (_) {}
        const parentBtn = els[i].closest('a, [role="button"], [role="link"], button');
        if (parentBtn && parentBtn !== els[i]) {
          try {
            parentBtn.click();
          } catch (_) {}
        }
        return true;
      }
    }
    return false;
  }

  function findArchiveElement() {
    // 1. Cari span (termasuk class x1lliihq) atau elemen lain dengan teks "Arsip" atau "Archive"
    const candidates = document.querySelectorAll(
      'span.x1lliihq, span, [role="button"], [role="link"], a, button, div'
    );

    for (const el of candidates) {
      const text = (el.innerText || el.textContent || '')
        .trim()
        .toLowerCase();

      if (text === 'arsip' || text === 'archive') {
        if (
          el.getClientRects().length &&
          !el.closest('[aria-hidden="true"]')
        ) {
          return el.closest('a, [role="link"], [role="button"], button') || el;
        }
      }
    }

    // 2. Cari elemen yang memiliki atribut aria-label atau href ke archive/arsip
    const ariaEl = document.querySelector(
      '[aria-label="Arsip" i], [aria-label="Archive" i], a[href*="/archive"], a[href*="/arsip"]'
    );
    if (ariaEl && ariaEl.getClientRects().length && !ariaEl.closest('[aria-hidden="true"]')) {
      return ariaEl;
    }

    return null;
  }

  function clickTarget(el) {
    if (!el) return;
    try {
      el.scrollIntoView({ block: 'center', inline: 'center' });
    } catch (_) {}

    const parentBtn = el.closest('a, [role="button"], [role="link"], button');
    const target = parentBtn || el;

    try {
      target.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      target.click();
    } catch (_) {
      try {
        target.click();
      } catch (_) {}
    }

    if (el !== target) {
      try {
        el.click();
      } catch (_) {}
    }
  }

  function findProfileElement() {
    const elements = document.querySelectorAll(
      'a, [role="link"], [role="button"]'
    );

    for (const el of elements) {
      const text = (el.innerText || el.textContent || '')
        .trim()
        .toLowerCase();

      if (text === 'profil' || text === 'profile') {
        if (
          el.getClientRects().length &&
          !el.closest('[aria-hidden="true"]')
        ) {
          return el;
        }
      }
    }

    // Fallback: cari link navigasi ke /@username di navbar
    const navLinks = document.querySelectorAll(
      'nav a[href^="/@"], [role="navigation"] a[href^="/@"], header a[href^="/@"]'
    );
    for (let i = navLinks.length - 1; i >= 0; i--) {
      const a = navLinks[i];
      const href = a.getAttribute('href') || '';
      if (
        /^\/@[A-Za-z0-9._]+\/?$/.test(href) &&
        a.getClientRects().length &&
        !a.closest('[aria-hidden="true"]')
      ) {
        return a;
      }
    }

    return null;
  }

  // =====================================================
  // FUNGSI TAHAP 1: LOGIN
  // =====================================================

  function handleLoginStep(identifier, password, autoClickLogin = true) {
    let identifierFilled = false;
    let passwordFilled = false;

    // Username / email
    const sharkLabelField = document.querySelector('[data-sharklabel="email"]');
    if (sharkLabelField && isFillable(sharkLabelField)) {
      fillInput(sharkLabelField, identifier);
      identifierFilled = true;
    }

    // Autocomplete username
    if (!identifierFilled) {
      document.querySelectorAll('[autocomplete="username"]').forEach(field => {
        if (!identifierFilled && isFillable(field)) {
          fillInput(field, identifier);
          identifierFilled = true;
        }
      });
    }

    // Fallback username
    if (!identifierFilled) {
      const keywords = [
        'nama pengguna',
        'telepon',
        'email',
        'username',
        'phone'
      ];

      document
        .querySelectorAll(
          'input[type="text"], ' +
          'input[type="email"], ' +
          'input[type="tel"], ' +
          'input:not([type])'
        )
        .forEach(input => {
          if (!identifierFilled && isFillable(input)) {
            const combined = `
              ${input.placeholder || ''}
              ${input.getAttribute('aria-label') || ''}
              ${input.name || ''}
            `.toLowerCase();

            if (keywords.some(kw => combined.includes(kw))) {
              fillInput(input, identifier);
              identifierFilled = true;
            }
          }
        });
    }

    // Password
    const sharkPassField = document.querySelector(
      '[data-sharklabel="password"]'
    );

    if (sharkPassField && isFillable(sharkPassField)) {
      fillInput(sharkPassField, password);
      passwordFilled = true;
    }

    // Fallback password
    if (!passwordFilled) {
      document.querySelectorAll('input[type="password"]').forEach(field => {
        if (!passwordFilled && isFillable(field)) {
          fillInput(field, password);
          passwordFilled = true;
        }
      });
    }

    if (identifierFilled && passwordFilled && autoClickLogin) {
      setTimeout(clickLoginButton, 500);
    }

    return identifierFilled && passwordFilled;
  }

  function clickLoginButton() {
    const fbLoginBtn = document.querySelector('div.xwhw2v2.x1xdureb');

    if (fbLoginBtn && isVisible(fbLoginBtn)) {
      fbLoginBtn.dispatchEvent(
        new MouseEvent('click', {
          view: window,
          bubbles: true,
          cancelable: true
        })
      );
      return true;
    }

    let clicked = false;
    document.querySelectorAll('div[role="button"], button, input[type="submit"]').forEach(btn => {
      if (clicked) return;
      const text = (btn.innerText || btn.value || '').trim().toLowerCase();

      if (
        (text === 'login' || text === 'masuk' || text === 'log in') &&
        isVisible(btn)
      ) {
        clicked = true;
        btn.dispatchEvent(
          new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true
          })
        );
      }
    });

    return clicked;
  }

  // =====================================================
  // FUNGSI TAHAP 2: ISI 2FA & KLIK KIRIM
  // =====================================================

  function find2FAInput() {
    const input2fa = document.querySelector(
      'input[autocomplete="one-time-code"], ' +
      'input[placeholder="Kode keamanan"], ' +
      'input[name="approvals_code"], ' +
      'input[data-testid="ocfEnterTextTextInput"], ' +
      'input[inputmode="numeric"]'
    );

    if (input2fa && isFillable(input2fa)) {
      return input2fa;
    }
    return null;
  }

  function handle2FAStep(code2fa, autoClick = false) {
    if (!code2fa) return false;

    const input2fa = find2FAInput();
    if (!input2fa) {
      console.log('Input 2FA tidak ditemukan');
      return false;
    }

    fillInput(input2fa, code2fa);
    console.log('Kode 2FA berhasil diisi');

    if (autoClick) {
      setTimeout(() => {
        waitForKirimButton().then(button => {
          if (button) {
            clickKirimButton(button);
          } else {
            console.log('Tombol Kirim tidak ditemukan setelah menunggu.');
          }
        });
      }, 500);
    }

    return true;
  }

  function waitForKirimButton(timeout = 5000) {
    return new Promise(resolve => {
      const start = Date.now();
      const timer = setInterval(() => {
        const button = findKirimButton();
        if (button) {
          clearInterval(timer);
          resolve(button);
          return;
        }
        if (Date.now() - start >= timeout) {
          clearInterval(timer);
          resolve(null);
        }
      }, 200);
    });
  }

  function findKirimButton() {
    const labels = ['kirim', 'konfirmasi', 'lanjutkan', 'submit', 'confirm', 'continue'];
    const textElements = document.querySelectorAll('div, span, button');

    for (const el of textElements) {
      const txt = el.textContent.trim().toLowerCase();
      if (!labels.includes(txt)) {
        continue;
      }

      const button =
        el.matches('button, [role="button"]')
          ? el
          : el.closest('button, [role="button"]');

      if (!button) continue;

      const rect = button.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) continue;

      return button;
    }

    return null;
  }

  function clickKirimButton(button) {
    if (!button) return false;

    button.scrollIntoView({
      behavior: 'smooth',
      block: 'center'
    });

    setTimeout(() => {
      button.dispatchEvent(
        new MouseEvent('click', {
          view: window,
          bubbles: true,
          cancelable: true
        })
      );
      console.log('Tombol "Kirim" diklik.');
    }, 150);

    return true;
  }

  // =====================================================
  // GENERATE TOTP (HMAC-SHA1)
  // =====================================================

  async function generateTOTP(secret) {
    try {
      const cleanSecret = (secret || '')
        .replace(/\s+/g, '')
        .replace(/-/g, '')
        .toUpperCase();

      if (cleanSecret.length < 16) {
        throw new Error('Secret Key terlalu pendek');
      }

      const keyBytes = base32ToBytes(cleanSecret);
      if (!keyBytes || keyBytes.length === 0) {
        throw new Error('Invalid Secret Key');
      }

      const epoch = Math.floor(Date.now() / 1000);
      const counter = Math.floor(epoch / 30);

      const counterBytes = new Uint8Array(8);
      let value = counter;
      for (let i = 7; i >= 0; i--) {
        counterBytes[i] = value & 0xff;
        value = Math.floor(value / 256);
      }

      const cryptoKey = await crypto.subtle.importKey(
        'raw',
        keyBytes,
        { name: 'HMAC', hash: 'SHA-1' },
        false,
        ['sign']
      );

      const hmacBuffer = await crypto.subtle.sign(
        'HMAC',
        cryptoKey,
        counterBytes
      );

      const hmac = new Uint8Array(hmacBuffer);
      const offset = hmac[hmac.length - 1] & 0x0f;

      const binary =
        ((hmac[offset] & 0x7f) << 24) |
        ((hmac[offset + 1] & 0xff) << 16) |
        ((hmac[offset + 2] & 0xff) << 8) |
        (hmac[offset + 3] & 0xff);

      return String(binary % 1000000).padStart(6, '0');
    } catch (e) {
      console.error('Error generating TOTP:', e);
      return null;
    }
  }

  function base32ToBytes(base32) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let bits = '';
    const bytes = [];

    for (let i = 0; i < base32.length; i++) {
      const char = base32[i];
      if (char === '=') continue;

      const value = alphabet.indexOf(char);
      if (value === -1) {
        throw new Error(`Invalid Base32 character: ${char}`);
      }
      bits += value.toString(2).padStart(5, '0');
    }

    for (let i = 0; i + 8 <= bits.length; i += 8) {
      bytes.push(parseInt(bits.substring(i, i + 8), 2));
    }

    return new Uint8Array(bytes);
  }

  // =====================================================
  // FUNGSI BANTUAN INPUT
  // =====================================================

  function fillInput(input, value) {
    input.focus();

    const setter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      'value'
    ).set;

    setter.call(input, value);

    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function isFillable(input) {
    if (!input) return false;
    const s = window.getComputedStyle(input);
    return (
      s.display !== 'none' &&
      s.visibility !== 'hidden' &&
      s.opacity !== '0' &&
      !input.disabled &&
      !input.readOnly
    );
  }

  function isVisible(el) {
    if (!el) return false;
    const s = window.getComputedStyle(el);
    return (
      s.display !== 'none' &&
      s.visibility !== 'hidden' &&
      s.opacity !== '0'
    );
  }
})();
