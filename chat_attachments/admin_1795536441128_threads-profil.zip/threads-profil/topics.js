const TOPICS = [
  "HoustonTexas",
  "Dating Threads",
  "Message me via my profile",
  "Sent you a friend request",
  "Atlanta",
  "HoustonAtlanta",
  "Texas",
  "Halloween",
  "Dallas"
];

