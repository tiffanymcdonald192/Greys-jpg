var pinarax = false;
var caritab = 0;
var hitung = 0;

chrome.browserAction.onClicked.addListener(function(activeTab) {
	if(pinarax == false) {
		pinarax = true;
	} else if(pinarax == true) {
		pinarax = false;
	}
	caritab = 0;
	pinarax_start();
});

function pinarax_start() {
    if(pinarax == true) {
		chrome.windows.getAll({ populate: true }, function (windows) {
			var count = windows[0];
			var tid = count.tabs[caritab].id;
			chrome.tabs.update(tid, {active: true, highlighted: true});
			caritab++;
			if(caritab < count.tabs.length) {
				setTimeout(function(){
					pinarax_start();
				}, 700);
			} else {
				caritab = 0;
				hitung = 0;
				setTimeout(function(){
					pinarax_start();
				}, 700);
			}
		});
		hitung++;
		chrome.browserAction.setBadgeText({text: '' + hitung});
	} else {
		chrome.browserAction.setBadgeText({text: ''});
	}
}